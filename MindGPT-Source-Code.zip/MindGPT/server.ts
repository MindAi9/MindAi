import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const FIREBASE_PROJECT_ID = 'mindgpt-a091c';
const DATA_DIR = path.resolve(__dirname, 'data');
const AVATARS_DIR = path.join(DATA_DIR, 'avatars');
const LIBRARY_DIR = path.join(DATA_DIR, 'library');
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json');
const LIBRARY_FILE = path.join(DATA_DIR, 'library.json');

try {
  fs.mkdirSync(AVATARS_DIR, { recursive: true });
  fs.mkdirSync(LIBRARY_DIR, { recursive: true });
} catch {}

interface VerifiedFirebaseUser {
  uid: string;
  email: string;
  name?: string;
  picture?: string;
  email_verified?: boolean;
}

interface AuthenticatedRequest extends Request {
  firebaseUser?: VerifiedFirebaseUser;
}

let cachedCerts: Record<string, string> = {};
let certsExpiry = 0;

async function getFirebasePublicCerts(): Promise<Record<string, string>> {
  if (Object.keys(cachedCerts).length > 0 && Date.now() < certsExpiry) {
    return cachedCerts;
  }
  const resp = await fetch(
    'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com',
    { signal: AbortSignal.timeout(8000) }
  );
  if (!resp.ok) {
    throw new Error('Failed to fetch Firebase public verification certificates.');
  }
  const cacheControl = resp.headers.get('cache-control') || '';
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
  const maxAgeSec = maxAgeMatch ? Number(maxAgeMatch[1]) : 3600;
  cachedCerts = (await resp.json()) as Record<string, string>;
  certsExpiry = Date.now() + maxAgeSec * 1000;
  return cachedCerts;
}

function base64UrlDecode(str: string): Buffer {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((str.length + 3) % 4);
  return Buffer.from(padded, 'base64');
}

async function verifyFirebaseIdToken(token: string): Promise<VerifiedFirebaseUser> {
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Invalid authentication token format.');
  }
  const [headerB64, payloadB64, signatureB64] = parts;
  const header = JSON.parse(base64UrlDecode(headerB64).toString('utf8'));
  const payload = JSON.parse(base64UrlDecode(payloadB64).toString('utf8'));

  if (header.alg !== 'RS256' || !header.kid) {
    throw new Error('Unsupported authentication token algorithm.');
  }

  const nowSec = Math.floor(Date.now() / 1000);
  if (payload.aud !== FIREBASE_PROJECT_ID) {
    throw new Error('Authentication token project mismatch.');
  }
  if (payload.iss !== `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`) {
    throw new Error('Authentication token issuer mismatch.');
  }
  if (!payload.sub || typeof payload.sub !== 'string' || payload.sub.length > 128) {
    throw new Error('Invalid Firebase UID in token.');
  }
  if (typeof payload.exp !== 'number' || payload.exp <= nowSec) {
    throw new Error('Authentication session expired. Please sign in again.');
  }
  if (typeof payload.iat !== 'number' || payload.iat > nowSec + 300) {
    throw new Error('Invalid token issue timestamp.');
  }

  const certs = await getFirebasePublicCerts();
  const cert = certs[header.kid];
  if (!cert) {
    throw new Error('Unable to find matching Firebase signing certificate.');
  }

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(`${headerB64}.${payloadB64}`);
  const isValidSig = verifier.verify(cert, base64UrlDecode(signatureB64));
  if (!isValidSig) {
    throw new Error('Authentication token signature verification failed.');
  }

  return {
    uid: payload.sub,
    email: payload.email || '',
    name: payload.name,
    picture: payload.picture,
    email_verified: Boolean(payload.email_verified),
  };
}

async function requireFirebaseAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in with Google.' });
    return;
  }
  const token = authHeader.slice(7).trim();
  try {
    req.firebaseUser = await verifyFirebaseIdToken(token);
    next();
  } catch (err: any) {
    res.status(401).json({ error: err?.message || 'Invalid or expired authentication session.' });
  }
}

function readProfilesStore(): Record<string, any> {
  try {
    if (fs.existsSync(PROFILES_FILE)) {
      return JSON.parse(fs.readFileSync(PROFILES_FILE, 'utf8'));
    }
  } catch {}
  return {};
}

function writeProfilesStore(data: Record<string, any>) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(PROFILES_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function readLibraryStore(): any[] {
  try {
    if (fs.existsSync(LIBRARY_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(LIBRARY_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {}
  return [];
}

function writeLibraryStore(items: any[]) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(LIBRARY_FILE, JSON.stringify(items, null, 2), 'utf8');
}

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// CORS & COOP Middleware (same-origin-allow-popups ensures Firebase Auth popup postMessage succeeds)
app.use((_req: Request, res: Response, next) => {
  res.header('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  if (_req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json({ limit: '25mb' }));

// Cloudflare Worker URL (if configured)
const CLOUDFLARE_WORKER_URL =
  process.env.CLOUDFLARE_WORKER_URL ||
  process.env.MINDGPT_API_URL ||
  '';

// Initialize GoogleGenAI server-side client
function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Model mapping - maps custom display names to genuine, working models
function resolveUnderlyingModel(requestedModel?: string): string {
  if (!requestedModel) return 'gemini-3.1-flash-lite';
  const clean = requestedModel.toLowerCase();
  if (clean.includes('reasoning') || clean.includes('argon')) {
    return 'gemini-4-argon';
  }
  // Mind Turbo One maps to gemini-3.1-flash-lite (fastest, lowest latency, reliable quota)
  return 'gemini-3.1-flash-lite';
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  const key = process.env.GEMINI_API_KEY || '';
  const hasKey = Boolean(key && key !== 'MY_GEMINI_API_KEY');
  const pollinationsKey = process.env.POLLINATIONS_API_KEY || '';
  const hasPollinationsKey = Boolean(pollinationsKey && pollinationsKey.trim().length > 6);
  res.json({
    status: 'ok',
    name: 'MindGPT Unified API',
    hasApiKey: hasKey,
    hasCloudflareWorker: Boolean(CLOUDFLARE_WORKER_URL),
    imageProviders: {
      cloudflareWorkerConfigured: Boolean(CLOUDFLARE_WORKER_URL),
      geminiApiKeyConfigured: hasKey,
      pollinationsApiKeyConfigured: hasPollinationsKey,
      pollinationsFreeFallbackActive: true,
    },
    models: {
      default: 'Mind Turbo One',
      reasoning: 'Mind Advanced Reasoning 4.0',
    },
    time: new Date().toISOString(),
  });
});

// Models list endpoint for client selector
app.get('/api/models', (_req: Request, res: Response) => {
  res.json([
    {
      id: 'mind-turbo-one',
      name: 'Mind Turbo One',
      tagline: 'High speed, balanced intelligence for coding, creative writing, and everyday analysis',
      badge: 'Recommended',
      speed: 'Ultra Fast (~140 tok/s)',
      context: '1M tokens',
      languages: 'English, Hindi, Hinglish + 80 more',
      isDefault: true,
    },
    {
      id: 'mind-reasoning',
      name: 'Mind Advanced Reasoning 4.0',
      tagline: 'Deep step-by-step logic, STEM problem solving, and complex system architectures',
      badge: 'Reasoning',
      speed: 'Standard',
      context: '2M tokens',
      languages: 'Multilingual',
      isDefault: false,
    },
  ]);
});

interface ChatMessageInput {
  role: 'user' | 'assistant' | 'model';
  content: string;
  attachments?: Array<{
    name: string;
    type: string;
    data: string;
    isBase64?: boolean;
  }>;
}

// Strictly format and alternate multi-turn messages for underlying AI model
function formatContentsForGemini(rawMessages: ChatMessageInput[]) {
  // A message is valid if it has non-empty text OR valid attachments
  const valid = rawMessages.filter(
    (m) =>
      m &&
      ((m.content && m.content.trim().length > 0) ||
        (m.attachments && m.attachments.length > 0))
  );

  if (valid.length === 0) {
    return [{ role: 'user', parts: [{ text: 'Hello' }] }];
  }

  const formatted: Array<{ role: 'user' | 'model'; parts: any[] }> = [];

  for (let i = 0; i < valid.length; i++) {
    const msg = valid[i];
    const role: 'user' | 'model' = msg.role === 'assistant' ? 'model' : 'user';
    const parts: any[] = [];

    if (msg.attachments && msg.attachments.length > 0) {
      for (const att of msg.attachments) {
        if (att.isBase64 && att.data) {
          parts.push({
            inlineData: {
              mimeType: att.type || 'image/jpeg',
              data: att.data.replace(/^data:[^;]+;base64,/, ''),
            },
          });
        } else if (att.data) {
          parts.push({
            text: `[Attached Document: ${att.name}]\n${att.data}\n[End Document]`,
          });
        }
      }
    }

    if (msg.content && msg.content.trim().length > 0) {
      parts.push({ text: msg.content.trim() });
    }

    // Skip if empty parts
    if (parts.length === 0) {
      continue;
    }

    // Ensure alternating roles: if previous message has same role, combine parts
    if (formatted.length > 0 && formatted[formatted.length - 1].role === role) {
      formatted[formatted.length - 1].parts.push(...parts);
    } else {
      formatted.push({ role, parts });
    }
  }

  // Model requires the first turn to be 'user'
  while (formatted.length > 0 && formatted[0].role === 'model') {
    formatted.shift();
  }

  // Multi-turn completion requires the last turn in contents to be 'user'
  while (formatted.length > 0 && formatted[formatted.length - 1].role === 'model') {
    formatted.pop();
  }

  if (formatted.length === 0) {
    return [{ role: 'user', parts: [{ text: 'Hello' }] }];
  }

  return formatted;
}

const DEFAULT_SYSTEM_INSTRUCTION = `You are MindGPT, an independent AI assistant developed and created by Ragib.
MindGPT is an independent AI product created by Ragib.

CRITICAL IDENTITY DIRECTIVE:
Whenever someone asks who created MindGPT, who its developer is, or who made it, you MUST respond:
"I was created by Ragib, the developer and creator of MindGPT. My vision is to make AI useful, accessible, and intelligent for everyone."
Never claim that Google AI Studio, Gemini, Firebase, or another platform created MindGPT. You may explain that MindGPT uses third-party AI technologies when relevant, but clearly distinguish Ragib as the creator and developer from underlying technology providers. Do not invent a publication date or other developer information.

PERSONALITY & COMMUNICATION STYLE:
- Be natural, intelligent, conversational, and genuinely helpful.
- Be concise by default for simple queries, and structured with step-by-step clarity for complex STEM, coding, or analytical queries.
- Do NOT repeat the user's prompt or begin with robotic introductory filler ("Certainly!", "I can help with that"). Jump straight to the insightful answer.
- Avoid oversized # or ## headings for normal conversational replies; prefer clean normal-sized paragraphs, concise bullet lists, and ### subheadings only when multi-section structure is genuinely needed.

REAL-TIME GROUNDING & INDIA-FOCUSED KNOWLEDGE:
- Current Year: 2026. Keep awareness that the current calendar year is 2026.
- For current or upcoming Indian festivals (e.g. Holi, Diwali, Eid, Durga Puja, Raksha Bandhan), national days, budget updates, competitive exams (UPSC, JEE, NEET), government schemes, and digital payments (UPI, RuPay), provide accurate 2026 or current verified information. Never return past years' dates (such as 2024 or 2025) for upcoming or current festivals.`;

const LOCALE_LANGUAGE_MAP: Record<string, { label: string; scriptRule: string }> = {
  'hi-IN': { label: 'Hindi (हिन्दी)', scriptRule: 'Write naturally and fluently in Hindi using proper Devanagari script (हिंदी). Do NOT randomly switch to English or mix Hindi and English words unless writing code or an untranslatable technical identifier.' },
  'en-IN': { label: 'English (India)', scriptRule: 'Write clearly in natural Indian English.' },
  'en-US': { label: 'English (US)', scriptRule: 'Write clearly in standard American English. Do NOT randomly switch languages.' },
  'en-GB': { label: 'English (UK)', scriptRule: 'Write clearly in standard British English.' },
  'en-AU': { label: 'English (Australia)', scriptRule: 'Write clearly in standard Australian English.' },
  'en-CA': { label: 'English (Canada)', scriptRule: 'Write clearly in standard Canadian English.' },
  'bn-IN': { label: 'Bengali (বাংলা)', scriptRule: 'Write fluently in Bengali using Bengali script (বাংলা).' },
  'bho-IN': { label: 'Bhojpuri (भोजपुरी)', scriptRule: 'Write naturally in Bhojpuri using Devanagari script (भोजपुरी).' },
  'mai-IN': { label: 'Maithili (मैथिली)', scriptRule: 'Write naturally in Maithili using Devanagari script (मैथिली).' },
  'mr-IN': { label: 'Marathi (मराठी)', scriptRule: 'Write fluently in Marathi using Devanagari script (मराठी).' },
  'gu-IN': { label: 'Gujarati (ગુજરાતી)', scriptRule: 'Write fluently in Gujarati using Gujarati script (ગુજરાતી).' },
  'pa-IN': { label: 'Punjabi (ਪੰਜਾਬੀ)', scriptRule: 'Write fluently in Punjabi using Gurmukhi script (ਪੰਜਾਬੀ).' },
  'ta-IN': { label: 'Tamil (தமிழ்)', scriptRule: 'Write fluently in Tamil using Tamil script (தமிழ்).' },
  'te-IN': { label: 'Telugu (తెలుగు)', scriptRule: 'Write fluently in Telugu using Telugu script (తెలుగు).' },
  'kn-IN': { label: 'Kannada (ಕನ್ನಡ)', scriptRule: 'Write fluently in Kannada using Kannada script (ಕನ್ನಡ).' },
  'ml-IN': { label: 'Malayalam (മലയാളം)', scriptRule: 'Write fluently in Malayalam using Malayalam script (മലയാളം).' },
  'or-IN': { label: 'Odia (ଓଡ଼ିଆ)', scriptRule: 'Write fluently in Odia using Odia script (ଓଡ଼ିଆ).' },
  'as-IN': { label: 'Assamese (অসমীয়া)', scriptRule: 'Write naturally in Assamese using Assamese/Bengali script (অসমীয়া).' },
  'sa-IN': { label: 'Sanskrit (संस्कृतम्)', scriptRule: 'Write in standard Sanskrit using Devanagari script (संस्कृतम्).' },
  'kok-IN': { label: 'Konkani (कोंकणी)', scriptRule: 'Write naturally in Konkani using Devanagari script (कोंकणी).' },
  'doi-IN': { label: 'Dogri (डोगरी)', scriptRule: 'Write naturally in Dogri using Devanagari script (डोगरी).' },
  'ks-IN': { label: 'Kashmiri (कश्मीरी)', scriptRule: 'Write naturally in Kashmiri.' },
  'mni-IN': { label: 'Manipuri (মৈতৈলোন্)', scriptRule: 'Write naturally in Manipuri (Meitei).' },
  'ne-IN': { label: 'Nepali (नेपाली)', scriptRule: 'Write fluently in Nepali using Devanagari script (नेपाली).' },
  'ur-IN': { label: 'Urdu (اردو)', scriptRule: 'Write fluently in Urdu using Perso-Arabic Urdu script (اردو).' },
  'es-ES': { label: 'Spanish (Español)', scriptRule: 'Write fluently in Spanish.' },
  'fr-FR': { label: 'French (Français)', scriptRule: 'Write fluently in French.' },
  'de-DE': { label: 'German (Deutsch)', scriptRule: 'Write fluently in German.' },
  'ja-JP': { label: 'Japanese (日本語)', scriptRule: 'Write fluently in Japanese.' },
  'ko-KR': { label: 'Korean (한국어)', scriptRule: 'Write fluently in Korean.' },
  'zh-CN': { label: 'Chinese (中文)', scriptRule: 'Write fluently in Simplified Chinese.' },
  'ar-SA': { label: 'Arabic (العربية)', scriptRule: 'Write fluently in Arabic.' },
  'pt-BR': { label: 'Portuguese (Português)', scriptRule: 'Write fluently in Brazilian Portuguese.' },
  'ru-RU': { label: 'Russian (Русский)', scriptRule: 'Write fluently in Russian.' },
};

function buildLanguageDirective(rawLocale?: string): string {
  const code =
    rawLocale === 'hi'
      ? 'hi-IN'
      : rawLocale === 'en'
        ? 'en-US'
        : rawLocale === 'hinglish'
          ? 'en-IN'
          : rawLocale && LOCALE_LANGUAGE_MAP[rawLocale]
            ? rawLocale
            : 'en-US';
  const entry = LOCALE_LANGUAGE_MAP[code] || LOCALE_LANGUAGE_MAP['en-US'];
  return `\n\nSTRICT RESPONSE LANGUAGE POLICY (${code}):
- The user's selected response language in Settings is: ${entry.label} (${code}).
- ${entry.scriptRule}
- You MUST answer in ${entry.label} across both new and existing conversations, regardless of minor greetings or mixed phrasing.
- EXCEPTION: ONLY if the user explicitly requests a different language inside that specific message (for example "reply in English", "translate to Spanish", "answer in Hindi"), follow that explicit per-message request for that turn only.`;
}

function parseGeminiErrorMessage(error: any): string {
  if (!error) return 'An unexpected error occurred.';
  let msg = error.message || String(error);

  try {
    const parsed = JSON.parse(msg);
    if (parsed.error?.message) {
      msg = parsed.error.message;
    }
  } catch {}

  if (msg.includes('high demand') || msg.includes('UNAVAILABLE') || error?.status === 503) {
    return 'MindGPT servers are experiencing high demand right now. Please tap Retry in a few moments.';
  }
  if (
    msg.includes('PERMISSION_DENIED') ||
    error?.status === 403 ||
    msg.includes('API_KEY_INVALID') ||
    msg.includes('ACCESS_TOKEN_SCOPE_INSUFFICIENT') ||
    msg.includes('insufficient authentication scopes')
  ) {
    return 'MindGPT API Key requires authorization. Please verify or re-select your GEMINI_API_KEY in the Settings > Secrets panel.';
  }
  if (msg.includes('RESOURCE_EXHAUSTED') || error?.status === 429) {
    return 'Request volume limit reached. Please wait a moment before sending another message.';
  }
  if (msg.includes('not found') || error?.status === 404) {
    return 'The requested AI model is currently updating. Switching to default model...';
  }
  return msg;
}

// Forward chat request to Cloudflare Worker if configured
async function tryForwardToCloudflareWorker(payload: any, isStream: boolean, res: Response): Promise<boolean> {
  const workerUrl = payload.customWorkerUrl || CLOUDFLARE_WORKER_URL;
  if (!workerUrl) return false;

  try {
    const targetUrl = workerUrl.endsWith('/api/chat') || workerUrl.endsWith('/chat')
      ? workerUrl
      : `${workerUrl.replace(/\/$/, '')}/api/chat`;

    console.log(`Forwarding chat request to Cloudflare Worker: ${targetUrl}`);

    const response = await fetch(targetUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      console.warn(`Cloudflare Worker responded with status ${response.status}`);
      return false; // Fallback to direct Gemini
    }

    if (isStream && response.body) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      const reader = (response.body as any).getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(value);
      }
      res.end();
      return true;
    } else {
      const data = await response.json();
      res.json(data);
      return true;
    }
  } catch (err) {
    console.warn('Failed to route through Cloudflare Worker, falling back to direct Gemini API:', err);
    return false;
  }
}

// Streaming Chat Endpoint via Server-Sent Events (SSE)
app.post('/api/chat/stream', async (req: Request, res: Response) => {
  const { messages, systemInstruction, model, customWorkerUrl, useSearch, languagePreference } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Messages array is required.' });
    return;
  }

  // 1. Try Cloudflare Worker (if configured)
  if (customWorkerUrl || CLOUDFLARE_WORKER_URL) {
    const handled = await tryForwardToCloudflareWorker(req.body, true, res);
    if (handled) return;
  }

  // 2. Direct Server-Side Gemini Execution
  const ai = getGenAIClient();
  if (!ai) {
    res.status(503).json({
      error: 'MindGPT API Key is not configured yet. Please configure your GEMINI_API_KEY in the environment or Secrets panel to enable live responses.',
    });
    return;
  }

  const actualModel = resolveUnderlyingModel(model);

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  try {
    const formattedContents = formatContentsForGemini(messages);
    const baseInstr = systemInstruction || DEFAULT_SYSTEM_INSTRUCTION;
    const instruction = `${baseInstr}${buildLanguageDirective(languagePreference)}`;

    // Only enable web search grounding if user explicitly asked or flagged useSearch
    const lastUserMsg = messages[messages.length - 1]?.content || '';
    const isSearchExplicitlyRequested = Boolean(
      useSearch ||
      /\b(search the web|live news|current weather|search online|live sports score)\b/i.test(lastUserMsg)
    );

    let streamResponse: any;

    if (isSearchExplicitlyRequested) {
      try {
        streamResponse = await ai.models.generateContentStream({
          model: 'gemini-3.1-flash-lite',
          contents: formattedContents,
          config: {
            systemInstruction: instruction,
            tools: [{ googleSearch: {} }],
          },
        });
      } catch (searchErr: any) {
        console.warn('Google search grounding failed (quota/scope), falling back to direct model:', searchErr?.message);
        streamResponse = await ai.models.generateContentStream({
          model: actualModel,
          contents: formattedContents,
          config: { systemInstruction: instruction },
        });
      }
    } else {
      // Normal questions must receive normal direct AI answers
      streamResponse = await ai.models.generateContentStream({
        model: actualModel,
        contents: formattedContents,
        config: { systemInstruction: instruction },
      });
    }

    let hasReportedSearch = false;
    const collectedSources: Array<{ title: string; uri: string }> = [];

    for await (const chunk of streamResponse) {
      const metadata = chunk.candidates?.[0]?.groundingMetadata;
      if (!hasReportedSearch && metadata?.webSearchQueries && metadata.webSearchQueries.length > 0) {
        hasReportedSearch = true;
        res.write(`data: ${JSON.stringify({ searchStatus: 'Searching the web...' })}\n\n`);
      }

      if (metadata?.groundingChunks) {
        for (const ch of metadata.groundingChunks) {
          if (ch.web?.uri && ch.web?.title) {
            if (!collectedSources.some((s) => s.uri === ch.web.uri)) {
              collectedSources.push({
                title: ch.web.title,
                uri: ch.web.uri,
              });
            }
          }
        }
      }

      const text = chunk.text;
      if (text) {
        res.write(`data: ${JSON.stringify({ text })}\n\n`);
      }
    }

    if (collectedSources.length > 0) {
      res.write(`data: ${JSON.stringify({ groundingSources: collectedSources })}\n\n`);
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Error generating streaming response from Gemini:', error);
    const friendlyError = parseGeminiErrorMessage(error);
    res.write(`data: ${JSON.stringify({ error: friendlyError })}\n\n`);
    res.end();
  }
});

// Non-streaming chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  const { messages, systemInstruction, model, customWorkerUrl, useSearch, languagePreference } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Messages array is required.' });
    return;
  }

  // 1. Try Cloudflare Worker (if configured)
  if (customWorkerUrl || CLOUDFLARE_WORKER_URL) {
    const handled = await tryForwardToCloudflareWorker(req.body, false, res);
    if (handled) return;
  }

  // 2. Direct Server-Side Gemini Execution
  const ai = getGenAIClient();
  if (!ai) {
    res.status(503).json({
      error: 'MindGPT API Key is not configured yet. Please configure your GEMINI_API_KEY in the environment or Secrets panel to enable live responses.',
    });
    return;
  }

  const actualModel = resolveUnderlyingModel(model);

  try {
    const formattedContents = formatContentsForGemini(messages);
    const baseInstr = systemInstruction || DEFAULT_SYSTEM_INSTRUCTION;
    const instruction = `${baseInstr}${buildLanguageDirective(languagePreference)}`;

    const lastUserMsg = messages[messages.length - 1]?.content || '';
    const isSearchExplicitlyRequested = Boolean(
      useSearch ||
      /\b(search the web|live news|current weather|search online|live sports score)\b/i.test(lastUserMsg)
    );

    let response: any;
    let finalModel = actualModel;

    if (isSearchExplicitlyRequested) {
      try {
        response = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: formattedContents,
          config: {
            systemInstruction: instruction,
            tools: [{ googleSearch: {} }],
          },
        });
      } catch (searchErr: any) {
        console.warn('Google search grounding failed (quota/scope), falling back to direct model:', searchErr?.message);
        response = await ai.models.generateContent({
          model: actualModel,
          contents: formattedContents,
          config: { systemInstruction: instruction },
        });
      }
    } else {
      // Normal direct generation
      response = await ai.models.generateContent({
        model: actualModel,
        contents: formattedContents,
        config: { systemInstruction: instruction },
      });
    }

    const sources: Array<{ title: string; uri: string }> = [];
    const metadata = response.candidates?.[0]?.groundingMetadata;
    if (metadata?.groundingChunks) {
      for (const ch of metadata.groundingChunks) {
        if (ch.web?.uri && ch.web?.title) {
          if (!sources.some((s) => s.uri === ch.web.uri)) {
            sources.push({
              title: ch.web.title,
              uri: ch.web.uri,
            });
          }
        }
      }
    }

    const publicModelName = finalModel.includes('argon') ? 'Mind Advanced Reasoning 4.0' : 'Mind Turbo One';

    res.json({
      role: 'assistant',
      content: response.text || '',
      model: publicModelName,
      groundingSources: sources.length > 0 ? sources : undefined,
    });
  } catch (error: any) {
    console.error('Error in MindGPT generateContent:', error);
    const friendlyError = parseGeminiErrorMessage(error);
    res.status(500).json({ error: friendlyError });
  }
});

interface ServerVoiceOption {
  id: string;
  name: string;
  gender: 'male' | 'female';
  provider: 'gemini' | 'elevenlabs';
  description: string;
}

const GEMINI_TTS_VOICES: ServerVoiceOption[] = [
  { id: 'Kore', name: 'Kore', gender: 'female', provider: 'gemini', description: 'Clear, expressive female voice' },
  { id: 'Zephyr', name: 'Zephyr', gender: 'female', provider: 'gemini', description: 'Warm, calm female voice' },
  { id: 'Charon', name: 'Charon', gender: 'male', provider: 'gemini', description: 'Warm, natural male voice' },
  { id: 'Fenrir', name: 'Fenrir', gender: 'male', provider: 'gemini', description: 'Deep, grounded male voice' },
  { id: 'Puck', name: 'Puck', gender: 'male', provider: 'gemini', description: 'Crisp, articulate male voice' },
];

const ELEVENLABS_TTS_VOICES: ServerVoiceOption[] = [
  { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel', gender: 'female', provider: 'elevenlabs', description: 'ElevenLabs Multilingual Female' },
  { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Bella', gender: 'female', provider: 'elevenlabs', description: 'ElevenLabs Warm Female' },
  { id: 'pNInz6obpgDQGcFmaJgB', name: 'Adam', gender: 'male', provider: 'elevenlabs', description: 'ElevenLabs Deep Male' },
  { id: 'TxGEqnHWrfWFTfGW9XjX', name: 'Josh', gender: 'male', provider: 'elevenlabs', description: 'ElevenLabs Natural Male' },
];

function wrapPcm16AsWav(pcmBuffer: Buffer, sampleRate = 24000, channels = 1): Buffer {
  const byteRate = sampleRate * channels * 2;
  const blockAlign = channels * 2;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcmBuffer.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcmBuffer.length, 40);
  return Buffer.concat([header, pcmBuffer]);
}

// Connected TTS Voices Metadata Endpoint
app.get('/api/tts/voices', (_req: Request, res: Response) => {
  const elevenKey = process.env.ELEVENLABS_API_KEY;
  const geminiKey = process.env.GEMINI_API_KEY;
  const hasEleven = Boolean(elevenKey && elevenKey.trim().length > 8);
  const hasGemini = Boolean(geminiKey && geminiKey !== 'MY_GEMINI_API_KEY');

  if (hasEleven) {
    res.json({
      configured: true,
      provider: 'elevenlabs',
      voices: hasGemini ? [...ELEVENLABS_TTS_VOICES, ...GEMINI_TTS_VOICES] : ELEVENLABS_TTS_VOICES,
    });
    return;
  }

  if (hasGemini) {
    res.json({
      configured: true,
      provider: 'gemini',
      voices: GEMINI_TTS_VOICES,
    });
    return;
  }

  res.json({
    configured: false,
    provider: 'webspeech',
    voices: [],
  });
});

// Real Speech Synthesis Proxy (Gemini TTS 3.8 Flash Lite / ElevenLabs)
app.post('/api/tts', async (req: Request, res: Response) => {
  const { text, voiceId, gender } = req.body || {};
  if (!text || typeof text !== 'string' || !text.trim()) {
    res.status(400).json({ error: 'Text is required for TTS.' });
    return;
  }

  const cleanInput = text.trim().slice(0, 1200);
  const elevenLabsKey = process.env.ELEVENLABS_API_KEY;
  const isElevenVoiceRequested = ELEVENLABS_TTS_VOICES.some((v) => v.id === voiceId);

  // 1. Use ElevenLabs if configured and requested (or no Gemini voice specified)
  if (elevenLabsKey && elevenLabsKey.trim().length > 8 && (isElevenVoiceRequested || !getGenAIClient())) {
    try {
      const fallbackEleven = gender === 'male' ? 'pNInz6obpgDQGcFmaJgB' : '21m00Tcm4TlvDq8ikWAM';
      const selectedVoice = isElevenVoiceRequested ? voiceId : fallbackEleven;
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${selectedVoice}`, {
        method: 'POST',
        headers: {
          Accept: 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': elevenLabsKey,
        },
        body: JSON.stringify({
          text: cleanInput,
          model_id: 'eleven_multilingual_v2',
          voice_settings: { stability: 0.5, similarity_boost: 0.75 },
        }),
        signal: AbortSignal.timeout(20000),
      });

      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        res.setHeader('Content-Type', 'audio/mpeg');
        res.setHeader('X-TTS-Provider', 'elevenlabs');
        res.send(Buffer.from(arrayBuffer));
        return;
      }
      console.warn(`ElevenLabs API responded with status ${response.status}`);
    } catch (err: any) {
      console.warn('ElevenLabs TTS error, checking Gemini TTS fallback:', err?.message);
    }
  }

  // 2. Real Gemini TTS Synthesis (gemini-3.8-flash-lite-tts)
  const ai = getGenAIClient();
  if (!ai) {
    res.json({
      configured: false,
      message: 'No cloud TTS API key is configured. Falling back to device speech synthesis.',
    });
    return;
  }

  const requestedGender: 'male' | 'female' = gender === 'male' ? 'male' : 'female';
  const matchedVoice = GEMINI_TTS_VOICES.find((v) => v.id === voiceId);
  const resolvedVoiceName =
    matchedVoice && matchedVoice.gender === requestedGender
      ? matchedVoice.id
      : matchedVoice && !gender
        ? matchedVoice.id
        : requestedGender === 'male'
          ? 'Charon'
          : 'Kore';

  try {
    const ttsResp = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: cleanInput,
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: resolvedVoiceName,
            },
          },
        },
      },
    });

    const audioPart = ttsResp.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData?.data);
    if (!audioPart?.inlineData?.data) {
      res.status(502).json({ error: 'Gemini TTS returned no audio payload.' });
      return;
    }

    const rawBuf = Buffer.from(audioPart.inlineData.data, 'base64');
    const mime = (audioPart.inlineData.mimeType || 'audio/wav').toLowerCase();
    const isAlreadyWav = rawBuf.subarray(0, 4).toString('ascii') === 'RIFF';

    const finalBuf = isAlreadyWav
      ? rawBuf
      : mime.includes('l16') || mime.includes('pcm') || !mime.includes('wav')
        ? wrapPcm16AsWav(rawBuf, 24000, 1)
        : rawBuf;

    res.setHeader('Content-Type', 'audio/wav');
    res.setHeader('X-TTS-Provider', 'gemini');
    res.setHeader('X-TTS-Voice', resolvedVoiceName);
    res.send(finalBuf);
  } catch (err: any) {
    console.error('Gemini TTS error:', err?.message || err);
    res.status(502).json({
      error: parseGeminiErrorMessage(err) || 'Failed to synthesize voice audio.',
    });
  }
});

// Authenticated User Profile Endpoints (Strictly UID-scoped)
app.get('/api/profile', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const store = readProfilesStore();
  const record = store[fbUser.uid] || null;
  res.json({
    authUser: fbUser,
    profile: record,
  });
});

app.put('/api/profile', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const { displayName, username, photoURL, avatarType, avatarId, avatarBg, preferences } = req.body || {};

  const cleanDisplayName = typeof displayName === 'string' ? displayName.trim() : '';
  const cleanUsername = typeof username === 'string' ? username.trim().toLowerCase() : '';
  const cleanPhotoUrl = typeof photoURL === 'string' ? photoURL.trim() : '';

  if (!cleanDisplayName || cleanDisplayName.length > 60) {
    res.status(400).json({ error: 'Display Name must be between 1 and 60 characters.' });
    return;
  }
  if (!/^[a-z0-9_]{3,24}$/.test(cleanUsername)) {
    res.status(400).json({ error: 'Username must be 3-24 characters using letters, numbers, or underscores.' });
    return;
  }
  if (cleanPhotoUrl.length > 500) {
    res.status(400).json({ error: 'Invalid profile photo reference.' });
    return;
  }

  const store = readProfilesStore();
  // Check username uniqueness across other UIDs
  const usernameTaken = Object.values(store).some(
    (p: any) => p.uid !== fbUser.uid && p.username === cleanUsername
  );
  if (usernameTaken) {
    res.status(409).json({ error: 'That username is already taken. Please choose another.' });
    return;
  }

  const existing = store[fbUser.uid];
  const nowIso = new Date().toISOString();
  const mergedPreferences = {
    ...(existing?.preferences || {}),
    ...(preferences && typeof preferences === 'object'
      ? {
          ...(typeof preferences.languagePreference === 'string'
            ? { languagePreference: preferences.languagePreference.slice(0, 24) }
            : {}),
          ...(preferences.voiceGender === 'male' || preferences.voiceGender === 'female'
            ? { voiceGender: preferences.voiceGender }
            : {}),
          ...(typeof preferences.voiceId === 'string'
            ? { voiceId: preferences.voiceId.slice(0, 64) }
            : {}),
        }
      : {}),
  };

  const updated = {
    uid: fbUser.uid,
    email: fbUser.email || existing?.email || '',
    displayName: cleanDisplayName,
    username: cleanUsername,
    photoURL: cleanPhotoUrl,
    avatarType: ['google', 'preset', 'color', 'upload'].includes(avatarType) ? avatarType : 'google',
    avatarId: typeof avatarId === 'string' ? avatarId.slice(0, 64) : undefined,
    avatarBg: typeof avatarBg === 'string' ? avatarBg.slice(0, 32) : undefined,
    preferences: mergedPreferences,
    createdAt: existing?.createdAt || nowIso,
    updatedAt: nowIso,
  };

  store[fbUser.uid] = updated;
  writeProfilesStore(store);

  res.json({ profile: updated });
});

// Dedicated authenticated user preferences sync (language & voice settings)
app.patch('/api/profile/preferences', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const { languagePreference, voiceGender, voiceId } = req.body || {};

  const store = readProfilesStore();
  const existing = store[fbUser.uid] || {
    uid: fbUser.uid,
    email: fbUser.email || '',
    displayName: fbUser.name || fbUser.email?.split('@')[0] || 'MindGPT User',
    username: `user_${fbUser.uid.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8)}`,
    photoURL: fbUser.picture || '',
    avatarType: 'google',
    createdAt: new Date().toISOString(),
  };

  const nextPrefs = {
    ...(existing.preferences || {}),
    ...(typeof languagePreference === 'string' && languagePreference !== 'auto'
      ? { languagePreference: languagePreference.slice(0, 24) }
      : {}),
    ...(voiceGender === 'male' || voiceGender === 'female' ? { voiceGender } : {}),
    ...(typeof voiceId === 'string' ? { voiceId: voiceId.slice(0, 64) } : {}),
  };

  const updated = {
    ...existing,
    preferences: nextPrefs,
    updatedAt: new Date().toISOString(),
  };

  store[fbUser.uid] = updated;
  writeProfilesStore(store);

  res.json({ preferences: nextPrefs, profile: updated });
});

// Authenticated Avatar Image Upload (validates MIME, size <= 2MB, and image magic bytes)
app.post('/api/profile/avatar', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const { imageData, mimeType } = req.body || {};

  if (!imageData || typeof imageData !== 'string') {
    res.status(400).json({ error: 'Image file data is required.' });
    return;
  }

  const allowedMimes: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
  };

  const dataUrlMatch = imageData.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  const effectiveMime = dataUrlMatch ? dataUrlMatch[1] : mimeType;
  const base64Payload = dataUrlMatch ? dataUrlMatch[2] : imageData.replace(/^data:[^;]+;base64,/, '');

  const ext = allowedMimes[effectiveMime];
  if (!ext) {
    res.status(400).json({ error: 'Unsupported format. Please upload a JPG, PNG, or WebP image.' });
    return;
  }

  const buffer = Buffer.from(base64Payload, 'base64');
  if (buffer.length === 0 || buffer.length > 2 * 1024 * 1024) {
    res.status(400).json({ error: 'Image file exceeds the 2 MB size limit.' });
    return;
  }

  // Magic bytes verification
  const isPng = buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;
  const isJpg = buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  const isWebp =
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP';

  if ((ext === 'png' && !isPng) || (ext === 'jpg' && !isJpg) || (ext === 'webp' && !isWebp)) {
    res.status(400).json({ error: 'Invalid image file signature. Upload rejected.' });
    return;
  }

  try {
    fs.mkdirSync(AVATARS_DIR, { recursive: true });
    // Remove previous uploaded avatar files for this UID to avoid stale accumulation
    for (const existingFile of fs.readdirSync(AVATARS_DIR)) {
      if (existingFile.startsWith(`${fbUser.uid}-`)) {
        try {
          fs.unlinkSync(path.join(AVATARS_DIR, existingFile));
        } catch {}
      }
    }

    const safeUid = fbUser.uid.replace(/[^a-zA-Z0-9_-]/g, '');
    const filename = `${safeUid}-${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(AVATARS_DIR, filename), buffer);

    res.json({
      photoURL: `/api/avatars/${filename}`,
      size: buffer.length,
    });
  } catch (err: any) {
    console.error('Avatar upload disk write failed:', err);
    res.status(500).json({ error: 'Failed to store uploaded image on server.' });
  }
});

// Serve crisp curated SVG preset avatars (Male, Female, AI, Color Icons)
app.get('/api/avatars/preset/:id.svg', (req: Request, res: Response) => {
  const id = (req.params.id || 'color-1').replace(/[^a-zA-Z0-9-]/g, '');
  const rawBg = String(req.query.bg || '10b981').replace(/[^a-fA-F0-9]/g, '').slice(0, 6) || '10b981';
  const bg = `#${rawBg}`;
  const init = String(req.query.init || 'M').replace(/[^a-zA-Z0-9]/g, '').charAt(0).toUpperCase() || 'M';

  let innerSvg = '';
  if (id.startsWith('male-')) {
    const hairColors: Record<string, string> = {
      'male-1': '#1e293b',
      'male-2': '#0f172a',
      'male-3': '#3f2e21',
      'male-4': '#334155',
      'male-5': '#18181b',
      'male-6': '#451a03',
    };
    const skinTones: Record<string, string> = {
      'male-1': '#fde68a',
      'male-2': '#f5d0b5',
      'male-3': '#d9a077',
      'male-4': '#f3cbb0',
      'male-5': '#c68b59',
      'male-6': '#f7d7c4',
    };
    const hair = hairColors[id] || '#1e293b';
    const skin = skinTones[id] || '#f5d0b5';
    const hasGlasses = id === 'male-3' || id === 'male-6';
    const hasBeard = id === 'male-2' || id === 'male-5';
    innerSvg = `
      <circle cx="64" cy="116" r="42" fill="#0f172a" opacity="0.88"/>
      <rect x="53" y="72" width="22" height="18" rx="8" fill="${skin}"/>
      <circle cx="64" cy="54" r="24" fill="${skin}"/>
      <path d="M40 48 C40 24, 88 24, 88 48 C84 36, 44 36, 40 48 Z" fill="${hair}"/>
      ${hasBeard ? `<path d="M44 58 C46 78, 82 78, 84 58 C80 70, 48 70, 44 58 Z" fill="${hair}" opacity="0.85"/>` : ''}
      <circle cx="55" cy="54" r="2.6" fill="#0f172a"/>
      <circle cx="73" cy="54" r="2.6" fill="#0f172a"/>
      ${hasGlasses ? `<rect x="46" y="48" width="16" height="12" rx="4" fill="none" stroke="#0f172a" stroke-width="2.2"/><rect x="66" y="48" width="16" height="12" rx="4" fill="none" stroke="#0f172a" stroke-width="2.2"/><line x1="62" y1="53" x2="66" y2="53" stroke="#0f172a" stroke-width="2"/>` : ''}
      <path d="M57 65 Q64 70 71 65" stroke="#7c2d12" stroke-width="2.4" fill="none" stroke-linecap="round"/>
    `;
  } else if (id.startsWith('female-')) {
    const hairColors: Record<string, string> = {
      'female-1': '#1e1b4b',
      'female-2': '#451a03',
      'female-3': '#7c2d12',
      'female-4': '#0f172a',
      'female-5': '#312e81',
      'female-6': '#1f2937',
    };
    const skinTones: Record<string, string> = {
      'female-1': '#fde2ce',
      'female-2': '#f3c6a5',
      'female-3': '#d79e75',
      'female-4': '#fce1cf',
      'female-5': '#c98e62',
      'female-6': '#f7d5bd',
    };
    const hair = hairColors[id] || '#1e1b4b';
    const skin = skinTones[id] || '#fde2ce';
    const hasGlasses = id === 'female-2' || id === 'female-4';
    innerSvg = `
      <circle cx="64" cy="56" r="31" fill="${hair}"/>
      <path d="M35 58 C35 88, 93 88, 93 58 L95 94 L33 94 Z" fill="${hair}"/>
      <circle cx="64" cy="116" r="40" fill="#1e293b" opacity="0.9"/>
      <rect x="54" y="72" width="20" height="16" rx="8" fill="${skin}"/>
      <circle cx="64" cy="54" r="22" fill="${skin}"/>
      <path d="M42 46 C45 28, 83 28, 86 46 C76 38, 52 38, 42 46 Z" fill="${hair}"/>
      <circle cx="55" cy="54" r="2.5" fill="#0f172a"/>
      <circle cx="73" cy="54" r="2.5" fill="#0f172a"/>
      ${hasGlasses ? `<circle cx="55" cy="54" r="7.5" fill="none" stroke="#0f172a" stroke-width="2"/><circle cx="73" cy="54" r="7.5" fill="none" stroke="#0f172a" stroke-width="2"/><line x1="62.5" y1="54" x2="65.5" y2="54" stroke="#0f172a" stroke-width="2"/>` : ''}
      <path d="M58 64 Q64 69 70 64" stroke="#be123c" stroke-width="2.3" fill="none" stroke-linecap="round"/>
    `;
  } else if (id.startsWith('ai-')) {
    const shapes: Record<string, string> = {
      'ai-1': `<circle cx="64" cy="64" r="28" fill="none" stroke="#fff" stroke-width="4"/><circle cx="64" cy="64" r="14" fill="#fff"/><circle cx="64" cy="30" r="5" fill="#fff"/><circle cx="64" cy="98" r="5" fill="#fff"/>`,
      'ai-2': `<rect x="30" y="42" width="68" height="44" rx="18" fill="#0f172a" stroke="#fff" stroke-width="3.5"/><rect x="40" y="54" width="48" height="14" rx="7" fill="#38bdf8"/><circle cx="52" cy="61" r="3" fill="#fff"/><circle cx="76" cy="61" r="3" fill="#fff"/>`,
      'ai-3': `<rect x="34" y="36" width="60" height="56" rx="16" fill="#fff" opacity="0.95"/><circle cx="50" cy="60" r="6" fill="${bg}"/><circle cx="78" cy="60" r="6" fill="${bg}"/><rect x="50" y="75" width="28" height="5" rx="2.5" fill="${bg}"/>`,
      'ai-4': `<polygon points="64,24 98,64 64,104 30,64" fill="none" stroke="#fff" stroke-width="4.5"/><circle cx="64" cy="64" r="14" fill="#fff"/>`,
      'ai-5': `<circle cx="64" cy="64" r="32" fill="#fff" opacity="0.2"/><circle cx="64" cy="64" r="20" fill="#fff"/><path d="M26 64 Q64 26 102 64 Q64 102 26 64" fill="none" stroke="#fff" stroke-width="3"/>`,
      'ai-6': `<polygon points="64,24 98,46 98,82 64,104 30,82 30,46" fill="none" stroke="#fff" stroke-width="4"/><polygon points="64,42 82,64 64,86 46,64" fill="#fff"/>`,
    };
    innerSvg = shapes[id] || shapes['ai-1'];
  } else {
    const colorShapes: Record<string, string> = {
      'color-1': `<text x="64" y="80" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-size="54" font-weight="800" fill="#ffffff">${init}</text>`,
      'color-2': `<path d="M64 24 L73 53 L102 64 L73 75 L64 104 L55 75 L26 64 L55 53 Z" fill="#ffffff"/>`,
      'color-3': `<polygon points="70,22 36,68 62,68 56,106 92,58 66,58" fill="#ffffff"/>`,
      'color-4': `<circle cx="64" cy="64" r="32" fill="none" stroke="#ffffff" stroke-width="5"/><polygon points="64,38 74,64 64,90 54,64" fill="#ffffff"/>`,
      'color-5': `<path d="M28 84 L36 44 L52 60 L64 36 L76 60 L92 44 L100 84 Z" fill="#ffffff" stroke="#ffffff" stroke-width="3" stroke-linejoin="round"/>`,
      'color-6': `<polygon points="64,26 96,45 96,83 64,102 32,83 32,45" fill="none" stroke="#ffffff" stroke-width="5"/><text x="64" y="76" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-size="38" font-weight="800" fill="#ffffff">${init}</text>`,
    };
    innerSvg = colorShapes[id] || colorShapes['color-1'];
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${bg}"/>
        <stop offset="100%" stop-color="#0f172a" stop-opacity="0.35"/>
      </linearGradient>
    </defs>
    <rect width="128" height="128" rx="64" fill="${bg}"/>
    <rect width="128" height="128" rx="64" fill="url(#g)" opacity="0.45"/>
    ${innerSvg}
  </svg>`;

  res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(svg);
});

// Serve uploaded user avatar files safely
app.get('/api/avatars/:filename', (req: Request, res: Response) => {
  const safeName = path.basename(req.params.filename || '');
  if (!safeName || !/^[a-zA-Z0-9_-]+\.(jpg|png|webp)$/.test(safeName)) {
    res.status(404).json({ error: 'Avatar not found.' });
    return;
  }
  const filePath = path.join(AVATARS_DIR, safeName);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: 'Avatar not found.' });
    return;
  }
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.sendFile(filePath);
});

// Authenticated User Image Library Endpoints (Strictly UID-scoped & Private)
app.get('/api/library', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const all = readLibraryStore();
  const userImages = all
    .filter((item) => item && item.uid === fbUser.uid)
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  res.json({ images: userImages });
});

app.post('/api/library', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const { imageUrl, prompt, aspectRatio, style, provider, model, isEdit } = req.body || {};

  if (!imageUrl || typeof imageUrl !== 'string' || !prompt || typeof prompt !== 'string') {
    res.status(400).json({ error: 'Both imageUrl and prompt are required to save to Library.' });
    return;
  }

  const cleanPrompt = prompt.trim().slice(0, 600);
  const id = `img-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const safeUid = fbUser.uid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || 'user';
  let storedUrl = imageUrl;

  // Persist base64 images cleanly on disk instead of bloating JSON
  const dataMatch = imageUrl.match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/i);
  if (dataMatch) {
    const mime = dataMatch[1].toLowerCase();
    const ext = mime.includes('png') ? 'png' : mime.includes('webp') ? 'webp' : 'jpg';
    const buf = Buffer.from(dataMatch[2], 'base64');
    if (buf.length > 0 && buf.length <= 15 * 1024 * 1024) {
      try {
        fs.mkdirSync(LIBRARY_DIR, { recursive: true });
        const filename = `${safeUid}-${id}.${ext}`;
        fs.writeFileSync(path.join(LIBRARY_DIR, filename), buf);
        storedUrl = `/api/library/image/${filename}`;
      } catch (err) {
        console.warn('Library image disk write failed, keeping inline reference:', err);
      }
    }
  }

  const record = {
    id,
    uid: fbUser.uid,
    imageUrl: storedUrl,
    prompt: cleanPrompt,
    aspectRatio: typeof aspectRatio === 'string' ? aspectRatio : '1:1',
    style: typeof style === 'string' ? style : 'photorealistic',
    provider: typeof provider === 'string' ? provider.slice(0, 48) : undefined,
    model: typeof model === 'string' ? model.slice(0, 64) : undefined,
    isEdit: Boolean(isEdit),
    favorite: false,
    createdAt: Date.now(),
  };

  const all = readLibraryStore();
  all.unshift(record);
  writeLibraryStore(all);

  res.status(201).json({ image: record });
});

app.patch('/api/library/:id', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const id = req.params.id;
  const all = readLibraryStore();
  const idx = all.findIndex((item) => item.id === id && item.uid === fbUser.uid);

  if (idx === -1) {
    res.status(404).json({ error: 'Library image not found.' });
    return;
  }

  const nextFav = typeof req.body?.favorite === 'boolean' ? req.body.favorite : !all[idx].favorite;
  all[idx] = { ...all[idx], favorite: nextFav };
  writeLibraryStore(all);

  res.json({ image: all[idx] });
});

app.delete('/api/library/:id', requireFirebaseAuth, (req: AuthenticatedRequest, res: Response) => {
  const fbUser = req.firebaseUser!;
  const id = req.params.id;
  const all = readLibraryStore();
  const target = all.find((item) => item.id === id && item.uid === fbUser.uid);

  if (!target) {
    res.status(404).json({ error: 'Library image not found.' });
    return;
  }

  if (typeof target.imageUrl === 'string' && target.imageUrl.startsWith('/api/library/image/')) {
    const filename = path.basename(target.imageUrl);
    const filePath = path.join(LIBRARY_DIR, filename);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch {}
    }
  }

  const filtered = all.filter((item) => !(item.id === id && item.uid === fbUser.uid));
  writeLibraryStore(filtered);

  res.json({ deleted: true, id });
});

// Serve stored library images safely
app.get('/api/library/image/:filename', (req: Request, res: Response) => {
  const safeName = path.basename(req.params.filename || '');
  if (!safeName || !/^[a-zA-Z0-9_-]+\.(jpg|png|webp)$/.test(safeName)) {
    res.status(404).json({ error: 'Image not found.' });
    return;
  }
  const filePath = path.join(LIBRARY_DIR, safeName);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: 'Image not found.' });
    return;
  }
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.sendFile(filePath);
});

// Helper: Infer aspect ratio and dimensions automatically from user prompt
function inferDimensionsFromPrompt(prompt: string, requestedRatio?: string): { aspectRatio: string; width: number; height: number } {
  if (requestedRatio && requestedRatio !== 'auto') {
    if (requestedRatio === '16:9') return { aspectRatio: '16:9', width: 1024, height: 576 };
    if (requestedRatio === '9:16') return { aspectRatio: '9:16', width: 576, height: 1024 };
    if (requestedRatio === '4:3') return { aspectRatio: '4:3', width: 800, height: 600 };
    if (requestedRatio === '3:4') return { aspectRatio: '3:4', width: 600, height: 800 };
    return { aspectRatio: '1:1', width: 768, height: 768 };
  }

  const lower = prompt.toLowerCase();
  if (/\b(wallpaper|desktop|banner|landscape|wide|cinema|cinematic|header|panorama)\b/i.test(lower)) {
    return { aspectRatio: '16:9', width: 1024, height: 576 };
  }
  if (/\b(portrait|phone|mobile|story|poster|vertical|tall|reel|phone wallpaper)\b/i.test(lower)) {
    return { aspectRatio: '9:16', width: 576, height: 1024 };
  }
  return { aspectRatio: '1:1', width: 768, height: 768 };
}

async function fetchVerifiedImageBytes(
  prompt: string,
  width: number,
  height: number
): Promise<{ dataUri?: string; mimeType?: string; provider: string; model: string; errorReason?: string }> {
  const clean = encodeURIComponent(prompt.replace(/[\n\r]+/g, ' ').slice(0, 450));
  const seed = Math.floor(Math.random() * 10000000);
  const pollinationsKey = (process.env.POLLINATIONS_API_KEY || '').trim();
  const headers: Record<string, string> = {};
  if (pollinationsKey.length > 6) {
    headers.Authorization = `Bearer ${pollinationsKey}`;
  }

  const modelName = 'flux';
  const targetUrl = `https://image.pollinations.ai/prompt/${clean}?width=${width}&height=${height}&seed=${seed}&model=${modelName}&nologo=true`;
  let lastError = 'Image provider could not return an image right now.';

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const resp = await fetch(targetUrl, {
        headers,
        signal: AbortSignal.timeout(25000),
      });
      const contentType = resp.headers.get('content-type') || '';

      if (resp.ok && contentType.startsWith('image/')) {
        const arrayBuf = await resp.arrayBuffer();
        if (arrayBuf.byteLength > 1000) {
          const base64Data = Buffer.from(arrayBuf).toString('base64');
          return {
            dataUri: `data:${contentType};base64,${base64Data}`,
            mimeType: contentType,
            provider: 'pollinations',
            model: modelName,
          };
        }
      }

      if (resp.status === 402 || resp.status === 429) {
        const errBody = await resp.text().catch(() => '');
        const retryMatch = errBody.match(/Retry after\s+(\d+(?:\.\d+)?)s/i);
        const waitSec = retryMatch ? Math.ceil(Number(retryMatch[1])) : 0;

        if (attempt === 0 && waitSec > 0 && waitSec <= 8) {
          await new Promise((r) => setTimeout(r, (waitSec + 0.5) * 1000));
          continue;
        }
        lastError =
          waitSec > 0
            ? `Free image tier rate limit reached. Please tap Retry in ${waitSec} seconds.`
            : 'Image provider quota/rate limit reached. Configure a paid GEMINI_API_KEY, POLLINATIONS_API_KEY, or CLOUDFLARE_WORKER_URL in backend secrets.';
        break;
      }

      lastError = `Image provider returned status ${resp.status}.`;
    } catch (err: any) {
      lastError = err?.name === 'TimeoutError'
        ? 'Image generation timed out while waiting for the provider.'
        : err?.message || 'Network error contacting image provider.';
    }
  }

  return { provider: 'pollinations', model: modelName, errorReason: lastError };
}

// REAL Image Generation Endpoint (never returns fake images or raw error dumps)
app.post('/api/images/generate', async (req: Request, res: Response) => {
  const { prompt, aspectRatio: userRatio, style, customWorkerUrl } = req.body || {};
  if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
    res.status(400).json({ error: 'Please describe the image you want to generate.' });
    return;
  }

  const cleanPrompt = prompt.trim();
  const { aspectRatio, width, height } = inferDimensionsFromPrompt(cleanPrompt, userRatio);

  let enhancedPrompt = cleanPrompt;
  if (style && style !== 'natural' && style !== 'none' && !cleanPrompt.toLowerCase().includes(String(style).toLowerCase())) {
    enhancedPrompt = `${cleanPrompt}, ${style} style`;
  }

  const diagnostics: string[] = [];

  // 1. Try Cloudflare Worker image endpoint if configured
  const workerBase = (customWorkerUrl || CLOUDFLARE_WORKER_URL || '').replace(/\/$/, '');
  if (workerBase) {
    try {
      const workerResp = await fetch(`${workerBase}/api/images/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: enhancedPrompt, aspectRatio, width, height, style }),
        signal: AbortSignal.timeout(25000),
      });
      if (workerResp.ok) {
        const ct = workerResp.headers.get('content-type') || '';
        if (ct.startsWith('image/')) {
          const buf = await workerResp.arrayBuffer();
          res.json({
            imageUrl: `data:${ct};base64,${Buffer.from(buf).toString('base64')}`,
            prompt: cleanPrompt,
            aspectRatio,
            style: style || 'photorealistic',
            provider: 'cloudflare-worker',
            model: workerResp.headers.get('x-image-model') || 'cloudflare-worker-image',
            createdAt: Date.now(),
          });
          return;
        }
        const workerJson: any = await workerResp.json().catch(() => null);
        const resolvedUrl =
          workerJson?.imageUrl ||
          workerJson?.image ||
          workerJson?.data?.[0]?.url ||
          (workerJson?.data?.[0]?.b64_json
            ? `data:image/png;base64,${workerJson.data[0].b64_json}`
            : null);
        if (resolvedUrl) {
          res.json({
            imageUrl: resolvedUrl,
            prompt: cleanPrompt,
            aspectRatio,
            style: style || 'photorealistic',
            provider: workerJson?.provider || 'cloudflare-worker',
            model: workerJson?.model || 'cloudflare-worker-image',
            createdAt: Date.now(),
          });
          return;
        }
      } else {
        diagnostics.push(`Cloudflare Worker returned HTTP ${workerResp.status}`);
      }
    } catch (workerErr: any) {
      diagnostics.push(`Cloudflare Worker skipped: ${workerErr?.message}`);
    }
  }

  // 2. Try Google GenAI image generation models (requires billing-enabled GEMINI_API_KEY)
  const ai = getGenAIClient();
  if (ai) {
    const validRatio = ['1:1', '3:4', '4:3', '9:16', '16:9'].includes(aspectRatio) ? aspectRatio : '1:1';

    for (const imgModel of ['gemini-3.1-flash-lite-image', 'gemini-nano-banana-2.1']) {
      try {
        const imageResponse = await ai.models.generateContent({
          model: imgModel,
          contents: {
            parts: [{ text: enhancedPrompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: validRatio,
            },
          },
        });
        for (const cand of imageResponse.candidates || []) {
          for (const part of cand.content?.parts || []) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              res.json({
                imageUrl: `data:${mime};base64,${part.inlineData.data}`,
                prompt: cleanPrompt,
                aspectRatio: validRatio,
                style: style || 'photorealistic',
                provider: 'gemini',
                model: imgModel,
                createdAt: Date.now(),
              });
              return;
            }
          }
        }
      } catch (genErr: any) {
        const msg = String(genErr?.message || '');
        console.warn(`${imgModel} generate notice:`, msg);
        if (msg.includes('ACCESS_TOKEN_SCOPE_INSUFFICIENT') || msg.includes('PERMISSION_DENIED')) {
          diagnostics.push(`${imgModel} requires a paid GEMINI_API_KEY scope`);
        } else {
          diagnostics.push(`${imgModel}: ${parseGeminiErrorMessage(genErr)}`);
        }
      }
    }
  }

  // 3. Verified Real AI Image Synthesis fallback (Pollinations Flux watermark-free nologo=true)
  const verifiedImage = await fetchVerifiedImageBytes(enhancedPrompt, width, height);
  if (verifiedImage.dataUri) {
    res.json({
      imageUrl: verifiedImage.dataUri,
      prompt: cleanPrompt,
      aspectRatio,
      style: style || 'photorealistic',
      provider: verifiedImage.provider,
      model: verifiedImage.model,
      createdAt: Date.now(),
    });
    return;
  }

  res.status(502).json({
    error: verifiedImage.errorReason || 'Image generation failed across configured providers. Please retry in a moment.',
    provider: verifiedImage.provider,
    model: verifiedImage.model,
    details: diagnostics.length > 0 ? diagnostics : undefined,
  });
});

// REAL Image Editing Endpoint (native multimodal edit + vision-grounded synthesis fallback)
app.post('/api/images/edit', async (req: Request, res: Response) => {
  const { prompt, imageBase64, mimeType, customWorkerUrl } = req.body || {};
  if (!prompt || !imageBase64) {
    res.status(400).json({ error: 'Both an uploaded image and an edit instruction are required.' });
    return;
  }

  const cleanPrompt = String(prompt).trim();
  const cleanData = String(imageBase64).replace(/^data:[^;]+;base64,/, '');
  const cleanMime = mimeType || 'image/png';

  const workerBase = (customWorkerUrl || CLOUDFLARE_WORKER_URL || '').replace(/\/$/, '');
  if (workerBase) {
    try {
      const workerResp = await fetch(`${workerBase}/api/images/edit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: cleanPrompt, imageBase64: cleanData, mimeType: cleanMime }),
        signal: AbortSignal.timeout(25000),
      });
      if (workerResp.ok) {
        const wJson: any = await workerResp.json().catch(() => null);
        if (wJson?.imageUrl) {
          res.json({
            imageUrl: wJson.imageUrl,
            prompt: cleanPrompt,
            provider: wJson.provider || 'cloudflare-worker',
            model: wJson.model || 'cloudflare-worker-edit',
            createdAt: Date.now(),
            isEdited: true,
          });
          return;
        }
      }
    } catch {}
  }

  const ai = getGenAIClient();
  let synthesisPrompt = cleanPrompt;

  // 1. Try native multimodal image editing models (gemini-3.1-flash-lite-image, gemini-nano-banana-2.1)
  if (ai) {
    for (const editModel of ['gemini-3.1-flash-lite-image', 'gemini-nano-banana-2.1']) {
      try {
        const editResponse = await ai.models.generateContent({
          model: editModel,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: cleanMime,
                  data: cleanData,
                },
              },
              {
                text: `Edit this image carefully according to this instruction: ${cleanPrompt}`,
              },
            ],
          },
        });
        for (const cand of editResponse.candidates || []) {
          for (const part of cand.content?.parts || []) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              res.json({
                imageUrl: `data:${mime};base64,${part.inlineData.data}`,
                prompt: cleanPrompt,
                provider: 'gemini',
                model: editModel,
                createdAt: Date.now(),
                isEdited: true,
              });
              return;
            }
          }
        }
      } catch (editErr: any) {
        console.warn(`${editModel} edit notice:`, editErr?.message);
      }
    }

    // 2. Vision-guided edit synthesis: inspect original photo using Gemini vision so edits preserve the photo's real subject/composition
    try {
      const visionDesc = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: {
          parts: [
            { inlineData: { mimeType: cleanMime, data: cleanData } },
            {
              text: `Describe the exact visual subject, pose, composition, colors, and style of this reference image, and integrate this requested modification seamlessly: "${cleanPrompt}". Output ONLY a single concise image-generation prompt under 320 characters with no preamble.`,
            },
          ],
        },
      });
      if (visionDesc.text && visionDesc.text.trim().length > 10) {
        synthesisPrompt = visionDesc.text.trim().slice(0, 420);
      }
    } catch (visionErr: any) {
      console.warn('Vision-guided edit description notice:', visionErr?.message);
    }
  }

  const verifiedEdited = await fetchVerifiedImageBytes(synthesisPrompt, 768, 768);
  if (verifiedEdited.dataUri) {
    res.json({
      imageUrl: verifiedEdited.dataUri,
      prompt: cleanPrompt,
      provider: verifiedEdited.provider,
      model: verifiedEdited.model,
      createdAt: Date.now(),
      isEdited: true,
    });
    return;
  }

  res.status(502).json({
    error: verifiedEdited.errorReason || 'Image editing could not complete right now. Please try again in a moment.',
    provider: verifiedEdited.provider,
    model: verifiedEdited.model,
  });
});

// Downloadable Project Source ZIP Archive (excludes secrets, node_modules, dist, runtime data)
app.get('/api/export/source-zip', (_req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'MindGPT-Source-Code.zip');
  if (!fs.existsSync(zipPath)) {
    res.status(404).json({ error: 'Source archive is not prepared yet.' });
    return;
  }
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="MindGPT-Source-Code.zip"');
  res.sendFile(zipPath);
});

const server = http.createServer(app);

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`MindGPT Foundation Server running on http://localhost:${PORT}`);
  });
}

startServer();

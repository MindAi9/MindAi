# MindGPT

**MindGPT** is a mobile-first, full-stack conversational AI, voice dictation, and real-time image generation web application built by **Ragib**. It combines streaming Gemini chat with web grounding, Firebase Google authentication, user profiles, multilingual speech input/output, real image generation and editing, an image inspiration gallery, and a private per-user image library.

---

## Key Features

- **Streaming AI Chat**: Multi-turn Gemini chat over SSE (`/api/chat/stream`) with configurable personas, response language selection (including English US and Hindi), Markdown/code rendering, and optional Google Search grounding sources.
- **Real Image Generation & Editing**: Server-side image pipeline (`/api/images/generate` and `/api/images/edit`) supporting a configured Cloudflare Worker endpoint, paid Gemini image models (when enabled), and a watermark-free Flux fallback provider, with inline processing cards, retry handling, fullscreen viewer, and PNG/JPEG download.
- **Images Discovery Gallery**: Curated visual discovery gallery across 11 categories (`Cinematic Photography`, `Portraits`, `Anime`, `3D Art`, `Stickers`, `Indian Traditional Fashion`, `Product Photography`, `Architecture`, `Fantasy`, `Posters`, `Landscapes`) with category filters, search, and a preview Detail View to edit prompts or generate directly.
- **Private Image Library**: UID-isolated per-user generated/edited image archive stored under Firebase UID authentication (`/api/library`), complete with favorites, prompt reuse, provider/model metadata, and delete controls.
- **Firebase Authentication & Profiles**: Google Sign-In via Firebase (`mindgpt-a091c`), session persistence, Firestore/server profile synchronization, and customizable nicknames/avatars.
- **Voice Input & Text-to-Speech**: Language-synced Web Speech API microphone dictation with safe permission prompting and multi-engine voice output (`/api/tts`).
- **Customizable Workspace**: Light/dark themes, accent colors, 16-category searchable settings drawer, conversation pinning/archiving, and optional Supabase persistence helpers.

---

## Technology Stack

- **Frontend**: React 19, TypeScript, Vite 8, Tailwind CSS v4, Lucide Icons, Motion
- **Backend**: Node.js, Express 4, `tsx`, WebSocket (`ws`)
- **AI & Media SDKs**: `@google/genai`, Pollinations Flux fallback, optional Cloudflare Worker proxy
- **Auth & Persistence**: Firebase Authentication & Firestore (`firebase`), Supabase client (`@supabase/supabase-js`), UID-scoped JSON/asset persistence on the server

---

## Prerequisites

- **Node.js** `>= 20.x` (recommended LTS)
- **npm** `>= 10.x` (or `bun` if preferred)
- At least one configured AI API credential (`GEMINI_API_KEY`)

---

## Installation

1. **Extract or clone the repository**:
   ```bash
   git clone <your-repo-url>
   cd mindgpt
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure environment variables**:
   Copy `.env.example` to `.env` and fill in your own runtime values (never commit `.env` to Git):
   ```bash
   cp .env.example .env
   ```

---

## Development

Start the full-stack Express + Vite development server on port `3000`:

```bash
npm run dev
```

Verify TypeScript types without emitting build files:

```bash
npm run lint
```

---

## Build & Production Deployment

1. **Build the frontend bundle (`dist/`)**:
   ```bash
   npm run build
   ```

2. **Start the production server**:
   ```bash
   npm start
   ```

The server binds to `PORT` (default `3000`) on `0.0.0.0`. For cloud deployment (Cloud Run, Render, Fly.io, Railway, or VPS), configure your runtime environment variables in the platform dashboard and run `npm run build` followed by `npm start`.

---

## Environment Variables Reference

Set these in your `.env` file or hosting provider's secrets manager. Never commit secret values to source control.

| Variable | Required | Purpose |
| --- | --- | --- |
| `GEMINI_API_KEY` | Yes (recommended) | Server-side key for Gemini chat streaming, grounding, TTS, and paid Gemini image models (if billed/enabled). |
| `APP_URL` | Recommended | Public base URL of the deployed MindGPT server. |
| `PORT` | Optional | HTTP server listen port (defaults to `3000`). |
| `NODE_ENV` | Optional | Set to `production` in production environments to serve static `dist/` assets. |
| `CLOUDFLARE_WORKER_URL` | Optional | Custom Cloudflare Worker endpoint for proxying chat or image generation requests. |
| `POLLINATIONS_API_KEY` | Optional | Optional Pollinations API token to bypass unauthenticated free-tier image rate limits. |
| `ELEVENLABS_API_KEY` | Optional | Optional ElevenLabs API key for studio TTS synthesis fallback. |
| `SUPABASE_URL` | Optional | Server/client Supabase project URL when Supabase database helpers are enabled. |
| `SUPABASE_ANON_KEY` | Optional | Public Supabase anonymous key (safe for client anon access only when RLS is enabled). |
| `VITE_SUPABASE_URL` | Optional | Vite-exposed Supabase URL for client utilities. |
| `VITE_SUPABASE_ANON_KEY` | Optional | Vite-exposed Supabase anonymous key for client utilities. |

---

## Security & GitHub Export Hygiene

- `.gitignore` excludes `node_modules/`, `dist/`, `.env*` (except `.env.example`), private keys (`*.pem`, `*.key`), service-account JSONs, runtime user data (`data/`), and export ZIP archives.
- Client Firebase configuration resides in `firebase-applet-config.json` (standard public Firebase Web App config — keep Firestore Security Rules in `firestore.rules` deployed and enforced).

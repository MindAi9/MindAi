import { Message, AppSettings, LibraryImageRecord } from '../types';
import { getFirebaseIdToken } from './firebase';
import { normalizeLocaleCode } from '../data/languages';

export interface StreamChatParams {
  messages: Array<{
    role: 'user' | 'assistant';
    content: string;
    attachments?: Array<{
      name: string;
      type: string;
      data: string;
      isBase64?: boolean;
    }>;
  }>;
  settings: AppSettings;
  onChunk: (chunk: string) => void;
  onError: (error: string) => void;
  onDone: () => void;
  onSearchStatus?: (status: string) => void;
  onGroundingSources?: (sources: Array<{ title: string; uri: string }>) => void;
  signal?: AbortSignal;
}

const PERSONA_PROMPTS: Record<string, string> = {
  balanced: `You are MindGPT, an exceptionally intelligent, adaptive, and thoughtful AI cognitive partner developed by Ragib.
You write in clean, elegant prose, with deep clarity, structured formatting, and practical insights.
- When generating code, always specify the language in markdown code blocks, write clean production-quality code, and explain key architectural decisions.
- Maintain an insightful, friendly, and empowering tone without generic corporate fluff.
- Avoid oversized # or ## headings for normal conversational answers; use natural paragraph sizing, bullet points, or ### subheadings only where genuinely helpful.`,
  precise: `You are MindGPT in Precise Mode, developed by Ragib. You give direct, highly concise, and razor-sharp answers.
- Avoid preamble, conversational filler, or unnecessary meta-commentary.
- Focus strictly on verified facts, rigorous logic, and direct solutions.
- Keep explanations tight, efficient, and well-structured without oversized headings.`,
  creative: `You are MindGPT in Creative Mode, developed by Ragib. You excel at inventive thinking, evocative writing, rich analogies, and novel brainstorming.
- Bring fresh perspectives, vivid imagery, and elegant style to every problem.
- Feel free to offer alternative creative angles and bold concepts.`,
  technical: `You are MindGPT in Technical Architect Mode, developed by Ragib.
- Provide deep technical precision, architectural patterns, algorithmic complexity analysis, and production considerations.
- Include concrete type signatures, error handling, edge cases, and best practices.`,
};

export async function streamChatMessage({
  messages,
  settings,
  onChunk,
  onError,
  onDone,
  onSearchStatus,
  onGroundingSources,
  signal,
}: StreamChatParams): Promise<void> {
  try {
    const baseInstruction = PERSONA_PROMPTS[settings.persona] || PERSONA_PROMPTS.balanced;
    const nicknameNote = settings.userNickname?.trim()
      ? `\n\nThe user prefers to be addressed as "${settings.userNickname.trim()}" when appropriate.`
      : '';
    const customNote = settings.customInstructions?.trim()
      ? `\n\nUser Custom Personalization Preferences:\n${settings.customInstructions.trim()}`
      : '';
    const systemInstruction = `${baseInstruction}${nicknameNote}${customNote}`;
    const resolvedLocale = normalizeLocaleCode(settings.languagePreference);

    // Filter out empty messages to prevent 400 Bad Request
    const cleanMessages = messages.filter(
      (m) => Boolean(m.content && m.content.trim().length > 0) || Boolean(m.attachments && m.attachments.length > 0)
    );

    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages: cleanMessages,
        systemInstruction,
        model: settings.model || 'mind-turbo-one',
        languagePreference: resolvedLocale,
        customWorkerUrl: settings.cloudflareWorkerUrl || undefined,
      }),
      signal,
    });

    if (!response.ok) {
      const errJson = await response.json().catch(() => ({}));
      throw new Error(errJson.error || `Server responded with status ${response.status}`);
    }

    if (!response.body) {
      throw new Error('ReadableStream not supported on this browser response.');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('data: ')) {
          const jsonStr = trimmed.slice(6);
          try {
            const data = JSON.parse(jsonStr);
            if (data.error) {
              onError(data.error);
              return;
            }
            if (data.searchStatus && onSearchStatus) {
              onSearchStatus(data.searchStatus);
            }
            if (data.groundingSources && onGroundingSources) {
              onGroundingSources(data.groundingSources);
            }
            if (data.text) {
              onChunk(data.text);
            }
            if (data.done) {
              onDone();
              return;
            }
          } catch (e) {
            // ignore malformed line
          }
        }
      }
    }

    onDone();
  } catch (error: any) {
    if (signal?.aborted) {
      onDone();
      return;
    }
    console.error('MindGPT Stream Error:', error);
    onError(error.message || 'Connection error. Please try again.');
  }
}

export async function checkServerHealth(): Promise<boolean> {
  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    return Boolean(data.hasApiKey);
  } catch {
    return false;
  }
}

export interface ImageGenerationResult {
  imageUrl: string;
  prompt: string;
  aspectRatio?: string;
  style?: string;
  provider?: string;
  model?: string;
  createdAt?: number;
  isEdited?: boolean;
}

export async function generateImageApi(
  prompt: string,
  aspectRatio = 'auto',
  style = 'photorealistic',
  options?: { customWorkerUrl?: string; signal?: AbortSignal }
): Promise<ImageGenerationResult> {
  const response = await fetch('/api/images/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      prompt,
      aspectRatio,
      style,
      customWorkerUrl: options?.customWorkerUrl || undefined,
    }),
    signal: options?.signal,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.imageUrl) {
    throw new Error(data.error || 'Failed to generate image.');
  }

  return data;
}

export async function editImageApi(
  prompt: string,
  imageBase64: string,
  mimeType = 'image/png',
  options?: { customWorkerUrl?: string; signal?: AbortSignal }
): Promise<ImageGenerationResult> {
  const response = await fetch('/api/images/edit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      prompt,
      imageBase64,
      mimeType,
      customWorkerUrl: options?.customWorkerUrl || undefined,
    }),
    signal: options?.signal,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.imageUrl) {
    throw new Error(data.error || 'Failed to edit image.');
  }

  return data;
}

export async function fetchUserLibraryApi(): Promise<LibraryImageRecord[]> {
  const token = await getFirebaseIdToken();
  if (!token) return [];
  const resp = await fetch('/api/library', {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!resp.ok) return [];
  const data = await resp.json().catch(() => ({}));
  return Array.isArray(data.images) ? data.images : [];
}

export async function saveLibraryImageApi(payload: {
  imageUrl: string;
  prompt: string;
  aspectRatio?: string;
  style?: string;
  provider?: string;
  model?: string;
  isEdit?: boolean;
}): Promise<LibraryImageRecord | null> {
  const token = await getFirebaseIdToken();
  if (!token) return null;
  const resp = await fetch('/api/library', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) return null;
  const data = await resp.json().catch(() => ({}));
  return data.image || null;
}

export async function toggleLibraryFavoriteApi(
  id: string,
  favorite?: boolean
): Promise<LibraryImageRecord | null> {
  const token = await getFirebaseIdToken();
  if (!token) return null;
  const resp = await fetch(`/api/library/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(typeof favorite === 'boolean' ? { favorite } : {}),
  });
  if (!resp.ok) return null;
  const data = await resp.json().catch(() => ({}));
  return data.image || null;
}

export async function deleteLibraryImageApi(id: string): Promise<boolean> {
  const token = await getFirebaseIdToken();
  if (!token) return false;
  const resp = await fetch(`/api/library/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
  return resp.ok;
}

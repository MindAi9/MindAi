import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  getAdditionalUserInfo,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Single idempotent Firebase Web App initialization for project mindgpt-a091c
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

const configuredDbId = (firebaseConfig as { firestoreDatabaseId?: string }).firestoreDatabaseId;
export const db = configuredDbId ? getFirestore(app, configuredDbId) : getFirestore(app);
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

// Persist session cleanly across browser refreshes and tabs
export const authPersistenceReady: Promise<void> = setPersistence(auth, browserLocalPersistence).catch(
  (err) => {
    console.warn('Firebase persistence notice:', err);
  }
);

let firestoreUnavailableForSession = false;

async function withTimeout<T>(promise: Promise<T>, ms = 3500): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error('firestore-timeout')), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export interface GoogleAuthResult {
  user: User;
  isNewUser: boolean;
}

export interface UserPreferencesRecord {
  languagePreference?: string;
  voiceGender?: 'male' | 'female';
  voiceId?: string;
}

export interface UserProfileRecord {
  uid: string;
  email: string;
  displayName: string;
  username: string;
  photoURL: string;
  avatarType: 'google' | 'preset' | 'color' | 'upload';
  avatarId?: string;
  avatarBg?: string;
  preferences?: UserPreferencesRecord;
  createdAt: string;
  updatedAt: string;
}

export interface ProfileSyncResult {
  profile: UserProfileRecord;
  firestoreStatus: 'synced' | 'rules-pending' | 'unavailable';
  firestoreMessage?: string;
}

export function mapFirebaseAuthError(error: any): string {
  const code = error?.code || '';
  switch (code) {
    case 'auth/popup-closed-by-user':
      return 'Sign-in window was closed before completing Google authentication.';
    case 'auth/cancelled-popup-request':
      return 'Authentication request was cancelled because another popup is open.';
    case 'auth/popup-blocked':
      return 'Your browser blocked the Google Sign-In popup. Please allow popups for this site and try again.';
    case 'auth/unauthorized-domain':
      return `Domain "${window.location.hostname}" is not authorized in Firebase Console for project "${firebaseConfig.projectId}". Add it under Authentication > Settings > Authorized domains.`;
    case 'auth/network-request-failed':
      return 'Network error occurred while contacting Google Authentication. Check your connection and try again.';
    case 'auth/user-disabled':
      return 'This Google account has been disabled in Firebase Authentication.';
    case 'auth/operation-not-allowed':
      return 'Google Sign-In provider is not enabled in Firebase Authentication Console.';
    default:
      return error?.message || 'Google authentication failed. Please try again.';
  }
}

function isRunningInIframe(): boolean {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
}

export async function signInWithGooglePopup(): Promise<GoogleAuthResult> {
  await authPersistenceReady;
  try {
    const credential = await signInWithPopup(auth, googleProvider);
    const info = getAdditionalUserInfo(credential);
    return {
      user: credential.user,
      isNewUser: Boolean(info?.isNewUser),
    };
  } catch (err: any) {
    const code = err?.code || '';
    // Fall back to redirect only in top-level browser tabs if popup is blocked/unsupported
    if (
      (code === 'auth/popup-blocked' || code === 'auth/operation-not-supported-in-this-environment') &&
      !isRunningInIframe()
    ) {
      await signInWithRedirect(auth, googleProvider);
      throw new Error('Redirecting to Google Sign-In...');
    }
    throw err;
  }
}

export async function checkGoogleRedirectResult(): Promise<GoogleAuthResult | null> {
  try {
    const credential = await getRedirectResult(auth);
    if (!credential) return null;
    const info = getAdditionalUserInfo(credential);
    return {
      user: credential.user,
      isNewUser: Boolean(info?.isNewUser),
    };
  } catch (err) {
    console.warn('Redirect sign-in check notice:', err);
    return null;
  }
}

export async function signOutFromFirebase(): Promise<void> {
  await signOut(auth);
}

export function subscribeToFirebaseAuth(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

export async function getFirebaseIdToken(forceRefresh = false): Promise<string | null> {
  const current = auth.currentUser;
  if (!current) return null;
  try {
    return await current.getIdToken(forceRefresh);
  } catch {
    return null;
  }
}

export function suggestDefaultUsername(displayName?: string | null, email?: string | null, uid?: string): string {
  const rawBase =
    (email && email.split('@')[0]) ||
    (displayName && displayName.toLowerCase()) ||
    'mindgpt_user';
  let cleaned = rawBase
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');
  if (cleaned.length < 3) {
    const suffix = (uid || 'user').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 6) || '001';
    cleaned = `user_${suffix}`;
  }
  return cleaned.slice(0, 24);
}

export function buildDefaultProfileFromUser(user: User): UserProfileRecord {
  const nowIso = new Date().toISOString();
  return {
    uid: user.uid,
    email: user.email || '',
    displayName: user.displayName || user.email?.split('@')[0] || 'MindGPT User',
    username: suggestDefaultUsername(user.displayName, user.email, user.uid),
    photoURL: user.photoURL || '',
    avatarType: 'google',
    createdAt: nowIso,
    updatedAt: nowIso,
  };
}

/**
 * Syncs or loads the UID-keyed User Profile database record.
 * Never overwrites saved user edits with Google defaults on subsequent logins.
 */
export async function syncOrLoadUserProfile(user: User): Promise<ProfileSyncResult> {
  const token = await user.getIdToken();
  const fallbackRecord = buildDefaultProfileFromUser(user);

  // 1. Check backend persistent profile store (authenticated with Firebase ID token)
  let serverProfile: UserProfileRecord | null = null;
  try {
    const resp = await fetch('/api/profile', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (resp.ok) {
      const json = await resp.json();
      serverProfile = json.profile || null;
    }
  } catch (err) {
    console.warn('Backend profile read failed:', err);
  }

  // 2. Check Firestore users/{uid} (strictly owner-only, bounded timeout, no repeated retries if DB missing)
  let firestoreProfile: UserProfileRecord | null = null;
  let firestoreStatus: ProfileSyncResult['firestoreStatus'] = 'unavailable';
  let firestoreMessage: string | undefined;

  if (!firestoreUnavailableForSession) {
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const snap = await withTimeout(getDoc(userDocRef), 3500);
      firestoreStatus = 'synced';
      if (snap.exists()) {
        const data = snap.data() as Partial<UserProfileRecord>;
        firestoreProfile = {
          ...fallbackRecord,
          ...data,
          uid: user.uid,
          email: data.email || user.email || '',
        };
      }
    } catch (err: any) {
      const code = err?.code || '';
      const msg = String(err?.message || '');
      if (
        code === 'not-found' ||
        msg.toLowerCase().includes('not found') ||
        msg === 'firestore-timeout'
      ) {
        firestoreUnavailableForSession = true;
        firestoreStatus = 'unavailable';
        firestoreMessage =
          'Firestore database (default) is not provisioned yet on mindgpt-a091c; synced via authenticated MindGPT profile API.';
      } else if (code === 'permission-denied' || msg.toLowerCase().includes('permission')) {
        firestoreStatus = 'rules-pending';
        firestoreMessage =
          'Firestore security rules need deployment on Firebase project mindgpt-a091c; synced via authenticated MindGPT profile API.';
      } else {
        firestoreStatus = 'unavailable';
        firestoreMessage = msg || 'Firestore unavailable.';
      }
    }
  } else {
    firestoreStatus = 'unavailable';
    firestoreMessage =
      'Firestore database (default) is not provisioned yet on mindgpt-a091c; synced via authenticated MindGPT profile API.';
  }

  let resolvedProfile: UserProfileRecord;
  if (firestoreProfile && serverProfile) {
    const fsTime = Date.parse(firestoreProfile.updatedAt || '') || 0;
    const srvTime = Date.parse(serverProfile.updatedAt || '') || 0;
    resolvedProfile = fsTime >= srvTime ? firestoreProfile : serverProfile;
  } else {
    resolvedProfile = firestoreProfile || serverProfile || fallbackRecord;
  }

  if (!serverProfile) {
    try {
      await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(resolvedProfile),
      });
    } catch {}
  }

  if (firestoreStatus === 'synced' && !firestoreProfile) {
    try {
      await withTimeout(
        setDoc(
          doc(db, 'users', user.uid),
          {
            ...resolvedProfile,
            serverUpdatedAt: serverTimestamp(),
          },
          { merge: true }
        ),
        3500
      );
    } catch {}
  }

  return {
    profile: resolvedProfile,
    firestoreStatus,
    firestoreMessage,
  };
}

export async function saveUserProfileRecord(
  user: User,
  updates: {
    displayName: string;
    username: string;
    photoURL: string;
    avatarType: 'google' | 'preset' | 'color' | 'upload';
    avatarId?: string;
    avatarBg?: string;
  }
): Promise<ProfileSyncResult> {
  const token = await user.getIdToken();

  const resp = await fetch('/api/profile', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(updates),
  });

  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    throw new Error(data.error || 'Failed to save profile changes.');
  }

  const savedProfile: UserProfileRecord = data.profile;

  let firestoreStatus: ProfileSyncResult['firestoreStatus'] = 'unavailable';
  let firestoreMessage: string | undefined;

  if (!firestoreUnavailableForSession) {
    try {
      await withTimeout(
        setDoc(
          doc(db, 'users', user.uid),
          {
            ...savedProfile,
            serverUpdatedAt: serverTimestamp(),
          },
          { merge: true }
        ),
        3500
      );
      firestoreStatus = 'synced';
    } catch (err: any) {
      const code = err?.code || '';
      const msg = String(err?.message || '');
      if (
        code === 'not-found' ||
        msg.toLowerCase().includes('not found') ||
        msg === 'firestore-timeout'
      ) {
        firestoreUnavailableForSession = true;
        firestoreStatus = 'unavailable';
        firestoreMessage = 'Firestore (default) not provisioned yet on mindgpt-a091c; saved to verified profile API.';
      } else if (code === 'permission-denied' || msg.toLowerCase().includes('permission')) {
        firestoreStatus = 'rules-pending';
        firestoreMessage = 'Firestore rules not yet published on mindgpt-a091c; saved to verified profile API.';
      } else {
        firestoreStatus = 'unavailable';
        firestoreMessage = msg || 'Firestore write skipped.';
      }
    }
  } else {
    firestoreMessage = 'Firestore (default) not provisioned yet on mindgpt-a091c; saved to verified profile API.';
  }

  return {
    profile: savedProfile,
    firestoreStatus,
    firestoreMessage,
  };
}

export async function saveUserPreferencesRecord(
  user: User,
  preferences: UserPreferencesRecord
): Promise<UserPreferencesRecord> {
  const token = await user.getIdToken();
  let savedPrefs: UserPreferencesRecord = preferences;

  try {
    const resp = await fetch('/api/profile/preferences', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(preferences),
    });
    if (resp.ok) {
      const json = await resp.json().catch(() => ({}));
      if (json.preferences) {
        savedPrefs = json.preferences;
      }
    }
  } catch (err) {
    console.warn('Server preference sync failed:', err);
  }

  if (!firestoreUnavailableForSession) {
    try {
      await withTimeout(
        setDoc(
          doc(db, 'users', user.uid),
          {
            preferences: savedPrefs,
            serverUpdatedAt: serverTimestamp(),
          },
          { merge: true }
        ),
        3000
      );
    } catch {}
  }

  return savedPrefs;
}

export async function uploadUserAvatarImage(file: File): Promise<string> {
  const current = auth.currentUser;
  if (!current) {
    throw new Error('Authentication required before uploading a profile photo.');
  }
  const token = await current.getIdToken();

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Could not read the selected image file.'));
    reader.readAsDataURL(file);
  });

  const resp = await fetch('/api/profile/avatar', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      imageData: dataUrl,
      mimeType: file.type,
    }),
  });

  const json = await resp.json().catch(() => ({}));
  if (!resp.ok || !json.photoURL) {
    throw new Error(json.error || 'Avatar upload failed.');
  }

  return json.photoURL as string;
}

export type { User as FirebaseUser };

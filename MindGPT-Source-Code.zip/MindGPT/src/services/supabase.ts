import { createClient, SupabaseClient, User, Session } from '@supabase/supabase-js';

// Retrieve Supabase credentials from Vite environment or localStorage override
const supabaseUrl =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  (typeof window !== 'undefined' && (window as any).__SUPABASE_URL__) ||
  '';

const supabaseAnonKey =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof window !== 'undefined' && (window as any).__SUPABASE_ANON_KEY__) ||
  '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl !== 'https://your-project.supabase.co' &&
    !supabaseUrl.includes('placeholder')
);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;

export interface AuthState {
  user: User | null;
  session: Session | null;
  isConfigured: boolean;
  configError?: string;
}

export async function getInitialAuthState(): Promise<AuthState> {
  if (!supabase || !isSupabaseConfigured) {
    return {
      user: null,
      session: null,
      isConfigured: false,
      configError:
        'Supabase project credentials not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment.',
    };
  }

  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    return {
      user: data.session?.user || null,
      session: data.session,
      isConfigured: true,
    };
  } catch (err: any) {
    return {
      user: null,
      session: null,
      isConfigured: true,
      configError: err.message,
    };
  }
}

export async function signUpWithEmail(email: string, password: string) {
  if (!supabase) {
    throw new Error('Supabase project credentials not found. Configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.');
  }
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw error;
  return data;
}

export async function signInWithEmail(email: string, password: string) {
  if (!supabase) {
    throw new Error('Supabase project credentials not found. Configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.');
  }
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOutUser() {
  if (!supabase) return;
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function resetPasswordForEmail(email: string) {
  if (!supabase) {
    throw new Error('Supabase project credentials not found. Configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.');
  }
  const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: typeof window !== 'undefined' ? `${window.location.origin}/reset-password` : undefined,
  });
  if (error) throw error;
  return data;
}

// Supabase SQL Schema and Row Level Security for MindGPT
export const SUPABASE_RLS_SCHEMA_SQL = `-- MindGPT Supabase Database Schema & Row Level Security (RLS)
-- Run this in your Supabase SQL Editor for project "MindGPT"

-- 1. Profiles Table
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  full_name text,
  avatar_url text,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.profiles enable row level security;

create policy "Users can view own profile" 
  on public.profiles for select 
  using (auth.uid() = id);

create policy "Users can update own profile" 
  on public.profiles for update 
  using (auth.uid() = id);

-- 2. Conversations Table
create table if not exists public.conversations (
  id text primary key,
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  messages jsonb not null default '[]'::jsonb,
  is_pinned boolean default false,
  created_at bigint not null,
  updated_at bigint not null
);

alter table public.conversations enable row level security;

create policy "Users can view own conversations" 
  on public.conversations for select 
  using (auth.uid() = user_id);

create policy "Users can insert own conversations" 
  on public.conversations for insert 
  with check (auth.uid() = user_id);

create policy "Users can update own conversations" 
  on public.conversations for update 
  using (auth.uid() = user_id);

create policy "Users can delete own conversations" 
  on public.conversations for delete 
  using (auth.uid() = user_id);
`;

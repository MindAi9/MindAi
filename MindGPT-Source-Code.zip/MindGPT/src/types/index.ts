export interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  data: string; // base64 or text preview
  isBase64?: boolean;
}

export interface GeneratedImagePayload {
  url: string;
  prompt: string;
  aspectRatio?: string;
  style?: string;
  provider?: string;
  model?: string;
  isEdit?: boolean;
  savedToLibrary?: boolean;
}

export interface LibraryImageRecord {
  id: string;
  uid: string;
  imageUrl: string;
  prompt: string;
  aspectRatio?: string;
  style?: string;
  provider?: string;
  model?: string;
  isEdit?: boolean;
  favorite: boolean;
  createdAt: number;
}

export interface ImageGenerationState {
  status: 'generating' | 'error';
  prompt: string;
  aspectRatio?: string;
  style?: string;
  isEdit?: boolean;
  errorMessage?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  generatedImage?: GeneratedImagePayload;
  imageGeneration?: ImageGenerationState;
  model?: string;
  isStreaming?: boolean;
  error?: boolean;
  groundingSources?: Array<{ title: string; uri: string }>;
  searchStatus?: string;
}

export interface Conversation {
  id: string;
  userId?: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  isPinned?: boolean;
  isLocked?: boolean;
  isArchived?: boolean;
  project?: string;
}

export interface AppSettings {
  theme: 'light' | 'dark';
  model: string;
  persona: 'balanced' | 'precise' | 'creative' | 'technical';
  soundEnabled: boolean;
  streamResponses: boolean;
  codeLineNumbers: boolean;
  userAvatarText: string;
  languagePreference: string;
  voiceGender: 'male' | 'female';
  voiceId?: string;
  cloudflareWorkerUrl: string;
  accentColor?: 'green' | 'blue' | 'purple' | 'amber';
  enterBehavior?: 'newline' | 'send';
  autoScroll?: boolean;
  customInstructions?: string;
  userNickname?: string;
  speechLanguage?: string;
}

export interface QuickPrompt {
  id: string;
  category: 'code' | 'analysis' | 'creative' | 'explain';
  categoryLabel: string;
  title: string;
  description: string;
  prompt: string;
  iconName: string;
}

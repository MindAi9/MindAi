import React, { useState, useEffect, useRef } from 'react';
import { Conversation, Message, AppSettings, Attachment, LibraryImageRecord } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { NavigationDrawer, DrawerType } from './components/NavigationDrawer';
import {
  streamChatMessage,
  generateImageApi,
  editImageApi,
  fetchUserLibraryApi,
  saveLibraryImageApi,
  toggleLibraryFavoriteApi,
  deleteLibraryImageApi,
} from './services/api';
import { playSendSound, playReceiveSound } from './utils/sound';
import { ttsEngine } from './utils/tts';
import { ChevronDown, Loader2 } from 'lucide-react';
import { useAuth } from './contexts/AuthContext';
import { FirebaseAuthScreen } from './components/FirebaseAuthScreen';
import { ProfileEditorModal } from './components/ProfileEditorModal';
import { DEFAULT_LANGUAGE_CODE, normalizeLocaleCode, getSpeechLangForLocale } from './data/languages';

const STORAGE_KEYS = {
  CONVERSATIONS: 'mindgpt_conversations_v3',
  SETTINGS: 'mindgpt_settings_v3',
  ACTIVE_ID: 'mindgpt_active_id_v3',
  THEME: 'mindgpt_theme_v4',
};

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  model: 'mind-turbo-one',
  persona: 'balanced',
  soundEnabled: true,
  streamResponses: true,
  codeLineNumbers: true,
  userAvatarText: 'U',
  languagePreference: DEFAULT_LANGUAGE_CODE,
  voiceGender: 'female',
  voiceId: 'Kore',
  cloudflareWorkerUrl: '',
  accentColor: 'green',
  enterBehavior: 'newline',
  autoScroll: true,
};

// Intent detector for in-chat image generation (English, Hindi & Hinglish)
function isImageGenIntent(text: string): boolean {
  const lower = text.trim().toLowerCase();
  if (!lower) return false;

  // Exclude coding/explanatory questions about images rather than requests to generate one
  if (
    /^(what is|why|how does|how to|write (a |the )?(code|script|function|html|css|react|python|js)|explain|difference between)\b/i.test(
      lower
    )
  ) {
    return false;
  }

  return (
    /^(generate|create|make|draw|render|produce|design|illustrate|paint|sketch)\s+(?:me\s+)?(?:an?\s+|the\s+|some\s+)?(?:[a-z0-9-]+\s+){0,6}(image|picture|photo|photography|pic|poster|wallpaper|illustration|artwork|art|graphic|logo|avatar|icon|render|sketch|portrait|painting|scene|banner|sticker|map|landscape|outfit|city|character|habitat|elixir|silhouette)\b/i.test(
      lower
    ) ||
    /^(generate|draw|paint|sketch|render)\s+(an?\s+)?[a-z0-9]/i.test(lower) ||
    /^(image|picture|photo|wallpaper|poster|logo|portrait)\s+(of|for)\s+/i.test(lower) ||
    /\b(generate an? image|create an? image|make an? image|make a picture|draw a picture|create a picture|generate a photo|create a photo|generate wallpaper|create wallpaper|create a logo)\b/i.test(
      lower
    ) ||
    /(तस्वीर|चित्र|फोटो|पोस्टर|वॉलपेपर)\s*(बना|बनाओ|बनाएं|जनरेट|दिखा|दो)/i.test(text) ||
    /\b(tasveer|photo|image|pic|picture|poster|wallpaper|logo)\s*(banao|banado|bana do|generate karo|create karo)\b/i.test(
      lower
    )
  );
}

export default function App() {
  const { user, profile, authLoading, signOut, savePreferences } = useAuth();

  // Theme State
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window === 'undefined') return 'light';
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      if (saved === 'light' || saved === 'dark') return saved;
      return 'light';
    } catch {
      return 'light';
    }
  });

  // App settings (migrating any legacy 'auto' preference cleanly)
  const [settings, setSettings] = useState<AppSettings>(() => {
    if (typeof window === 'undefined') return DEFAULT_SETTINGS;
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (!saved) return DEFAULT_SETTINGS;
      const parsed = JSON.parse(saved);
      const migratedModel =
        !parsed.model || parsed.model === 'mind-turbo-5.1' ? 'mind-turbo-one' : parsed.model;
      const migratedLang = normalizeLocaleCode(parsed.languagePreference);
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        model: migratedModel,
        languagePreference: migratedLang,
        speechLanguage: getSpeechLangForLocale(migratedLang),
      };
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Conversations
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeId, setActiveId] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      return localStorage.getItem(STORAGE_KEYS.ACTIVE_ID) || null;
    } catch {
      return null;
    }
  });

  const [selectedModel, setSelectedModel] = useState<string>(() =>
    settings.model === 'mind-turbo-5.1' ? 'mind-turbo-one' : settings.model || 'mind-turbo-one'
  );
  const [isLoading, setIsLoading] = useState(false);
  const [sendingStatus, setSendingStatus] = useState<'idle' | 'sending' | 'streaming' | 'error'>('idle');
  const [sendingError, setSendingError] = useState<string | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeDrawer, setActiveDrawer] = useState<DrawerType>(null);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [showScrollBottomBtn, setShowScrollBottomBtn] = useState(false);
  const [draftPrompt, setDraftPrompt] = useState<{ text: string; nonce: number } | null>(null);
  const [libraryImages, setLibraryImages] = useState<LibraryImageRecord[]>([]);
  const [libraryLoading, setLibraryLoading] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const lastSubmittedRef = useRef<{ text: string; attachments?: Attachment[] } | null>(null);

  // Apply persisted user preferences from profile on sign-in / page reload
  useEffect(() => {
    if (!profile?.preferences) return;
    const prefs = profile.preferences;
    setSettings((prev) => {
      const nextLang = prefs.languagePreference
        ? normalizeLocaleCode(prefs.languagePreference)
        : prev.languagePreference;
      return {
        ...prev,
        languagePreference: nextLang,
        speechLanguage: getSpeechLangForLocale(nextLang),
        voiceGender: prefs.voiceGender || prev.voiceGender,
        voiceId: prefs.voiceId || prev.voiceId,
      };
    });
  }, [
    profile?.uid,
    profile?.preferences?.languagePreference,
    profile?.preferences?.voiceGender,
    profile?.preferences?.voiceId,
  ]);

  // Load UID-isolated private image library whenever authenticated user changes
  useEffect(() => {
    if (!user) {
      setLibraryImages([]);
      return;
    }
    let cancelled = false;
    setLibraryLoading(true);
    fetchUserLibraryApi()
      .then((items) => {
        if (!cancelled) setLibraryImages(items);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLibraryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user?.uid]);

  // Sync Theme to HTML Root Class & LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      setSettings((prev) => ({ ...prev, theme }));
    } catch (e) {
      console.warn('Theme synchronization failed:', e);
    }
  }, [theme]);

  // Sync Conversations to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [conversations]);

  // Sync Settings to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      if (activeId) {
        localStorage.setItem(STORAGE_KEYS.ACTIVE_ID, activeId);
      } else {
        localStorage.removeItem(STORAGE_KEYS.ACTIVE_ID);
      }
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [activeId]);

  // Global Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleNewChat();
      }
      if (e.key === 'Escape') {
        setMobileSidebarOpen(false);
        setActiveDrawer(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const scrollToBottom = (smooth = true) => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: smooth ? 'smooth' : 'auto',
      });
    }
  };

  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottomBtn(distanceToBottom > 160);
  };

  const activeConversation = conversations.find((c) => c.id === activeId);

  useEffect(() => {
    if (settings.autoScroll !== false) {
      scrollToBottom();
    }
  }, [activeConversation?.messages]);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleNewChat = () => {
    ttsEngine.stop();
    if (isLoading && abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
    setActiveId(null);
  };

  const handleDeleteConversation = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) {
      setActiveId(null);
    }
  };

  const handleRenameConversation = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  };

  const handleTogglePin = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isPinned: !c.isPinned } : c))
    );
  };

  const handleToggleLock = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isLocked: !c.isLocked } : c))
    );
  };

  const handleToggleArchive = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isArchived: !c.isArchived } : c))
    );
  };

  const handleRestoreConversation = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isArchived: false, updatedAt: Date.now() } : c))
    );
  };

  const handleClearCurrentChat = () => {
    if (!activeId) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === activeId ? { ...c, messages: [], updatedAt: Date.now() } : c))
    );
  };

  const handleClearAllConversations = () => {
    setConversations([]);
    setActiveId(null);
  };

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId);
    setSettings((prev) => ({ ...prev, model: modelId }));
  };

  // Unified Message Handler: Text Chat, Image Generation & Image Editing in one conversation
  const handleSendMessage = async (
    text: string,
    attachments?: Attachment[],
    options?: { forceImageGen?: boolean }
  ) => {
    if ((!text && (!attachments || attachments.length === 0)) || isLoading) return;

    ttsEngine.stop();
    playSendSound(settings.soundEnabled);

    let currentConversationId = activeId;
    let targetConversation = conversations.find((c) => c.id === currentConversationId);

    if (!currentConversationId || !targetConversation) {
      const generatedTitle = text.slice(0, 36) || 'New Conversation';
      const newConv: Conversation = {
        id: `conv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        title: generatedTitle,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
      };
      currentConversationId = newConv.id;
      targetConversation = newConv;
      setConversations((prev) => [newConv, ...prev]);
      setActiveId(newConv.id);
    }

    const imageAttachment = attachments?.find((a) => a.isBase64 && a.type.startsWith('image/'));
    const isEditMode = Boolean(imageAttachment && text.trim());
    const isImageRequest = Boolean(options?.forceImageGen) || (!isEditMode && isImageGenIntent(text));

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      attachments,
    };

    const assistantMessageId = `msg-ai-${Date.now() + 1}`;
    const assistantPlaceholder: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      model: selectedModel,
      isStreaming: true,
      ...(isEditMode || isImageRequest
        ? {
            imageGeneration: {
              status: 'generating' as const,
              prompt: text.trim(),
              aspectRatio: isEditMode ? 'auto' : '1:1',
              style: 'photorealistic',
              isEdit: isEditMode,
            },
          }
        : {}),
    };

    const updatedMessages = [...targetConversation.messages, userMessage, assistantPlaceholder];

    setConversations((prev) =>
      prev.map((c) =>
        c.id === currentConversationId
          ? {
              ...c,
              updatedAt: Date.now(),
              messages: updatedMessages,
            }
          : c
      )
    );

    lastSubmittedRef.current = { text, attachments };
    setSendingError(null);
    setSendingStatus('sending');
    setIsLoading(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    if (isEditMode && imageAttachment) {
      // In-chat Image Editing
      try {
        const editResult = await editImageApi(
          text.trim(),
          imageAttachment.data,
          imageAttachment.type,
          { customWorkerUrl: settings.cloudflareWorkerUrl, signal: controller.signal }
        );
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: `Edited image for **"${text.trim()}"**`,
                          isStreaming: false,
                          imageGeneration: undefined,
                          generatedImage: {
                            url: editResult.imageUrl,
                            prompt: text.trim(),
                            aspectRatio: editResult.aspectRatio || 'auto',
                            style: editResult.style || 'photorealistic',
                            provider: editResult.provider,
                            model: editResult.model,
                            isEdit: true,
                          },
                        }
                      : m
                  ),
                }
              : c
          )
        );
        playReceiveSound(settings.soundEnabled);
        saveLibraryImageApi({
          imageUrl: editResult.imageUrl,
          prompt: text.trim(),
          aspectRatio: editResult.aspectRatio,
          style: editResult.style,
          provider: editResult.provider,
          model: editResult.model,
          isEdit: true,
        })
          .then((savedRecord) => {
            if (savedRecord) {
              setLibraryImages((prev) => [savedRecord, ...prev]);
              setConversations((prev) =>
                prev.map((c) =>
                  c.id === currentConversationId
                    ? {
                        ...c,
                        messages: c.messages.map((m) =>
                          m.id === assistantMessageId && m.generatedImage
                            ? {
                                ...m,
                                generatedImage: { ...m.generatedImage, savedToLibrary: true },
                              }
                            : m
                        ),
                      }
                    : c
                )
              );
            }
          })
          .catch(() => {});
      } catch (err: any) {
        const aborted = controller.signal.aborted || err?.name === 'AbortError';
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: aborted ? 'Image editing stopped.' : '',
                          isStreaming: false,
                          imageGeneration: aborted
                            ? undefined
                            : {
                                status: 'error',
                                prompt: text.trim(),
                                aspectRatio: 'auto',
                                style: 'photorealistic',
                                isEdit: true,
                                errorMessage:
                                  err?.message || 'Image modification encountered an issue. Please try again.',
                              },
                        }
                      : m
                  ),
                }
              : c
          )
        );
      } finally {
        setIsLoading(false);
        setSendingStatus('idle');
        abortControllerRef.current = null;
      }
      return;
    }

    // Check for Image Generation intent
    if (isImageRequest) {
      try {
        const genResult = await generateImageApi(text.trim(), '1:1', 'photorealistic', {
          customWorkerUrl: settings.cloudflareWorkerUrl,
          signal: controller.signal,
        });
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: `Generated image for **"${text.trim()}"**`,
                          isStreaming: false,
                          imageGeneration: undefined,
                          generatedImage: {
                            url: genResult.imageUrl,
                            prompt: text.trim(),
                            aspectRatio: genResult.aspectRatio || '1:1',
                            style: genResult.style || 'photorealistic',
                            provider: genResult.provider,
                            model: genResult.model,
                            isEdit: false,
                          },
                        }
                      : m
                  ),
                }
              : c
          )
        );
        playReceiveSound(settings.soundEnabled);
        saveLibraryImageApi({
          imageUrl: genResult.imageUrl,
          prompt: text.trim(),
          aspectRatio: genResult.aspectRatio || '1:1',
          style: genResult.style || 'photorealistic',
          provider: genResult.provider,
          model: genResult.model,
          isEdit: false,
        })
          .then((savedRecord) => {
            if (savedRecord) {
              setLibraryImages((prev) => [savedRecord, ...prev]);
              setConversations((prev) =>
                prev.map((c) =>
                  c.id === currentConversationId
                    ? {
                        ...c,
                        messages: c.messages.map((m) =>
                          m.id === assistantMessageId && m.generatedImage
                            ? {
                                ...m,
                                generatedImage: { ...m.generatedImage, savedToLibrary: true },
                              }
                            : m
                        ),
                      }
                    : c
                )
              );
            }
          })
          .catch(() => {});
      } catch (err: any) {
        const aborted = controller.signal.aborted || err?.name === 'AbortError';
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: aborted ? 'Image generation stopped.' : '',
                          isStreaming: false,
                          imageGeneration: aborted
                            ? undefined
                            : {
                                status: 'error',
                                prompt: text.trim(),
                                aspectRatio: '1:1',
                                style: 'photorealistic',
                                isEdit: false,
                                errorMessage:
                                  err?.message || 'Failed to generate image. Please try again.',
                              },
                        }
                      : m
                  ),
                }
              : c
          )
        );
      } finally {
        setIsLoading(false);
        setSendingStatus('idle');
        abortControllerRef.current = null;
      }
      return;
    }

    // Normal Text Chat Streaming with Multi-turn Context
    const historyPayload = [...targetConversation.messages, userMessage]
      .filter((m) => !m.error && (m.content.trim().length > 0 || (m.attachments && m.attachments.length > 0)))
      .map((m) => ({
        role: m.role,
        content: m.content,
        attachments: m.attachments,
      }));

    let accumulatedContent = '';

    await streamChatMessage({
      messages: historyPayload,
      settings: { ...settings, model: selectedModel },
      signal: controller.signal,
      onSearchStatus: (searchStatus: string) => {
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId ? { ...m, searchStatus } : m
                  ),
                }
              : c
          )
        );
      },
      onGroundingSources: (groundingSources: Array<{ title: string; uri: string }>) => {
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId ? { ...m, groundingSources, searchStatus: undefined } : m
                  ),
                }
              : c
          )
        );
      },
      onChunk: (chunk: string) => {
        setSendingStatus('streaming');
        accumulatedContent += chunk;
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? { ...m, content: accumulatedContent, isStreaming: true, searchStatus: undefined }
                      : m
                  ),
                }
              : c
          )
        );
        if (settings.autoScroll !== false) {
          scrollToBottom();
        }
      },
      onError: (errMessage: string) => {
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content: errMessage,
                          error: true,
                          isStreaming: false,
                          searchStatus: undefined,
                        }
                      : m
                  ),
                }
              : c
          )
        );
        setSendingStatus('error');
        setSendingError(errMessage);
        setIsLoading(false);
      },
      onDone: () => {
        playReceiveSound(settings.soundEnabled);
        setConversations((prev) =>
          prev.map((c) =>
            c.id === currentConversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? { ...m, isStreaming: false, searchStatus: undefined }
                      : m
                  ),
                }
              : c
          )
        );
        setSendingStatus('idle');
        setSendingError(null);
        setIsLoading(false);
        abortControllerRef.current = null;
      },
    });
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setSendingStatus('idle');
    setIsLoading(false);
  };

  const handleRegenerate = () => {
    if (!activeConversation || activeConversation.messages.length < 2) return;
    const msgs = [...activeConversation.messages];
    let lastUserIndex = -1;
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }
    if (lastUserIndex === -1) return;

    const userMsg = msgs[lastUserIndex];
    const sliced = msgs.slice(0, lastUserIndex);
    setConversations((prev) =>
      prev.map((c) => (c.id === activeConversation.id ? { ...c, messages: sliced } : c))
    );

    setTimeout(() => {
      handleSendMessage(userMsg.content, userMsg.attachments);
    }, 50);
  };

  const handleEditPrompt = (newPrompt: string) => {
    handleSendMessage(newPrompt);
  };

  const handleEditImageInChat = (imagePrompt: string) => {
    void handleSendMessage(`Modify this image: ${imagePrompt}`, undefined, { forceImageGen: true });
  };

  const handleRetryImageGeneration = async (messageId: string, prompt: string, isEdit?: boolean) => {
    if (!activeId || isLoading) return;
    const targetConvId = activeId;
    const conv = conversations.find((c) => c.id === targetConvId);
    if (!conv) return;

    // Look for attached source image if retrying an edit
    const msgIdx = conv.messages.findIndex((m) => m.id === messageId);
    const prevUserMsg = msgIdx > 0 ? conv.messages[msgIdx - 1] : undefined;
    const sourceAttachment = isEdit
      ? prevUserMsg?.attachments?.find((a) => a.isBase64 && a.type.startsWith('image/'))
      : undefined;

    setIsLoading(true);
    setSendingError(null);
    setSendingStatus('sending');
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setConversations((prev) =>
      prev.map((c) =>
        c.id === targetConvId
          ? {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId
                  ? {
                      ...m,
                      content: '',
                      error: false,
                      isStreaming: true,
                      imageGeneration: {
                        status: 'generating',
                        prompt,
                        aspectRatio: isEdit ? 'auto' : '1:1',
                        style: 'photorealistic',
                        isEdit,
                      },
                    }
                  : m
              ),
            }
          : c
      )
    );

    try {
      const result =
        isEdit && sourceAttachment
          ? await editImageApi(prompt, sourceAttachment.data, sourceAttachment.type, {
              customWorkerUrl: settings.cloudflareWorkerUrl,
              signal: controller.signal,
            })
          : await generateImageApi(prompt, '1:1', 'photorealistic', {
              customWorkerUrl: settings.cloudflareWorkerUrl,
              signal: controller.signal,
            });

      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId
                    ? {
                        ...m,
                        content: isEdit ? `Edited image for **"${prompt}"**` : `Generated image for **"${prompt}"**`,
                        isStreaming: false,
                        imageGeneration: undefined,
                        generatedImage: {
                          url: result.imageUrl,
                          prompt,
                          aspectRatio: result.aspectRatio || '1:1',
                          style: result.style || 'photorealistic',
                          provider: result.provider,
                          model: result.model,
                          isEdit: Boolean(isEdit),
                        },
                      }
                    : m
                ),
              }
            : c
        )
      );
      playReceiveSound(settings.soundEnabled);
      saveLibraryImageApi({
        imageUrl: result.imageUrl,
        prompt,
        aspectRatio: result.aspectRatio,
        style: result.style,
        provider: result.provider,
        model: result.model,
        isEdit: Boolean(isEdit),
      })
        .then((savedRecord) => {
          if (savedRecord) {
            setLibraryImages((prev) => [savedRecord, ...prev]);
            setConversations((prev) =>
              prev.map((c) =>
                c.id === targetConvId
                  ? {
                      ...c,
                      messages: c.messages.map((m) =>
                        m.id === messageId && m.generatedImage
                          ? { ...m, generatedImage: { ...m.generatedImage, savedToLibrary: true } }
                          : m
                      ),
                    }
                  : c
              )
            );
          }
        })
        .catch(() => {});
    } catch (err: any) {
      const aborted = controller.signal.aborted || err?.name === 'AbortError';
      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId
                    ? {
                        ...m,
                        content: aborted ? 'Image generation stopped.' : '',
                        isStreaming: false,
                        imageGeneration: aborted
                          ? undefined
                          : {
                              status: 'error',
                              prompt,
                              aspectRatio: isEdit ? 'auto' : '1:1',
                              style: 'photorealistic',
                              isEdit,
                              errorMessage: err?.message || 'Image generation retry failed.',
                            },
                      }
                    : m
                ),
              }
            : c
        )
      );
    } finally {
      setIsLoading(false);
      setSendingStatus('idle');
      abortControllerRef.current = null;
    }
  };

  const handleSaveGeneratedImage = async (messageId: string) => {
    if (!activeId) return;
    const conv = conversations.find((c) => c.id === activeId);
    const msg = conv?.messages.find((m) => m.id === messageId);
    if (!msg?.generatedImage || msg.generatedImage.savedToLibrary) return;

    const savedRecord = await saveLibraryImageApi({
      imageUrl: msg.generatedImage.url,
      prompt: msg.generatedImage.prompt,
      aspectRatio: msg.generatedImage.aspectRatio,
      style: msg.generatedImage.style,
      provider: msg.generatedImage.provider,
      model: msg.generatedImage.model,
      isEdit: msg.generatedImage.isEdit,
    }).catch(() => null);

    if (savedRecord) {
      setLibraryImages((prev) => [savedRecord, ...prev]);
      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId && m.generatedImage
                    ? { ...m, generatedImage: { ...m.generatedImage, savedToLibrary: true } }
                    : m
                ),
              }
            : c
        )
      );
    }
  };

  const handleGenerateFromGallery = (promptText: string) => {
    setActiveDrawer(null);
    setMobileSidebarOpen(false);
    void handleSendMessage(promptText, undefined, { forceImageGen: true });
  };

  const handleUsePromptInNewChat = (promptText: string) => {
    ttsEngine.stop();
    if (isLoading && abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
    setActiveId(null);
    setActiveDrawer(null);
    setMobileSidebarOpen(false);
    setDraftPrompt({ text: promptText, nonce: Date.now() });
  };

  const handleToggleLibraryFavorite = async (id: string) => {
    const updated = await toggleLibraryFavoriteApi(id);
    if (updated) {
      setLibraryImages((prev) => prev.map((img) => (img.id === id ? updated : img)));
    }
  };

  const handleDeleteLibraryImage = async (id: string) => {
    const ok = await deleteLibraryImageApi(id);
    if (ok) {
      setLibraryImages((prev) => prev.filter((img) => img.id !== id));
    }
  };

  const handleLogout = async () => {
    ttsEngine.stop();
    if (isLoading && abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
    setActiveDrawer(null);
    setMobileSidebarOpen(false);
    await signOut();
  };

  if (authLoading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-white dark:bg-[#07090e] text-slate-800 dark:text-slate-100 gap-4">
        <div className="w-12 h-12 rounded-2xl overflow-hidden bg-black border border-purple-500/40 shadow-lg flex items-center justify-center">
          <img src="/mindgpt-badge.png" alt="MindGPT" className="w-full h-full object-contain" />
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
          <span>Verifying MindGPT session...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <FirebaseAuthScreen />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-white dark:bg-[#07090e] text-slate-900 dark:text-slate-100 font-sans transition-colors">
      {/* Sidebar Navigation */}
      <Sidebar
        conversations={conversations}
        activeConversationId={activeId}
        onSelectConversation={(id) => setActiveId(id)}
        onNewChat={handleNewChat}
        onDeleteConversation={handleDeleteConversation}
        onRenameConversation={handleRenameConversation}
        onTogglePinConversation={handleTogglePin}
        onToggleLockConversation={handleToggleLock}
        onToggleArchiveConversation={handleToggleArchive}
        onOpenDrawer={(type) => setActiveDrawer(type)}
        isMobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        userNickname={settings.userNickname}
        firebaseUser={user}
        userProfile={profile}
        onOpenProfile={() => setProfileModalOpen(true)}
        onSignOut={handleLogout}
        libraryCount={libraryImages.length}
      />

      {/* Main Unified Chat Interface */}
      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        {/* Top Header */}
        <Header
          settings={settings}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
          onNewChat={handleNewChat}
          onClearCurrentChat={handleClearCurrentChat}
          onOpenSettings={() => setActiveDrawer('settings')}
          onToggleTheme={handleToggleTheme}
          hasMessages={Boolean(activeConversation && activeConversation.messages.length > 0)}
        />

        {/* Conversation View */}
        <div className="flex-1 flex flex-col min-h-0 relative">
          {/* Messages Scroll Area */}
          <div
            ref={chatContainerRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto px-2 sm:px-4 py-3 scroll-smooth"
          >
            {!activeConversation || activeConversation.messages.length === 0 ? (
              <WelcomeScreen
                onSelectPrompt={(prompt) => handleSendMessage(prompt)}
                onNewChat={handleNewChat}
                onTriggerImagePrompt={() => handleSendMessage('Create a cinematic 3D wallpaper of a futuristic neon city')}
                onUploadFiles={() => {}}
                onVoiceInput={() => {}}
              />
            ) : (
              <div className="max-w-3xl mx-auto w-full pb-4">
                {activeConversation.messages.map((message, index) => (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    isLast={index === activeConversation.messages.length - 1}
                    onRegenerate={handleRegenerate}
                    onEditPrompt={handleEditPrompt}
                    onEditImageInChat={handleEditImageInChat}
                    onRetryImageGeneration={(msgId, prompt, isEdit) =>
                      void handleRetryImageGeneration(msgId, prompt, isEdit)
                    }
                    onSaveGeneratedImage={(msgId) => void handleSaveGeneratedImage(msgId)}
                    languagePreference={settings.languagePreference}
                    voiceGender={settings.voiceGender || 'female'}
                    voiceId={settings.voiceId}
                    accentColor={settings.accentColor || 'green'}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Scroll to latest button */}
          {showScrollBottomBtn && (
            <button
              type="button"
              onClick={() => scrollToBottom(true)}
              className="absolute right-6 bottom-28 z-20 p-2 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 shadow-lg hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer animate-fadeIn"
              title="Scroll to latest message"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          )}

          {/* Message Input Box with Unified Plus Menu, Voice Dictation, and Model Selector */}
          <ChatInput
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            sendingStatus={sendingStatus}
            sendingError={sendingError}
            onRetryLastSend={() => {
              if (lastSubmittedRef.current) {
                void handleSendMessage(
                  lastSubmittedRef.current.text,
                  lastSubmittedRef.current.attachments
                );
              }
            }}
            onStopGeneration={handleStopGeneration}
            disabled={false}
            selectedModel={selectedModel}
            onSelectModel={handleSelectModel}
            languagePreference={settings.languagePreference}
            enterBehavior={settings.enterBehavior || 'newline'}
            draftPrompt={draftPrompt}
          />
        </div>
      </main>

      {/* Slide-out Full-Height Navigation Drawer (Images Gallery, User Library, Profile, Complete Settings, Archived) */}
      <NavigationDrawer
        type={activeDrawer}
        isOpen={activeDrawer !== null}
        onClose={() => setActiveDrawer(null)}
        settings={settings}
        onUpdateSettings={(newVals) => {
          if (newVals.theme && newVals.theme !== theme) {
            setTheme(newVals.theme);
          }
          setSettings((prev) => {
            const merged = { ...prev, ...newVals };
            if (
              newVals.languagePreference !== undefined ||
              newVals.voiceGender !== undefined ||
              newVals.voiceId !== undefined
            ) {
              void savePreferences({
                languagePreference: normalizeLocaleCode(merged.languagePreference),
                voiceGender: merged.voiceGender,
                voiceId: merged.voiceId,
              });
            }
            return merged;
          });
        }}
        conversations={conversations}
        onSelectConversation={(id) => {
          setActiveId(id);
          setActiveDrawer(null);
        }}
        onClearAllConversations={handleClearAllConversations}
        onRestoreConversation={handleRestoreConversation}
        onUsePromptInNewChat={handleUsePromptInNewChat}
        onGenerateFromGallery={handleGenerateFromGallery}
        onSwitchDrawer={(nextType) => setActiveDrawer(nextType)}
        firebaseUser={user}
        userProfile={profile}
        onOpenProfileEditor={() => setProfileModalOpen(true)}
        onSignOut={handleLogout}
        libraryImages={libraryImages}
        libraryLoading={libraryLoading}
        onToggleLibraryFavorite={handleToggleLibraryFavorite}
        onDeleteLibraryImage={handleDeleteLibraryImage}
      />

      {/* Focused Profile & Avatar Editor Modal */}
      <ProfileEditorModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
        onSignOut={handleLogout}
      />
    </div>
  );
}

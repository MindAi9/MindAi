import { useState, useEffect, useRef, useCallback } from 'react';
import { getSpeechLangForLocale } from '../data/languages';

interface UseSpeechRecognitionProps {
  onTranscriptChange?: (text: string) => void;
  onFinalTranscript?: (text: string) => void;
  preferredLanguage?: string;
}

export function useSpeechRecognition({
  onTranscriptChange,
  onFinalTranscript,
  preferredLanguage = 'en-US',
}: UseSpeechRecognitionProps = {}) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const activeLang = getSpeechLangForLocale(preferredLanguage);

  const recognitionRef = useRef<any>(null);
  const onTranscriptChangeRef = useRef(onTranscriptChange);
  const onFinalTranscriptRef = useRef(onFinalTranscript);
  const isListeningRef = useRef(false);

  useEffect(() => {
    onTranscriptChangeRef.current = onTranscriptChange;
  }, [onTranscriptChange]);

  useEffect(() => {
    onFinalTranscriptRef.current = onFinalTranscript;
  }, [onFinalTranscript]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setIsSupported(false);
      return;
    }

    setIsSupported(true);
    const recognition = new SpeechRecognitionClass();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = activeLang;

    recognition.onresult = (event: any) => {
      let currentSessionText = '';
      for (let i = 0; i < event.results.length; i++) {
        currentSessionText += event.results[i][0].transcript;
      }
      setTranscript(currentSessionText);
      onTranscriptChangeRef.current?.(currentSessionText);

      const lastResult = event.results[event.results.length - 1];
      if (lastResult?.isFinal) {
        onFinalTranscriptRef.current?.(lastResult[0].transcript);
      }
    };

    recognition.onerror = (event: any) => {
      const code = event?.error || 'unknown';
      const inAndroidWebView =
        typeof navigator !== 'undefined' && /;\s*wv\)|Android.*Version\//i.test(navigator.userAgent);

      if (code === 'not-allowed' || code === 'permission-denied' || code === 'service-not-allowed') {
        setError(
          inAndroidWebView
            ? 'Microphone permission was denied in this app WebView. Enable RECORD_AUDIO in Android App Settings > Permissions > Microphone and allow audio permission requests.'
            : 'Microphone permission is blocked. Click the site settings icon beside the address bar, set Microphone to Allow, and try again.'
        );
      } else if (code === 'audio-capture') {
        setError('No working microphone was detected or another app is currently using it.');
      } else if (code === 'no-speech') {
        // Ignore harmless pause when user has not started speaking yet
      } else if (code === 'network') {
        setError('Speech service network error. Check your internet connection.');
      } else if (code !== 'aborted') {
        setError(`Voice input error: ${code}`);
      }

      isListeningRef.current = false;
      setIsListening(false);
    };

    recognition.onend = () => {
      isListeningRef.current = false;
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.onresult = null;
        recognition.onerror = null;
        recognition.onend = null;
        recognition.abort();
      } catch {}
    };
  }, [activeLang]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const startListening = useCallback(async () => {
    setError(null);
    setTranscript('');

    if (typeof window !== 'undefined' && !window.isSecureContext) {
      setError('Voice input requires a secure HTTPS connection.');
      return;
    }

    const inAndroidWebView =
      typeof navigator !== 'undefined' && /;\s*wv\)|Android.*Version\//i.test(navigator.userAgent);

    if (!recognitionRef.current) {
      setError(
        inAndroidWebView
          ? 'Speech recognition is unavailable inside this Android WebView. Use Google Chrome or enable Android Speech Services in your WebView build.'
          : 'Speech recognition is not supported in this browser. Try Google Chrome or Microsoft Edge for voice dictation.'
      );
      return;
    }

    // Check current browser permission state if supported
    let permissionState: PermissionState | 'unknown' = 'unknown';
    try {
      if (navigator.permissions && navigator.permissions.query) {
        const status = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        permissionState = status.state;
        if (status.state === 'denied') {
          setError(
            inAndroidWebView
              ? 'Microphone access is blocked in the app WebView. Open Android App Settings > Permissions > Microphone and allow access.'
              : 'Microphone permission is blocked in browser site settings. Set Microphone to Allow beside the URL bar and tap the mic again.'
          );
          return;
        }
      }
    } catch {
      // Permissions API may not support 'microphone' in all browsers/WebViews
    }

    // Trigger genuine browser / iframe / Android WebView runtime mic prompt before recognition starts,
    // then immediately stop all media tracks so Android/Chromium does not suffer a hardware stream lock.
    if (permissionState !== 'granted' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (permErr: any) {
        const name = permErr?.name || '';
        const msg = String(permErr?.message || '').toLowerCase();
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || msg.includes('denied') || msg.includes('not allowed')) {
          setError(
            inAndroidWebView
              ? 'Microphone access was denied by Android or WebView. Allow Microphone permission in App Settings and try again.'
              : 'Microphone access was denied. Allow Microphone permission when prompted (or in Site Settings) and tap again.'
          );
          return;
        }
        if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
          setError('No microphone device was found on this device.');
          return;
        }
        // Other benign getUserMedia failures can fall through cleanly to SpeechRecognition.start()
      }
    }

    try {
      if (isListeningRef.current) {
        recognitionRef.current.stop();
      }
      recognitionRef.current.lang = activeLang;
      recognitionRef.current.start();
      isListeningRef.current = true;
      setIsListening(true);
    } catch (err: any) {
      const name = err?.name || '';
      const msg = String(err?.message || '');
      if (name === 'NotAllowedError' || msg.toLowerCase().includes('not-allowed')) {
        setError(
          'Microphone permission was denied. Allow microphone access in browser or device permissions and try again.'
        );
      } else if (name === 'InvalidStateError') {
        isListeningRef.current = true;
        setIsListening(true);
      } else {
        setError('Could not start microphone listening. Please verify browser microphone permissions.');
      }
    }
  }, [activeLang]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    isListeningRef.current = false;
    setIsListening(false);
  }, []);

  const toggleListening = useCallback(() => {
    if (isListeningRef.current) {
      stopListening();
    } else {
      void startListening();
    }
  }, [startListening, stopListening]);

  return {
    isListening,
    transcript,
    isSupported,
    error,
    clearError,
    activeLang,
    startListening,
    stopListening,
    toggleListening,
  };
}

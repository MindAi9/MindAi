import { useState, useEffect, useCallback } from 'react';
import { ttsEngine, TTSState } from '../utils/tts';

export function useTTS() {
  const [ttsState, setTtsState] = useState<TTSState>(() => ttsEngine.getState());

  useEffect(() => {
    const unsubscribe = ttsEngine.subscribe((newState) => {
      setTtsState(newState);
    });
    return unsubscribe;
  }, []);

  const play = useCallback(
    async (
      messageId: string,
      text: string,
      options: {
        languagePreference: string;
        gender: 'male' | 'female';
        voiceId?: string;
      }
    ) => {
      await ttsEngine.play(messageId, text, options);
    },
    []
  );

  const pause = useCallback(() => {
    ttsEngine.pause();
  }, []);

  const resume = useCallback(() => {
    ttsEngine.resume();
  }, []);

  const stop = useCallback(() => {
    ttsEngine.stop();
  }, []);

  return {
    currentMessageId: ttsState.currentMessageId,
    status: ttsState.status,
    isPlaying: ttsState.status === 'playing',
    isPaused: ttsState.status === 'paused',
    isLoading: ttsState.status === 'loading',
    ttsSource: ttsState.provider,
    voiceName: ttsState.voiceName,
    notice: ttsState.notice,
    chunkIndex: ttsState.chunkIndex,
    totalChunks: ttsState.totalChunks,
    play,
    pause,
    resume,
    stop,
    isSupported: ttsEngine.isSupported(),
  };
}

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  FirebaseUser,
  UserProfileRecord,
  UserPreferencesRecord,
  subscribeToFirebaseAuth,
  signInWithGooglePopup,
  checkGoogleRedirectResult,
  signOutFromFirebase,
  mapFirebaseAuthError,
  syncOrLoadUserProfile,
  saveUserProfileRecord,
  saveUserPreferencesRecord,
  uploadUserAvatarImage,
  buildDefaultProfileFromUser,
} from '../services/firebase';

interface AuthContextValue {
  user: FirebaseUser | null;
  profile: UserProfileRecord | null;
  authLoading: boolean;
  profileLoading: boolean;
  actionLoading: boolean;
  authError: string | null;
  firestoreStatus: 'synced' | 'rules-pending' | 'unavailable';
  firestoreMessage?: string;
  isNewUserSession: boolean;
  signInWithGoogle: () => Promise<boolean>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  saveProfile: (updates: {
    displayName: string;
    username: string;
    photoURL: string;
    avatarType: 'google' | 'preset' | 'color' | 'upload';
    avatarId?: string;
    avatarBg?: string;
  }) => Promise<UserProfileRecord>;
  savePreferences: (prefs: UserPreferencesRecord) => Promise<void>;
  uploadAvatar: (file: File) => Promise<string>;
  clearAuthError: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfileRecord | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [profileLoading, setProfileLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [firestoreStatus, setFirestoreStatus] = useState<'synced' | 'rules-pending' | 'unavailable'>('unavailable');
  const [firestoreMessage, setFirestoreMessage] = useState<string | undefined>(undefined);
  const [isNewUserSession, setIsNewUserSession] = useState(false);

  const loadProfileForUser = useCallback(async (firebaseUser: FirebaseUser) => {
    setProfileLoading(true);
    try {
      const result = await syncOrLoadUserProfile(firebaseUser);
      setProfile(result.profile);
      setFirestoreStatus(result.firestoreStatus);
      setFirestoreMessage(result.firestoreMessage);
    } catch (err) {
      console.warn('Failed syncing user profile:', err);
      setProfile((prev) => prev || buildDefaultProfileFromUser(firebaseUser));
    } finally {
      setProfileLoading(false);
    }
  }, []);

  useEffect(() => {
    // Handle any pending redirect login result cleanly
    checkGoogleRedirectResult()
      .then((res) => {
        if (res?.user) {
          setUser(res.user);
          setIsNewUserSession(res.isNewUser);
        }
      })
      .catch(() => {});

    const unsubscribe = subscribeToFirebaseAuth((firebaseUser) => {
      setUser(firebaseUser);
      setAuthLoading(false);
      if (firebaseUser) {
        loadProfileForUser(firebaseUser);
      } else {
        setProfile(null);
        setIsNewUserSession(false);
        setFirestoreStatus('unavailable');
        setFirestoreMessage(undefined);
      }
    });
    return () => unsubscribe();
  }, [loadProfileForUser]);

  const signInWithGoogle = useCallback(async (): Promise<boolean> => {
    setAuthError(null);
    setActionLoading(true);
    try {
      const result = await signInWithGooglePopup();
      // Immediately update auth user so MindGPT chat opens without waiting for background profile sync
      setUser(result.user);
      setIsNewUserSession(result.isNewUser);
      setProfile((prev) => prev || buildDefaultProfileFromUser(result.user));
      void loadProfileForUser(result.user);
      return true;
    } catch (err: any) {
      setAuthError(mapFirebaseAuthError(err));
      return false;
    } finally {
      setActionLoading(false);
    }
  }, [loadProfileForUser]);

  const signOut = useCallback(async () => {
    setAuthError(null);
    setActionLoading(true);
    try {
      await signOutFromFirebase();
      setUser(null);
      setProfile(null);
      setIsNewUserSession(false);
    } catch (err: any) {
      setAuthError(mapFirebaseAuthError(err));
    } finally {
      setActionLoading(false);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!user) return;
    await loadProfileForUser(user);
  }, [user, loadProfileForUser]);

  const saveProfile = useCallback(
    async (updates: {
      displayName: string;
      username: string;
      photoURL: string;
      avatarType: 'google' | 'preset' | 'color' | 'upload';
      avatarId?: string;
      avatarBg?: string;
    }): Promise<UserProfileRecord> => {
      if (!user) {
        throw new Error('You must be signed in to update your profile.');
      }
      const res = await saveUserProfileRecord(user, updates);
      setProfile(res.profile);
      setFirestoreStatus(res.firestoreStatus);
      setFirestoreMessage(res.firestoreMessage);
      return res.profile;
    },
    [user]
  );

  const savePreferences = useCallback(
    async (prefs: UserPreferencesRecord): Promise<void> => {
      if (!user) return;
      const savedPrefs = await saveUserPreferencesRecord(user, prefs);
      setProfile((prev) =>
        prev
          ? {
              ...prev,
              preferences: { ...(prev.preferences || {}), ...savedPrefs },
              updatedAt: new Date().toISOString(),
            }
          : prev
      );
    },
    [user]
  );

  const uploadAvatar = useCallback(async (file: File): Promise<string> => {
    return await uploadUserAvatarImage(file);
  }, []);

  const clearAuthError = useCallback(() => {
    setAuthError(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        authLoading,
        profileLoading,
        actionLoading,
        authError,
        firestoreStatus,
        firestoreMessage,
        isNewUserSession,
        signInWithGoogle,
        signOut,
        refreshProfile,
        saveProfile,
        savePreferences,
        uploadAvatar,
        clearAuthError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}

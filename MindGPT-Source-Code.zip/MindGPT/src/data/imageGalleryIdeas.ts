import cinematicPortraitImg from '../assets/images/cinematic_portrait_1794740024127.jpg';
import cinematicPhotographyImg from '../assets/images/cinematic_photography_1794839208920.jpg';
import animeCharacterImg from '../assets/images/anime_character_1794740024079.jpg';
import indianTraditionalOutfitImg from '../assets/images/indian_traditional_outfit_1794740024896.jpg';
import tirangaOutfitImg from '../assets/images/tiranga_outfit_1794740025566.jpg';
import ancientRomeMapImg from '../assets/images/ancient_rome_map_1794740025223.jpg';
import fantasyLandscapeImg from '../assets/images/fantasy_landscape_1794740026543.jpg';
import mountainLandscapeImg from '../assets/images/mountain_landscape_1794839209398.jpg';
import threeDStickerImg from '../assets/images/three_d_sticker_1794740026571.jpg';
import threeDArtImg from '../assets/images/three_d_art_1794839209450.jpg';
import productPhotographyImg from '../assets/images/product_photography_1794740026236.jpg';
import futuristicCityImg from '../assets/images/futuristic_city_1794740027468.jpg';
import professionalPosterImg from '../assets/images/professional_poster_1794740027418.jpg';

export interface ImageGalleryIdea {
  id: string;
  title: string;
  category: string;
  description: string;
  prompt: string;
  previewImageUrl: string;
  gradientFrom: string;
  gradientTo: string;
  accentColor: string;
  artworkType:
    | 'stickers'
    | 'cinema'
    | 'map'
    | 'anime'
    | 'tiranga'
    | 'character3d'
    | 'fantasy'
    | 'product'
    | 'poster'
    | 'architecture'
    | 'portrait'
    | 'landscape';
}

export const IMAGE_GALLERY_CATEGORIES = [
  'All Images',
  'Cinematic Photography',
  'Portraits',
  'Anime',
  '3D Art',
  'Stickers',
  'Indian Traditional Fashion',
  'Product Photography',
  'Architecture',
  'Fantasy',
  'Posters',
  'Landscapes',
] as const;

export const CURATED_IMAGE_IDEAS: ImageGalleryIdea[] = [
  {
    id: 'idea-cinematic-photography',
    title: 'Neon Rain Street Frame',
    category: 'Cinematic Photography',
    description: 'Anamorphic 35mm night street shot with wet asphalt reflections and teal-amber film grain.',
    prompt:
      'Create a cinematic 35mm wide-angle film photograph of a rain-slicked neon night street, glowing signage reflecting in puddles, warm tungsten cafe light contrasting cool teal shadows, anamorphic lens bokeh',
    previewImageUrl: cinematicPhotographyImg,
    gradientFrom: '#0f172a',
    gradientTo: '#0e7490',
    accentColor: '#fde68a',
    artworkType: 'cinema',
  },
  {
    id: 'idea-cinematic-portrait',
    title: 'Golden Hour Portrait',
    category: 'Portraits',
    description: 'Editorial close-up portrait bathed in warm sunset rim light with shallow 85mm depth.',
    prompt:
      'Create a cinematic editorial portrait illuminated by golden hour sunlight casting warm amber rim light and natural shallow 85mm depth of field, ultra-sharp film photography look',
    previewImageUrl: cinematicPortraitImg,
    gradientFrom: '#6d28d9',
    gradientTo: '#be185d',
    accentColor: '#f5d0fe',
    artworkType: 'portrait',
  },
  {
    id: 'idea-anime-character',
    title: 'Sunset Sky Traveler',
    category: 'Anime',
    description: 'Painterly twilight rooftop character illustration with luminous clouds and crisp cel shading.',
    prompt:
      'Create high-detail anime character art of a serene traveler on a rooftop at golden hour sunset above shimmering city lights, luminous cumulus clouds, crisp cel shading and rich painterly brushwork',
    previewImageUrl: animeCharacterImg,
    gradientFrom: '#7c3aed',
    gradientTo: '#ec4899',
    accentColor: '#fed7aa',
    artworkType: 'anime',
  },
  {
    id: 'idea-3d-art',
    title: 'Obsidian & Glass Sculpture',
    category: '3D Art',
    description: 'Studio octane 3D render of iridescent glass ribbons and brushed brass orbiting geometry.',
    prompt:
      'Create a museum-grade 3D abstract sculptural render featuring smooth translucent dichroic glass ribbons, brushed satin brass spheres, and matte slate pedestals under soft rim lighting',
    previewImageUrl: threeDArtImg,
    gradientFrom: '#312e81',
    gradientTo: '#0f766e',
    accentColor: '#99f6e4',
    artworkType: 'character3d',
  },
  {
    id: 'idea-3d-sticker',
    title: 'Cosmic Explorer Sticker',
    category: 'Stickers',
    description: 'Glossy die-cut 3D vinyl sticker character with clean white contour border and soft glow.',
    prompt:
      'Create a cute 3D die-cut vinyl sticker of a miniature cosmic fox explorer with glossy clay textures, thick crisp white sticker border, clean studio backdrop',
    previewImageUrl: threeDStickerImg,
    gradientFrom: '#f43f5e',
    gradientTo: '#fb923c',
    accentColor: '#fef08a',
    artworkType: 'stickers',
  },
  {
    id: 'idea-indian-traditional-outfit',
    title: 'Royal Zari Couture',
    category: 'Indian Traditional Fashion',
    description: 'Handwoven royal silk ensemble with intricate gold zari embroidery in a heritage archway.',
    prompt:
      'Create a high-fashion editorial portrait showcasing a regal Indian traditional outfit crafted from royal silk with intricate gold zari embroidery, sandstone palace archway backdrop, soft studio lighting',
    previewImageUrl: indianTraditionalOutfitImg,
    gradientFrom: '#9a3412',
    gradientTo: '#b45309',
    accentColor: '#fde68a',
    artworkType: 'portrait',
  },
  {
    id: 'idea-tiranga-outfit',
    title: 'Saffron & Khadi Lookbook',
    category: 'Indian Traditional Fashion',
    description: 'Modern handloom couture blending saffron silk, crisp ivory khadi drape, and emerald green trim.',
    prompt:
      'Create a high-fashion editorial portrait showcasing a modern Indian handloom couture outfit woven from warm saffron silk, crisp ivory khadi cotton drape, and deep emerald green woven borders',
    previewImageUrl: tirangaOutfitImg,
    gradientFrom: '#ea580c',
    gradientTo: '#15803d',
    accentColor: '#f8fafc',
    artworkType: 'tiranga',
  },
  {
    id: 'idea-product-photography',
    title: 'Titanium Audio Studio',
    category: 'Product Photography',
    description: 'Commercial macro still life of matte titanium headphones resting on sculpted travertine.',
    prompt:
      'Create ultra-sharp commercial product photography of matte titanium wireless over-ear headphones resting on a sculpted travertine stone pedestal, warm directional key light, subtle caustic shadows',
    previewImageUrl: productPhotographyImg,
    gradientFrom: '#334155',
    gradientTo: '#64748b',
    accentColor: '#e2e8f0',
    artworkType: 'product',
  },
  {
    id: 'idea-futuristic-city',
    title: 'Biophilic Skyline at Dusk',
    category: 'Architecture',
    description: 'Terraced glass towers, hanging sky gardens, and calm waterfront reflections at twilight.',
    prompt:
      'Create an architectural wide photograph of a futuristic biophilic glass city skyline at twilight with sweeping vertical gardens, glowing skybridges, and calm canal reflections',
    previewImageUrl: futuristicCityImg,
    gradientFrom: '#0f766e',
    gradientTo: '#0284c7',
    accentColor: '#bae6fd',
    artworkType: 'architecture',
  },
  {
    id: 'idea-fantasy-landscape',
    title: 'Floating Emerald Citadel',
    category: 'Fantasy',
    description: 'Skyward stone bridges linking mossy cliffs above golden clouds and cascading falls.',
    prompt:
      'Create an epic fantasy landscape painting of floating emerald cliffside islands connected by ancient stone bridges, silver waterfalls plunging into golden clouds below, volumetric god rays',
    previewImageUrl: fantasyLandscapeImg,
    gradientFrom: '#065f46',
    gradientTo: '#1d4ed8',
    accentColor: '#a7f3d0',
    artworkType: 'fantasy',
  },
  {
    id: 'idea-professional-poster',
    title: 'Swiss Modernist Exhibition',
    category: 'Posters',
    description: 'Crisp geometric exhibition print using vermilion and charcoal ink on archival paper.',
    prompt:
      'Create a bold Swiss modernist poster design with balanced interlocking vermilion red and deep obsidian geometric forms on textured cream archival paper, crisp editorial layout',
    previewImageUrl: professionalPosterImg,
    gradientFrom: '#991b1b',
    gradientTo: '#18181b',
    accentColor: '#fca5a5',
    artworkType: 'poster',
  },
  {
    id: 'idea-ancient-rome-map',
    title: 'Ancient Rome Parchment Print',
    category: 'Posters',
    description: 'Detailed antique engraved parchment chart showing the Tiber River, Colosseum, and Forum.',
    prompt:
      'Create a highly detailed vintage parchment cartographic poster map of Ancient Rome around 117 AD, illustrating the curving Tiber River, Colosseum, Circus Maximus, aqueducts, compass rose, and sepia ink engraving style',
    previewImageUrl: ancientRomeMapImg,
    gradientFrom: '#78350f',
    gradientTo: '#b45309',
    accentColor: '#fde68a',
    artworkType: 'map',
  },
  {
    id: 'idea-mountain-landscape',
    title: 'Alpine Dawn Ridge',
    category: 'Landscapes',
    description: 'First rose-gold sunlight touching jagged granite peaks above a mirror-calm glacier lake.',
    prompt:
      'Create a crisp wide landscape photograph of jagged snow-dusted alpine granite peaks illuminated by first rose-gold sunrise light above a still mirror-reflective glacial valley lake, morning mist',
    previewImageUrl: mountainLandscapeImg,
    gradientFrom: '#1e3a8a',
    gradientTo: '#f59e0b',
    accentColor: '#fef3c7',
    artworkType: 'landscape',
  },
];

export function shuffleGalleryIdeas(items: ImageGalleryIdea[]): ImageGalleryIdea[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

import React from 'react';
import { AlertCircle, Loader2, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function FirebaseAuthScreen() {
  const { signInWithGoogle, actionLoading, authError, clearAuthError } = useAuth();

  const handleGoogleContinue = async () => {
    await signInWithGoogle();
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-[#07090e] text-slate-900 dark:text-slate-100 relative overflow-hidden transition-colors">
      {/* Subtle Animated Gradient Ambient Background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[540px] h-[360px] rounded-full bg-gradient-to-tr from-emerald-400/20 via-sky-400/15 to-purple-400/20 dark:from-emerald-500/15 dark:via-sky-500/10 dark:to-purple-500/15 blur-3xl animate-pulse" />
        <div
          className="absolute -bottom-32 left-1/3 w-[440px] h-[320px] rounded-full bg-gradient-to-br from-purple-400/15 via-emerald-300/15 to-transparent dark:from-purple-600/10 dark:via-emerald-600/10 blur-3xl animate-pulse"
          style={{ animationDelay: '1.2s', animationDuration: '4s' }}
        />
      </div>

      {/* Single Clean Google Sign-In Card */}
      <div className="relative z-10 w-full max-w-sm bg-white/95 dark:bg-[#0c101c]/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl p-7 sm:p-8 text-center space-y-6">
        {/* Official MindGPT Logo */}
        <div className="flex flex-col items-center space-y-3">
          <div className="w-16 h-16 rounded-2xl overflow-hidden bg-black border border-purple-500/40 shadow-md flex items-center justify-center">
            <img
              src="/mindgpt-badge.png"
              alt="MindGPT"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="space-y-1">
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              MindGPT
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Sign in with Google to continue to your AI workspace
            </p>
          </div>
        </div>

        {/* Auth Error Notice if any */}
        {authError && (
          <div
            role="alert"
            data-testid="auth-error-banner"
            className="p-3 rounded-2xl bg-red-50 dark:bg-red-950/35 border border-red-200 dark:border-red-800/60 text-xs text-red-700 dark:text-red-300 flex items-start gap-2 text-left"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
            <span className="flex-1 leading-relaxed">{authError}</span>
            <button
              type="button"
              onClick={clearAuthError}
              className="text-red-400 hover:text-red-700 dark:hover:text-red-200 cursor-pointer shrink-0"
              aria-label="Dismiss error"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Single Continue with Google Button */}
        <button
          type="button"
          onClick={handleGoogleContinue}
          disabled={actionLoading}
          data-testid="google-auth-button"
          className="w-full py-3.5 px-5 rounded-2xl bg-white dark:bg-[#13192b] hover:bg-slate-50 dark:hover:bg-[#1a2238] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-sm transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-3 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {actionLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
              <span>Signing in with Google...</span>
            </>
          ) : (
            <>
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96z"
                />
              </svg>
              <span>Continue with Google</span>
            </>
          )}
        </button>

        <p className="text-[11px] text-slate-400 dark:text-slate-500">
          MindGPT by Ragib
        </p>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import type { ImageGalleryIdea } from '../data/imageGalleryIdeas';

export function GalleryArtwork({ idea }: { idea: ImageGalleryIdea }) {
  const { gradientFrom, gradientTo, previewImageUrl, title } = idea;
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div
      className="relative w-full aspect-[4/3] overflow-hidden bg-slate-100 dark:bg-slate-900"
      style={{
        background: `linear-gradient(135deg, ${gradientFrom}, ${gradientTo})`,
      }}
    >
      {!imgLoaded && !imgFailed && (
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-white/5 via-white/20 to-white/5 animate-pulse"
        />
      )}

      {!imgFailed && previewImageUrl ? (
        <img
          src={previewImageUrl}
          alt={title}
          loading="lazy"
          referrerPolicy="no-referrer"
          onLoad={() => setImgLoaded(true)}
          onError={() => setImgFailed(true)}
          className={`w-full h-full object-cover group-hover:scale-[1.03] transition-all duration-300 ${
            imgLoaded ? 'opacity-100' : 'opacity-0'
          }`}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center p-4 text-center">
          <span className="text-xs font-bold text-white/90">{title}</span>
        </div>
      )}
    </div>
  );
}

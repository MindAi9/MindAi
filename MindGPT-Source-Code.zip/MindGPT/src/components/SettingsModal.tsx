import React, { useState, useEffect } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Trash2,
  Check,
  Sun,
  Moon,
  Play,
  Square,
  Sparkles,
  Info,
  Sliders,
  User,
  Search,
  Bug,
  ShieldCheck,
  Palette,
  MessageSquare,
  Globe,
  Mic,
} from 'lucide-react';
import { AppSettings, Conversation } from '../types';
import { ttsEngine } from '../utils/tts';
import { normalizeLocaleCode } from '../data/languages';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  conversations: Conversation[];
  onClearAllConversations: () => void;
  onShowLoginPopup?: () => void;
}

export function SettingsModal({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  conversations,
  onClearAllConversations,
  onShowLoginPopup,
}: SettingsModalProps) {
  const [activeTab, setActiveTab] = useState<
    'personalization' | 'appearance' | 'voice' | 'chat' | 'language' | 'account' | 'general'
  >('appearance');
  const [searchSettingsQuery, setSearchSettingsQuery] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isPlayingTestVoice, setIsPlayingTestVoice] = useState(false);
  const [bugReportSubmitted, setBugReportSubmitted] = useState(false);
  const [bugDescription, setBugDescription] = useState('');

  useEffect(() => {
    return ttsEngine.subscribe((state) => {
      setIsPlayingTestVoice(
        state.currentMessageId === 'test-voice-preview' &&
          (state.status === 'playing' || state.status === 'loading')
      );
    });
  }, []);

  if (!isOpen) return null;

  const isTtsSupported = ttsEngine.isSupported();

  const handleTestVoice = () => {
    if (!isTtsSupported) return;
    setIsPlayingTestVoice(true);
    void ttsEngine.testVoice({
      gender: settings.voiceGender || 'female',
      languagePreference: normalizeLocaleCode(settings.languagePreference),
      voiceId: settings.voiceId,
    });
  };

  const handleStopTestVoice = () => {
    ttsEngine.stop();
    setIsPlayingTestVoice(false);
  };

  const TABS = [
    { id: 'personalization', label: 'Personalization', icon: Sliders },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'voice', label: 'Voice', icon: Mic },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'language', label: 'Language', icon: Globe },
    { id: 'account', label: 'Account', icon: User },
    { id: 'general', label: 'General', icon: Info },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-fadeIn select-none">
      <div
        className="relative w-full max-w-2xl bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl text-slate-800 dark:text-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Official Logo */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl overflow-hidden bg-black border border-purple-500/40 shadow-xs flex items-center justify-center shrink-0">
              <img
                src="/mindgpt-badge.png"
                alt="MindGPT"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Settings</h3>
              <p className="text-[11px] text-slate-400">MindGPT preferences & custom controls</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Settings Bar at Top of Modal (Requirement 11) */}
        <div className="px-6 py-2 border-b border-slate-100 dark:border-slate-800/60 bg-slate-50/50 dark:bg-[#0a0d16]">
          <div className="relative flex items-center">
            <Search className="absolute left-3 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchSettingsQuery}
              onChange={(e) => setSearchSettingsQuery(e.target.value)}
              placeholder="Search settings (theme, voice, hindi, enter key, nickname...)"
              className="w-full pl-8 pr-7 py-1.5 text-xs rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none text-slate-800 dark:text-slate-200 placeholder:text-slate-400 transition-colors"
            />
            {searchSettingsQuery && (
              <button
                onClick={() => setSearchSettingsQuery('')}
                className="absolute right-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-1 px-4 sm:px-6 py-2 border-b border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#080b13] overflow-x-auto scrollbar-none shrink-0">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-sm">
          {/* 1. PERSONALIZATION */}
          {activeTab === 'personalization' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">
                  Custom Personalization
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Provide custom instructions or information you want MindGPT to remember across conversations.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    What should MindGPT call you? (Nickname)
                  </label>
                  <input
                    type="text"
                    value={settings.userNickname || ''}
                    onChange={(e) => onUpdateSettings({ userNickname: e.target.value })}
                    placeholder="e.g. Alex, Friend, or leave empty"
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-[#0e1220] border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Custom AI Instructions
                  </label>
                  <textarea
                    value={settings.customInstructions || ''}
                    onChange={(e) => onUpdateSettings({ customInstructions: e.target.value })}
                    placeholder="e.g. 'I am a senior frontend engineer in Bangalore. Prefer TypeScript examples with concise explanations and always consider 2026 standards.'"
                    rows={4}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-[#0e1220] border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none resize-none leading-relaxed"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 2. APPEARANCE */}
          {activeTab === 'appearance' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Theme Mode</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Switch between crisp minimal Light Mode and deep dark Midnight Mode.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Light Theme */}
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ theme: 'light' })}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    settings.theme === 'light'
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-950 ring-2 ring-emerald-500/20'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-amber-100 text-amber-700">
                        <Sun className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-xs text-slate-900">Light</span>
                    </div>
                    {settings.theme === 'light' && <Check className="w-4 h-4 text-emerald-600" />}
                  </div>
                  <p className="text-[11px] text-slate-500">Default clean white aesthetic, high contrast</p>
                </button>

                {/* Dark Theme */}
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ theme: 'dark' })}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    settings.theme === 'dark'
                      ? 'bg-emerald-950/40 border-emerald-500 text-white ring-2 ring-emerald-500/20'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-indigo-950 text-indigo-300">
                        <Moon className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-xs text-white">Dark</span>
                    </div>
                    {settings.theme === 'dark' && <Check className="w-4 h-4 text-emerald-400" />}
                  </div>
                  <p className="text-[11px] text-slate-400">Deep obsidian void, easy on the eyes</p>
                </button>
              </div>

              {/* Accent Color Selection */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <span className="text-xs font-semibold text-slate-900 dark:text-white block mb-1">
                  User Message Accent Color
                </span>
                <p className="text-[11px] text-slate-400 mb-3">
                  Default is MindGPT Emerald Green (ChatGPT-inspired).
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'green', label: 'Emerald Green (Default)', color: 'bg-emerald-600' },
                    { id: 'blue', label: 'Ocean Blue', color: 'bg-blue-600' },
                    { id: 'purple', label: 'Violet Glow', color: 'bg-purple-600' },
                    { id: 'amber', label: 'Amber Gold', color: 'bg-amber-600' },
                  ].map((acc) => (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => onUpdateSettings({ accentColor: acc.id as any })}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                        (settings.accentColor || 'green') === acc.id
                          ? 'border-emerald-500 bg-slate-100 dark:bg-[#121626]'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full ${acc.color} shadow-xs flex items-center justify-center text-white`}>
                        {(settings.accentColor || 'green') === acc.id && <Check className="w-3 h-3" />}
                      </div>
                      <span className="text-[10px] font-medium text-slate-700 dark:text-slate-300">{acc.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 3. VOICE */}
          {activeTab === 'voice' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Voice Selection</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Select your preferred voice for reading AI responses aloud in English, Hindi, and Hinglish.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ voiceGender: 'female' })}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    settings.voiceGender === 'female' || !settings.voiceGender
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 dark:border-emerald-500 text-slate-900 dark:text-white'
                      : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-slate-900 dark:text-white">Female Voice</span>
                    {(settings.voiceGender === 'female' || !settings.voiceGender) && (
                      <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">Natural tone matching your language</p>
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateSettings({ voiceGender: 'male' })}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    settings.voiceGender === 'male'
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 dark:border-emerald-500 text-slate-900 dark:text-white'
                      : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-slate-900 dark:text-white">Male Voice</span>
                    {settings.voiceGender === 'male' && (
                      <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">Natural tone matching your language</p>
                </button>
              </div>

              {/* Test Voice Control */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-xs text-slate-900 dark:text-white block">
                    Test Selected Voice
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Play a brief audio sample
                  </span>
                </div>

                {isPlayingTestVoice ? (
                  <button
                    type="button"
                    onClick={handleStopTestVoice}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-100 dark:bg-red-950/50 text-red-700 dark:text-red-300 font-semibold text-xs cursor-pointer"
                  >
                    <Square className="w-3 h-3 fill-current" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleTestVoice}
                    disabled={!isTtsSupported}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Test Voice</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 4. CHAT */}
          {activeTab === 'chat' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Chat Controls</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Configure keyboard behavior, auto-scrolling, and acoustic sound cues.
                </p>
              </div>

              <div className="space-y-3">
                {/* Enter Behavior Toggle */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-xs text-slate-900 dark:text-white block">
                      Enter Key Inserts Newline (Default)
                    </span>
                    <span className="text-[11px] text-slate-500">
                      When enabled, pressing Enter creates a new line without sending. Clicking the Send button or Cmd+Enter sends the message.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={(settings.enterBehavior || 'newline') === 'newline'}
                    onChange={(e) =>
                      onUpdateSettings({ enterBehavior: e.target.checked ? 'newline' : 'send' })
                    }
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Auto Scroll Toggle */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-xs text-slate-900 dark:text-white block">
                      Smooth Auto-Scroll to Latest
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Automatically scroll down as new tokens stream in
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autoScroll !== false}
                    onChange={(e) => onUpdateSettings({ autoScroll: e.target.checked })}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Acoustic Sound Cues */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-xs text-slate-900 dark:text-white block">
                      Acoustic Sound Feedback
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Subtle sound when sending and receiving responses
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.soundEnabled}
                    onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Clear All Chats */}
                <div className="pt-2">
                  {showClearConfirm ? (
                    <div className="p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800/40 space-y-2">
                      <p className="text-xs text-red-700 dark:text-red-300 font-medium">
                        Delete all {conversations.length} chats permanently?
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            onClearAllConversations();
                            setShowClearConfirm(false);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-red-600 text-white font-semibold text-xs cursor-pointer"
                        >
                          Confirm Delete
                        </button>
                        <button
                          onClick={() => setShowClearConfirm(false)}
                          className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-medium cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowClearConfirm(true)}
                      className="flex items-center gap-2 text-xs font-medium text-red-600 dark:text-red-400 p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/20 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete all conversation history</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 5. LANGUAGE */}
          {activeTab === 'language' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">
                  Language Preference
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  MindGPT automatically understands and speaks English, Hindi (हिंदी), and Hinglish.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {[
                  {
                    id: 'en-US',
                    title: 'English (US)',
                    desc: 'Clear, modern American English standard across all answers.',
                  },
                  {
                    id: 'hi-IN',
                    title: 'Hindi (हिन्दी)',
                    desc: 'Shuddh Hindi with proper Devanagari script and native pronunciation.',
                  },
                  {
                    id: 'en-IN',
                    title: 'English (India)',
                    desc: 'Indian English tone adapted for local idioms and everyday phrasing.',
                  },
                  {
                    id: 'bn-IN',
                    title: 'Bengali (বাংলা)',
                    desc: 'Natural Bengali script and conversational phrasing across answers.',
                  },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onUpdateSettings({ languagePreference: item.id })}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      normalizeLocaleCode(settings.languagePreference) === item.id
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 dark:border-emerald-500 text-slate-900 dark:text-white'
                        : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-xs text-slate-900 dark:text-white">{item.title}</span>
                      {normalizeLocaleCode(settings.languagePreference) === item.id && (
                        <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 leading-relaxed">{item.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 6. ACCOUNT */}
          {activeTab === 'account' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Account & Profile</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Manage your MindGPT user profile and account preferences.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-600 text-white font-bold text-lg flex items-center justify-center">
                    {settings.userNickname ? settings.userNickname.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 dark:text-white text-sm">
                      {settings.userNickname || 'MindGPT User'}
                    </h5>
                    <p className="text-xs text-slate-500">guest@mindgpt.ai</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Authentication Status: Guest Account</span>
                  <button
                    type="button"
                    onClick={() => {
                      if (onShowLoginPopup) onShowLoginPopup();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    Log In
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 7. GENERAL / ABOUT */}
          {activeTab === 'general' && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800">
                <div className="w-12 h-12 rounded-2xl overflow-hidden bg-black border border-purple-500/50 shrink-0">
                  <img src="/mindgpt-badge.png" alt="MindGPT" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">MindGPT</h4>
                  <p className="text-xs text-slate-500">Version 2.5 Master Edition</p>
                </div>
              </div>

              {/* Creator Credit Directive (Ragib) */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 text-xs text-slate-700 dark:text-slate-300 space-y-1.5">
                <span className="font-bold text-emerald-900 dark:text-emerald-200 block text-sm">
                  Developer and Creator: Ragib
                </span>
                <p className="leading-relaxed">
                  "I was created by Ragib, the developer and creator of MindGPT. My vision is to make AI useful, accessible, and intelligent for everyone."
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                  MindGPT is an independent AI product engineered for deep problem solving, natural multilingual speech, and real-time knowledge.
                </p>
              </div>

              {/* Report a Bug / Feedback */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Bug className="w-4 h-4 text-amber-500" />
                  <span>Report a Bug or Feedback</span>
                </span>
                {bugReportSubmitted ? (
                  <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 text-xs text-emerald-800 dark:text-emerald-200">
                    Thank you! Your feedback has been noted for the developer (Ragib).
                  </div>
                ) : (
                  <div className="space-y-2">
                    <textarea
                      value={bugDescription}
                      onChange={(e) => setBugDescription(e.target.value)}
                      placeholder="Describe any issue, unexpected output, or suggestion..."
                      rows={2}
                      className="w-full p-2.5 rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none resize-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (bugDescription.trim()) {
                          setBugReportSubmitted(true);
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-black font-semibold text-xs cursor-pointer"
                    >
                      Submit Report
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080b13] shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>MindGPT Secure Engine · Ragib</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all cursor-pointer shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

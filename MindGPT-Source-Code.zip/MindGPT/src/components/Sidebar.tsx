import React, { useState, useRef } from 'react';
import {
  SquarePen,
  Search,
  MessageSquare,
  Settings,
  Trash2,
  Edit2,
  Pin,
  Lock,
  Unlock,
  Archive,
  Share2,
  MoreVertical,
  Check,
  X,
  PanelLeftClose,
  Layers,
  Image as ImageIcon,
  LogOut,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { Conversation } from '../types';
import { DrawerType } from './NavigationDrawer';
import type { FirebaseUser, UserProfileRecord } from '../services/firebase';

interface SidebarProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onDeleteConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onTogglePinConversation: (id: string) => void;
  onToggleLockConversation?: (id: string) => void;
  onToggleArchiveConversation?: (id: string) => void;
  onOpenDrawer: (type: DrawerType) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  userNickname?: string;
  firebaseUser?: FirebaseUser | null;
  userProfile?: UserProfileRecord | null;
  onOpenProfile?: () => void;
  onSignOut?: () => void;
  libraryCount?: number;
}

function formatRelativeTime(timestamp: number): string {
  const diffMs = Math.max(0, Date.now() - timestamp);
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return new Date(timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function Sidebar({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  onDeleteConversation,
  onRenameConversation,
  onTogglePinConversation,
  onToggleLockConversation,
  onToggleArchiveConversation,
  onOpenDrawer,
  isMobileOpen,
  onCloseMobile,
  isCollapsed,
  onToggleCollapse,
  userNickname,
  firebaseUser,
  userProfile,
  onOpenProfile,
  onSignOut,
  libraryCount = 0,
}: SidebarProps) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [pinnedCollapsed, setPinnedCollapsed] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [shareToast, setShareToast] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  const activeConversations = conversations
    .filter((c) => !c.isArchived)
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  const filtered = activeConversations.filter((c) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    const matchesTitle = c.title.toLowerCase().includes(query);
    const matchesMessage = c.messages.some((m) => m.content.toLowerCase().includes(query));
    return matchesTitle || matchesMessage;
  });

  const pinned = filtered.filter((c) => c.isPinned);
  const recentChats = filtered.filter((c) => !c.isPinned);

  const handleToggleSearch = () => {
    if (isCollapsed) {
      onToggleCollapse();
    }
    const next = !searchOpen;
    setSearchOpen(next);
    if (next) {
      setTimeout(() => searchInputRef.current?.focus(), 60);
    } else {
      setSearchQuery('');
    }
  };

  const handleStartRename = (e: React.MouseEvent, c: Conversation) => {
    e.stopPropagation();
    setEditingId(c.id);
    setEditingTitle(c.title);
    setActiveMenuId(null);
  };

  const handleSaveRename = (e: React.MouseEvent | React.FormEvent, id: string) => {
    e.stopPropagation();
    e.preventDefault();
    if (editingTitle.trim()) {
      onRenameConversation(id, editingTitle.trim());
    }
    setEditingId(null);
  };

  const handleShare = (c: Conversation) => {
    const text = `MindGPT Conversation: ${c.title}\n\n${c.messages
      .slice(0, 2)
      .map((m) => `${m.role === 'user' ? 'User' : 'MindGPT'}: ${m.content}`)
      .join('\n\n')}`;
    navigator.clipboard.writeText(text);
    setShareToast('Chat summary copied!');
    setActiveMenuId(null);
    setTimeout(() => setShareToast(null), 3000);
  };

  const renderConversationRow = (c: Conversation) => {
    const isActive = c.id === activeConversationId;
    const isEditing = c.id === editingId;
    const isMenuOpen = activeMenuId === c.id;

    return (
      <div
        key={c.id}
        onClick={() => {
          onSelectConversation(c.id);
          onCloseMobile();
        }}
        className={`group relative flex items-center justify-between px-3 min-h-[44px] py-2 rounded-xl text-xs transition-all cursor-pointer ${
          isActive
            ? 'bg-slate-200/90 dark:bg-[#151c2f] text-slate-900 dark:text-white font-semibold shadow-xs'
            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#101424] hover:text-slate-900 dark:hover:text-white'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          {c.isLocked ? (
            <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
          ) : c.isPinned ? (
            <Pin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          ) : (
            <MessageSquare className="w-3.5 h-3.5 text-slate-400 shrink-0 group-hover:text-slate-600 dark:group-hover:text-slate-300" />
          )}

          {isEditing ? (
            <form
              onSubmit={(e) => handleSaveRename(e, c.id)}
              className="flex-1 flex items-center gap-1"
              onClick={(e) => e.stopPropagation()}
            >
              <input
                type="text"
                value={editingTitle}
                onChange={(e) => setEditingTitle(e.target.value)}
                autoFocus
                className="w-full bg-white dark:bg-[#080b13] border border-emerald-500 rounded-lg px-2 py-1 text-xs text-slate-900 dark:text-white focus:outline-none"
              />
              <button
                type="button"
                onClick={(e) => handleSaveRename(e, c.id)}
                className="p-1.5 text-emerald-600 hover:text-emerald-500 cursor-pointer"
                aria-label="Save title"
              >
                <Check className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setEditingId(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label="Cancel rename"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </form>
          ) : (
            <div className="min-w-0 flex-1">
              <span className="truncate block text-xs leading-snug">{c.title}</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-normal block">
                {formatRelativeTime(c.updatedAt)}
              </span>
            </div>
          )}
        </div>

        {/* 3-Dot Action Menu Trigger */}
        {!isEditing && (
          <div className="relative pl-1 shrink-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setActiveMenuId(isMenuOpen ? null : c.id);
              }}
              className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-opacity cursor-pointer ${
                isMenuOpen ? 'opacity-100 bg-slate-200 dark:bg-slate-800' : 'opacity-100 md:opacity-0 md:group-hover:opacity-100'
              }`}
              title="Chat actions"
              aria-label="Chat actions"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>

            {isMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenuId(null);
                  }}
                />
                <div
                  className="absolute right-0 top-full mt-1 w-44 z-50 bg-white dark:bg-[#0f1424] border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl p-1 text-xs animate-fadeIn space-y-0.5"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    type="button"
                    onClick={() => handleShare(c)}
                    className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-left"
                  >
                    <Share2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>Share Chat</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onTogglePinConversation(c.id);
                      setActiveMenuId(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-left"
                  >
                    <Pin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{c.isPinned ? 'Unpin Chat' : 'Pin Chat'}</span>
                  </button>

                  {onToggleLockConversation && (
                    <button
                      type="button"
                      onClick={() => {
                        onToggleLockConversation(c.id);
                        setActiveMenuId(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-left"
                    >
                      {c.isLocked ? (
                        <Unlock className="w-3.5 h-3.5 text-slate-400" />
                      ) : (
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                      )}
                      <span>{c.isLocked ? 'Unlock Chat' : 'Lock Chat'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={(e) => handleStartRename(e, c)}
                    className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-left"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>Rename</span>
                  </button>

                  {onToggleArchiveConversation && (
                    <button
                      type="button"
                      onClick={() => {
                        onToggleArchiveConversation(c.id);
                        setActiveMenuId(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-left"
                    >
                      <Archive className="w-3.5 h-3.5 text-slate-400" />
                      <span>Archive Chat</span>
                    </button>
                  )}

                  <div className="border-t border-slate-100 dark:border-slate-800 my-1" />

                  <button
                    type="button"
                    onClick={() => {
                      setConfirmDeleteId(c.id);
                      setActiveMenuId(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer text-left"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/55 dark:bg-black/75 backdrop-blur-xs md:hidden transition-opacity"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#0f1424] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl animate-fadeIn">
            <h4 className="font-bold text-slate-900 dark:text-white text-sm">Delete Conversation?</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              This will permanently delete this conversation and its messages from your history.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteConversation(confirmDeleteId);
                  setConfirmDeleteId(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-red-600 hover:bg-red-500 cursor-pointer shadow-xs"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      <aside
        data-testid="navigation-sidebar"
        className={`fixed md:static inset-y-0 left-0 z-40 flex flex-col w-[280px] max-w-[85vw] bg-slate-50 dark:bg-[#07090e] border-r border-slate-200 dark:border-slate-800/80 transition-transform duration-300 ease-out md:transition-all shrink-0 select-none ${
          isMobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'
        } ${isCollapsed ? 'md:w-[68px]' : 'md:w-[272px]'}`}
      >
        {/* 1. DRAWER HEADER: MindGPT Logo & Branding + Search Action + Close/Collapse */}
        <div className="flex items-center justify-between h-14 px-3.5 border-b border-slate-200 dark:border-slate-800/80 shrink-0">
          <div
            onClick={() => {
              onNewChat();
              onCloseMobile();
            }}
            className="flex items-center gap-2.5 cursor-pointer group min-w-0"
            title="Start New Chat"
          >
            <div className="relative w-8 h-8 rounded-xl overflow-hidden bg-black border border-purple-500/40 shadow-xs flex items-center justify-center shrink-0">
              <img src="/mindgpt-badge.png" alt="MindGPT" className="w-full h-full object-contain" />
            </div>

            {!isCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-white truncate">
                  MindGPT
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium truncate">
                  By Ragib
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-0.5 shrink-0">
            {!isCollapsed && (
              <button
                type="button"
                onClick={handleToggleSearch}
                data-testid="drawer-search-button"
                className={`min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
                  searchOpen
                    ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800/60'
                }`}
                title="Search chats"
                aria-label="Search chats"
              >
                <Search className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={onToggleCollapse}
              className="hidden md:flex min-w-[36px] min-h-[36px] items-center justify-center rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
              title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              <PanelLeftClose className={`w-4 h-4 transition-transform ${isCollapsed ? 'rotate-180' : ''}`} />
            </button>

            <button
              type="button"
              onClick={onCloseMobile}
              className="flex md:hidden min-w-[40px] min-h-[40px] items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800/60 cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Expandable Search Bar inside Drawer */}
        {!isCollapsed && searchOpen && (
          <div className="px-3 pt-2.5 pb-1.5 animate-fadeIn">
            <div className="relative flex items-center">
              <Search className="absolute left-3 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search chat titles & messages..."
                data-testid="drawer-search-input"
                className="w-full pl-8 pr-8 py-2 text-xs rounded-xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none text-slate-800 dark:text-slate-200 placeholder:text-slate-400 transition-colors shadow-2xs"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* 2. MAIN NAVIGATION ITEMS: New Chat, Images, Library (Projects/Remote/Scheduled/Plugins removed) */}
        <div className="px-2.5 py-2 space-y-1">
          {!isCollapsed ? (
            <>
              <button
                type="button"
                onClick={() => {
                  onNewChat();
                  onCloseMobile();
                }}
                data-testid="nav-new-chat-button"
                className="w-full flex items-center gap-3 px-3 min-h-[44px] rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 hover:bg-slate-100/70 dark:hover:bg-[#131929] transition-colors cursor-pointer text-left shadow-2xs"
              >
                <SquarePen className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>New Chat</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onOpenDrawer('image-library');
                  onCloseMobile();
                }}
                data-testid="nav-images-button"
                className="w-full flex items-center justify-between px-3 min-h-[44px] rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800/60 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <ImageIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Images</span>
                </span>
                <span className="text-[10px] font-medium text-slate-400 dark:text-slate-500">Ideas</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onOpenDrawer('library');
                  onCloseMobile();
                }}
                data-testid="nav-library-button"
                className="w-full flex items-center justify-between px-3 min-h-[44px] rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800/60 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <Layers className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span>Library</span>
                </span>
                {libraryCount > 0 && (
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {libraryCount}
                  </span>
                )}
              </button>
            </>
          ) : (
            <div className="flex flex-col items-center gap-1.5 py-1">
              <button
                type="button"
                onClick={onNewChat}
                className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:text-emerald-600 hover:bg-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                title="New Chat"
              >
                <SquarePen className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onOpenDrawer('image-library')}
                className="p-2.5 rounded-xl text-slate-500 hover:text-emerald-600 hover:bg-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                title="Images"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onOpenDrawer('library')}
                className="p-2.5 rounded-xl text-slate-500 hover:text-blue-600 hover:bg-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                title="Library"
              >
                <Layers className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Share notification toast */}
        {shareToast && (
          <div className="mx-3 my-1 p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-600/40 text-[11px] text-emerald-800 dark:text-emerald-200 flex items-center justify-between animate-fadeIn">
            <span>{shareToast}</span>
            <button type="button" onClick={() => setShareToast(null)} className="cursor-pointer">
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* 3. PINNED & RECENT CHATS SECTIONS */}
        <div className="flex-1 overflow-y-auto px-2.5 py-1 border-t border-slate-200/80 dark:border-slate-800/80 scrollbar-thin">
          {!isCollapsed ? (
            <div className="space-y-3 pt-2">
              {/* C. Pinned Section */}
              <div data-testid="nav-pinned-section">
                <button
                  type="button"
                  onClick={() => setPinnedCollapsed(!pinnedCollapsed)}
                  className="w-full flex items-center justify-between px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  <span className="flex items-center gap-1.5">
                    <Pin className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    <span>Pinned</span>
                    <span className="text-[10px] font-semibold text-slate-400">({pinned.length})</span>
                  </span>
                  {pinnedCollapsed ? (
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  )}
                </button>

                {!pinnedCollapsed && (
                  <div className="mt-1 space-y-0.5">
                    {pinned.length === 0 ? (
                      <p className="px-3 py-1.5 text-[11px] text-slate-400 dark:text-slate-500">
                        Pin important chats from the menu to keep them here.
                      </p>
                    ) : (
                      pinned.map(renderConversationRow)
                    )}
                  </div>
                )}
              </div>

              {/* D. Recent Chats Section */}
              <div data-testid="nav-recent-section" className="pt-1 border-t border-slate-200/60 dark:border-slate-800/60">
                <div className="flex items-center justify-between px-2.5 py-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Recent Chats
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onOpenDrawer('settings');
                      onCloseMobile();
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Open Settings"
                    aria-label="Open Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                  </button>
                </div>

                {recentChats.length === 0 ? (
                  <div className="py-6 px-3 text-center text-xs text-slate-400 dark:text-slate-500">
                    {searchQuery ? 'No matching chats found.' : 'Start a conversation to see recent chats here.'}
                  </div>
                ) : (
                  <div className="space-y-0.5 pb-2">
                    {recentChats.map(renderConversationRow)}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5 pt-2">
              <button
                type="button"
                onClick={() => onOpenDrawer('settings')}
                className="p-2.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
              {filtered.slice(0, 8).map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onSelectConversation(c.id)}
                  title={c.title}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs transition-colors cursor-pointer ${
                    c.id === activeConversationId
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-600/40'
                      : 'text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 4. BOTTOM USER PROFILE AREA */}
        <div className="p-2 border-t border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-[#07090e] flex items-center gap-1 shrink-0 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          <button
            type="button"
            onClick={() => {
              onOpenDrawer('profile');
              onCloseMobile();
            }}
            data-testid="sidebar-profile-button"
            className={`flex-1 min-w-0 min-h-[44px] flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer ${
              isCollapsed ? 'justify-center px-1.5' : ''
            }`}
            title="Open Profile & Settings"
          >
            {(userProfile?.photoURL || firebaseUser?.photoURL) ? (
              <img
                src={userProfile?.photoURL || firebaseUser?.photoURL || ''}
                alt={userProfile?.displayName || firebaseUser?.displayName || 'User'}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-emerald-500/50 shadow-xs"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
                {(userProfile?.displayName || firebaseUser?.displayName || userNickname || firebaseUser?.email || 'U')
                  .charAt(0)
                  .toUpperCase()}
              </div>
            )}

            {!isCollapsed && (
              <div className="flex-1 min-w-0">
                <span className="block truncate text-xs font-semibold text-slate-900 dark:text-slate-100">
                  {userProfile?.displayName || firebaseUser?.displayName || userNickname || 'MindGPT User'}
                </span>
                <span className="block truncate text-[10px] text-slate-500 dark:text-slate-400">
                  {userProfile?.username ? `@${userProfile.username}` : firebaseUser?.email || 'Google Account'}
                </span>
              </div>
            )}
          </button>

          {!isCollapsed && (
            <button
              type="button"
              onClick={() => {
                onOpenDrawer('settings');
                onCloseMobile();
              }}
              data-testid="sidebar-settings-button"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
              title="Settings"
              aria-label="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          )}

          {!isCollapsed && onSignOut && firebaseUser && (
            <button
              type="button"
              onClick={onSignOut}
              data-testid="sidebar-logout-button"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer shrink-0"
              title="Sign out"
              aria-label="Sign out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </aside>
    </>
  );
}

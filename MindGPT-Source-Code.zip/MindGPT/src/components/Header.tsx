import React, { useState } from 'react';
import {
  Menu,
  Share2,
  Trash2,
  Plus,
  Settings,
  Check,
  Sun,
  Moon,
  MoreVertical,
  MessageSquarePlus,
} from 'lucide-react';
import { AppSettings } from '../types';

interface HeaderProps {
  settings: AppSettings;
  onOpenMobileSidebar: () => void;
  onNewChat: () => void;
  onClearCurrentChat: () => void;
  onOpenSettings: () => void;
  onToggleTheme: () => void;
  hasMessages: boolean;
}

export function Header({
  settings,
  onOpenMobileSidebar,
  onNewChat,
  onClearCurrentChat,
  onOpenSettings,
  onToggleTheme,
  hasMessages,
}: HeaderProps) {
  const [plusMenuOpen, setPlusMenuOpen] = useState(false);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  const handleShare = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch {}
    setMoreMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-14 px-3 sm:px-4 bg-white/95 dark:bg-[#07090e]/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 shrink-0 transition-colors">
      {/* Left zone: Mobile sidebar menu button ONLY */}
      <div className="flex items-center">
        <button
          type="button"
          onClick={onOpenMobileSidebar}
          data-testid="mobile-menu-button"
          className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors cursor-pointer"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Right zone: Plus (+) popup button & Three-dot (⋮) dropdown ONLY */}
      <div className="flex items-center gap-1.5 relative">
        {/* Compact Plus (+) Button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setPlusMenuOpen((v) => !v);
              setMoreMenuOpen(false);
            }}
            data-testid="header-plus-button"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors cursor-pointer"
            title="New Chat options"
            aria-label="New Chat options"
          >
            <Plus className="w-5 h-5" />
          </button>

          {plusMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setPlusMenuOpen(false)}
              />
              <div
                data-testid="header-plus-popup"
                className="absolute right-0 top-full mt-1.5 w-44 z-50 bg-white dark:bg-[#0f1424] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-1.5 text-xs animate-fadeIn"
              >
                <button
                  type="button"
                  onClick={() => {
                    setPlusMenuOpen(false);
                    onNewChat();
                  }}
                  data-testid="header-popup-new-chat"
                  className="w-full min-h-[40px] flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-800 dark:text-slate-100 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-700 dark:hover:text-emerald-300 font-semibold transition-colors cursor-pointer text-left"
                >
                  <MessageSquarePlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>New Chat</span>
                </button>
              </div>
            </>
          )}
        </div>

        {/* Three-dot (⋮) Menu Button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setMoreMenuOpen((v) => !v);
              setPlusMenuOpen(false);
            }}
            data-testid="header-more-button"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors cursor-pointer"
            title="More options"
            aria-label="More options"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {moreMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setMoreMenuOpen(false)}
              />
              <div
                data-testid="header-more-dropdown"
                className="absolute right-0 top-full mt-1.5 w-52 z-50 bg-white dark:bg-[#0f1424] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-1.5 text-xs animate-fadeIn space-y-0.5"
              >
                <button
                  type="button"
                  onClick={handleShare}
                  className="w-full min-h-[40px] flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 font-medium transition-colors cursor-pointer text-left"
                >
                  {copiedShare ? (
                    <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <Share2 className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                  )}
                  <span>{copiedShare ? 'Link Copied' : 'Share Chat'}</span>
                </button>

                <button
                  type="button"
                  disabled={!hasMessages}
                  onClick={() => {
                    setMoreMenuOpen(false);
                    onClearCurrentChat();
                  }}
                  className="w-full min-h-[40px] flex items-center gap-2.5 px-3 py-2 rounded-xl text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-40 disabled:cursor-not-allowed font-medium transition-colors cursor-pointer text-left"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Clear Chat</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMoreMenuOpen(false);
                    onToggleTheme();
                  }}
                  data-testid="menu-toggle-theme"
                  className="w-full min-h-[40px] flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 font-medium transition-colors cursor-pointer text-left"
                >
                  {settings.theme === 'dark' ? (
                    <Sun className="w-4 h-4 text-amber-500" />
                  ) : (
                    <Moon className="w-4 h-4 text-indigo-500" />
                  )}
                  <span>{settings.theme === 'dark' ? 'Switch to Light Theme' : 'Switch to Dark Theme'}</span>
                </button>

                <div className="border-t border-slate-100 dark:border-slate-800 my-1" />

                <button
                  type="button"
                  onClick={() => {
                    setMoreMenuOpen(false);
                    onOpenSettings();
                  }}
                  data-testid="menu-open-settings"
                  className="w-full min-h-[40px] flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 font-medium transition-colors cursor-pointer text-left"
                >
                  <Settings className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Open Settings</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

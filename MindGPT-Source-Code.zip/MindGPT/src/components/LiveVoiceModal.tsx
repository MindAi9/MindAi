import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  PhoneOff,
  Sparkles,
  Volume2,
  AlertCircle,
  Radio,
} from 'lucide-react';

interface LiveVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LiveVoiceModal({ isOpen, onClose }: LiveVoiceModalProps) {
  const [connectionStatus, setConnectionStatus] = useState<
    'connecting' | 'connected' | 'error' | 'disconnected'
  >('connecting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isAiResponding, setIsAiResponding] = useState(false);
  const [volumeLevel, setVolumeLevel] = useState(0);

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const isMutedRef = useRef(isMuted);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    if (!isOpen) return;

    let isCancelled = false;

    async function initLiveVoice() {
      setConnectionStatus('connecting');
      setErrorMessage(null);

      // 1. Establish WebSocket connection to backend /api/live
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = async () => {
          if (isCancelled) return;
          console.log('Connected to MindGPT Live Voice WebSocket');

          try {
            // 2. Request mic access
            const stream = await navigator.mediaDevices.getUserMedia({
              audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
              },
            });
            mediaStreamRef.current = stream;

            // 3. Audio Contexts
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            // 16kHz for input mic capture as required by Mind Live Audio API
            const inputCtx = new AudioContextClass({ sampleRate: 16000 });
            // 24kHz for model output playback
            const outputCtx = new AudioContextClass({ sampleRate: 24000 });

            inputAudioCtxRef.current = inputCtx;
            outputAudioCtxRef.current = outputCtx;
            nextStartTimeRef.current = outputCtx.currentTime;

            const sourceNode = inputCtx.createMediaStreamSource(stream);
            // ScriptProcessorNode for raw PCM float32 capture
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              if (isMutedRef.current || ws.readyState !== WebSocket.OPEN) return;

              const inputChannelData = e.inputBuffer.getChannelData(0);

              // Calculate mic volume for UI visualizer
              let sum = 0;
              for (let i = 0; i < inputChannelData.length; i++) {
                sum += Math.abs(inputChannelData[i]);
              }
              const avg = sum / inputChannelData.length;
              setVolumeLevel(Math.min(100, Math.round(avg * 400)));
              setIsSpeaking(avg > 0.02);

              // Convert Float32 to 16-bit PCM little-endian
              const pcm16 = new Int16Array(inputChannelData.length);
              for (let i = 0; i < inputChannelData.length; i++) {
                const s = Math.max(-1, Math.min(1, inputChannelData[i]));
                pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
              }

              // Base64 encode
              const bytes = new Uint8Array(pcm16.buffer);
              let binary = '';
              for (let i = 0; i < bytes.byteLength; i++) {
                binary += String.fromCharCode(bytes[i]);
              }
              const base64Audio = btoa(binary);

              ws.send(JSON.stringify({ audio: base64Audio }));
            };

            sourceNode.connect(processor);
            processor.connect(inputCtx.destination);

            setConnectionStatus('connected');
          } catch (micErr: any) {
            console.error('Microphone permission error:', micErr);
            setErrorMessage(
              'Microphone access was denied or is unavailable. Please allow microphone permissions in your browser.'
            );
            setConnectionStatus('error');
          }
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);

            if (data.error) {
              setErrorMessage(data.error);
              setConnectionStatus('error');
              return;
            }

            // User interrupted AI speaking: stop all queued audio sources immediately
            if (data.interrupted) {
              console.log('AI response interrupted by user');
              stopAllOutputSources();
              setIsAiResponding(false);
              return;
            }

            // Play incoming 24kHz audio chunk from Live Voice stream
            if (data.audio) {
              playIncomingAudioChunk(data.audio);
            }
          } catch (e) {
            console.warn('Error parsing websocket live audio message:', e);
          }
        };

        ws.onerror = () => {
          setErrorMessage('Could not establish live connection to Mind Live Voice server.');
          setConnectionStatus('error');
        };

        ws.onclose = () => {
          setConnectionStatus('disconnected');
        };
      } catch (err: any) {
        setErrorMessage(err?.message || 'Failed to initialize live voice.');
        setConnectionStatus('error');
      }
    }

    initLiveVoice();

    return () => {
      isCancelled = true;
      cleanup();
    };
  }, [isOpen]);

  // Clean up all audio nodes & sockets
  const cleanup = () => {
    stopAllOutputSources();

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {}
      processorRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch {}
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      try {
        outputAudioCtxRef.current.close();
      } catch {}
      outputAudioCtxRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {}
      wsRef.current = null;
    }
  };

  const stopAllOutputSources = () => {
    activeSourcesRef.current.forEach((source) => {
      try {
        source.stop();
      } catch {}
    });
    activeSourcesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  };

  // Convert incoming base64 PCM 16-bit 24kHz audio into AudioBuffer and schedule playback
  const playIncomingAudioChunk = (base64Audio: string) => {
    const outputCtx = outputAudioCtxRef.current;
    if (!outputCtx || outputCtx.state === 'closed') return;

    if (outputCtx.state === 'suspended') {
      outputCtx.resume();
    }

    setIsAiResponding(true);

    try {
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const pcm16 = new Int16Array(bytes.buffer);
      const numSamples = pcm16.length;

      const audioBuffer = outputCtx.createBuffer(1, numSamples, 24000);
      const channelData = audioBuffer.getChannelData(0);

      for (let i = 0; i < numSamples; i++) {
        channelData[i] = pcm16[i] / 32768.0;
      }

      const sourceNode = outputCtx.createBufferSource();
      sourceNode.buffer = audioBuffer;
      sourceNode.connect(outputCtx.destination);

      const currentTime = outputCtx.currentTime;
      const startTime = Math.max(currentTime, nextStartTimeRef.current);
      sourceNode.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;

      activeSourcesRef.current.push(sourceNode);

      sourceNode.onended = () => {
        activeSourcesRef.current = activeSourcesRef.current.filter((s) => s !== sourceNode);
        if (activeSourcesRef.current.length === 0) {
          setIsAiResponding(false);
        }
      };
    } catch (err) {
      console.warn('Error playing audio chunk:', err);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div
        className="relative w-full max-w-lg bg-[#0b0e18] border border-purple-500/30 rounded-3xl p-8 shadow-2xl text-slate-100 flex flex-col items-center text-center overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Background glow dynamics */}
        <div
          className={`absolute inset-0 bg-gradient-to-b from-purple-900/10 via-blue-900/10 to-transparent transition-opacity duration-700 pointer-events-none ${
            isAiResponding ? 'opacity-100' : 'opacity-40'
          }`}
        />

        {/* Top Header */}
        <div className="w-full flex items-center justify-between pb-4 border-b border-slate-800/80 mb-6">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-purple-300">
              Mind Live Voice Mode
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Orb Visualizer with Official MindGPT Logo */}
        <div className="relative my-6 flex items-center justify-center">
          {/* Animated concentric pulse rings */}
          <div
            className={`absolute w-44 h-44 rounded-full border border-purple-500/20 transition-all duration-300 ${
              isAiResponding
                ? 'scale-125 border-purple-400/50 animate-ping'
                : isSpeaking
                ? 'scale-110 border-blue-400/40'
                : 'scale-100 opacity-30'
            }`}
          />
          <div
            className={`absolute w-36 h-36 rounded-full bg-gradient-to-tr from-purple-600/30 via-indigo-600/20 to-blue-500/30 blur-xl transition-all duration-300 ${
              isAiResponding ? 'scale-150 opacity-90' : isSpeaking ? 'scale-125 opacity-70' : 'opacity-40'
            }`}
          />

          {/* Central Logo Disk */}
          <div className="relative w-28 h-28 rounded-3xl overflow-hidden shadow-2xl border-2 border-purple-500/40 bg-black flex items-center justify-center">
            <img
              src="/mindgpt-badge.png"
              alt="MindGPT Live Voice"
              className="w-full h-full object-contain p-1"
            />
          </div>
        </div>

        {/* Dynamic Status Display */}
        <div className="space-y-1.5 mb-8">
          <h3 className="text-lg font-bold text-white">
            {connectionStatus === 'connecting' && 'Connecting to Mind Live Voice...'}
            {connectionStatus === 'connected' &&
              (isAiResponding
                ? 'MindGPT is speaking...'
                : isSpeaking
                ? 'Listening to you...'
                : 'Listening... (Speak naturally)')}
            {connectionStatus === 'error' && 'Connection Error'}
            {connectionStatus === 'disconnected' && 'Live Session Ended'}
          </h3>

          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            {connectionStatus === 'connected' &&
              'Natural two-way spoken dialogue. You can interrupt the AI at any moment while it speaks.'}
            {connectionStatus === 'connecting' && 'Initializing microphone and Mind Live audio bridge...'}
            {errorMessage}
          </p>
        </div>

        {/* Controls Bar */}
        <div className="flex items-center gap-4">
          {/* Mute Button */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            disabled={connectionStatus !== 'connected'}
            className={`p-4 rounded-2xl transition-all cursor-pointer ${
              isMuted
                ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40'
                : 'bg-[#121727] text-slate-200 border border-slate-700 hover:bg-[#1a2238]'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* End Call Button */}
          <button
            onClick={onClose}
            className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm transition-all shadow-xl shadow-red-950/40 cursor-pointer"
            title="End live voice session"
          >
            <PhoneOff className="w-5 h-5" />
            <span>End Call</span>
          </button>
        </div>

        {/* Footer Language Note */}
        <div className="mt-8 text-[11px] text-slate-500">
          Supports real-time English, Hindi (हिंदी) and Hinglish spoken voices.
        </div>
      </div>
    </div>
  );
}

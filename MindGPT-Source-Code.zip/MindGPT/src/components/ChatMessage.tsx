import React, { useState } from 'react';
import {
  Copy,
  Check,
  RotateCcw,
  Volume2,
  Pause,
  Play,
  Square,
  ThumbsUp,
  ThumbsDown,
  Edit3,
  Globe,
  ExternalLink,
  Search,
  AlertCircle,
  FileText,
  Download,
  Maximize2,
  Sparkles,
  Wand2,
  Bookmark,
  Loader2,
  X,
} from 'lucide-react';
import { Message } from '../types';
import { RenderMarkdown } from '../utils/markdown';
import { useTTS } from '../hooks/useTTS';

interface ChatMessageProps {
  message: Message;
  isLast: boolean;
  onRegenerate?: () => void;
  onEditPrompt?: (newPrompt: string) => void;
  onEditImageInChat?: (imagePrompt: string) => void;
  onRetryImageGeneration?: (messageId: string, prompt: string, isEdit?: boolean) => void;
  onSaveGeneratedImage?: (messageId: string) => void;
  languagePreference?: string;
  voiceGender?: 'male' | 'female';
  voiceId?: string;
  accentColor?: 'green' | 'blue' | 'purple' | 'amber';
}

export function ChatMessage({
  message,
  isLast,
  onRegenerate,
  onEditPrompt,
  onEditImageInChat,
  onRetryImageGeneration,
  onSaveGeneratedImage,
  languagePreference = 'en-US',
  voiceGender = 'female',
  voiceId,
  accentColor = 'green',
}: ChatMessageProps) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<'up' | 'down' | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(message.content);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [imageLoadFailed, setImageLoadFailed] = useState(false);

  const {
    currentMessageId,
    status,
    play,
    pause,
    resume,
    stop,
    isSupported,
    isLoading: isTtsLoading,
    ttsSource,
    voiceName,
    notice: ttsNotice,
    chunkIndex,
    totalChunks,
  } = useTTS();

  const isUser = message.role === 'user';
  const isThisActive = currentMessageId === message.id && status !== 'idle';
  const isThisLoading = isThisActive && isTtsLoading;
  const isThisPlaying = isThisActive && status === 'playing';
  const isThisPaused = isThisActive && status === 'paused';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleSpeak = () => {
    if (isThisPlaying) {
      pause();
    } else if (isThisPaused) {
      resume();
    } else {
      void play(message.id, message.content, {
        languagePreference,
        gender: voiceGender,
        voiceId,
      });
    }
  };

  const handleStopSpeak = () => {
    stop();
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editText.trim() && onEditPrompt) {
      onEditPrompt(editText.trim());
      setIsEditing(false);
    }
  };

  const handleDownloadImage = async () => {
    if (!message.generatedImage) return;
    try {
      if (message.generatedImage.url.startsWith('data:')) {
        const a = document.createElement('a');
        a.href = message.generatedImage.url;
        a.download = `mindgpt-${Date.now()}.png`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        return;
      }
      const res = await fetch(message.generatedImage.url);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `mindgpt-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(blobUrl);
    } catch {
      const a = document.createElement('a');
      a.href = message.generatedImage.url;
      a.target = '_blank';
      a.download = `mindgpt-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  };

  const userBubbleColors = {
    green: 'bg-emerald-600 dark:bg-emerald-600 text-white shadow-xs',
    blue: 'bg-blue-600 dark:bg-blue-600 text-white shadow-xs',
    purple: 'bg-purple-600 dark:bg-purple-600 text-white shadow-xs',
    amber: 'bg-amber-600 dark:bg-amber-600 text-white shadow-xs',
  }[accentColor || 'green'];

  return (
    <div className="w-full py-2 px-2 sm:px-4">
      <div className="max-w-3xl mx-auto">
        {isUser ? (
          /* USER MESSAGE: Attractive Green Message Bubble (Aligned Right) */
          <div className="flex flex-col items-end space-y-1 ml-auto max-w-[88%] sm:max-w-[80%]">
            {/* User Attachments Display */}
            {message.attachments && message.attachments.length > 0 && (
              <div className="flex flex-wrap justify-end gap-2 mb-1">
                {message.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-100 dark:bg-[#161b2e] border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200"
                  >
                    {att.isBase64 ? (
                      <img
                        src={att.data}
                        alt={att.name}
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                        <FileText className="w-5 h-5" />
                      </div>
                    )}
                    <div className="truncate max-w-[140px] pr-1 text-left">
                      <span className="block truncate font-semibold text-[11px] text-slate-900 dark:text-white">
                        {att.name}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {(att.size / 1024).toFixed(1)} KB
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Bubble */}
            <div
              className={`rounded-2xl rounded-tr-xs px-3.5 py-2.5 text-[13.5px] sm:text-[14px] leading-[1.55] break-words ${userBubbleColors}`}
            >
              {isEditing ? (
                <form onSubmit={handleSaveEdit} className="space-y-2">
                  <textarea
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    className="w-full p-2 rounded-xl bg-black/20 text-white placeholder-white/70 border border-white/30 focus:outline-none focus:ring-1 focus:ring-white text-sm"
                    rows={3}
                  />
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="px-3 py-1 text-xs font-semibold bg-white text-emerald-800 rounded-lg cursor-pointer hover:bg-slate-100"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1 text-xs font-medium text-white/80 hover:text-white bg-black/30 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <p className="whitespace-pre-wrap">{message.content}</p>
              )}
            </div>

            {/* Action Row for User (Copy & Edit) */}
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 text-[11px] pr-1">
              <button
                onClick={handleCopy}
                className="hover:text-slate-700 dark:hover:text-slate-300 transition-colors cursor-pointer"
                title="Copy prompt"
              >
                {copied ? 'Copied' : 'Copy'}
              </button>
              {onEditPrompt && !isEditing && (
                <>
                  <span>·</span>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="hover:text-slate-700 dark:hover:text-slate-300 transition-colors cursor-pointer flex items-center gap-1"
                    title="Edit prompt"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>Edit</span>
                  </button>
                </>
              )}
            </div>
          </div>
        ) : (
          /* ASSISTANT MESSAGE: Clean Unboxed Layout (No avatar beside every reply) */
          <div className="space-y-2 py-1">
            {/* Search Grounding Live Status Banner */}
            {message.searchStatus && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-[#101424] border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 w-fit animate-pulse">
                <Search className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 animate-spin" />
                <span className="font-medium">{message.searchStatus}</span>
              </div>
            )}

            {/* Error Message Card */}
            {message.error ? (
              <div className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800/40 text-red-700 dark:text-red-300 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                <div className="space-y-1">
                  <p className="font-semibold text-red-800 dark:text-red-200">Notice</p>
                  <p className="text-red-700 dark:text-red-300/90 leading-relaxed">{message.content}</p>
                  {onRegenerate && (
                    <button
                      onClick={onRegenerate}
                      className="mt-2 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-red-100 hover:bg-red-200 dark:bg-red-900/40 dark:hover:bg-red-800/60 text-red-800 dark:text-red-200 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Retry</span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Genuine AI Markdown Content */
              <div className="space-y-3">
                {message.isStreaming &&
                  !message.content &&
                  !message.generatedImage &&
                  !message.imageGeneration &&
                  !message.searchStatus && (
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 py-1">
                      <span className="inline-flex gap-1 items-center">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                      </span>
                      <span className="font-medium">MindGPT is thinking...</span>
                    </div>
                  )}

                {/* TEMPORARY PROCESSING PREVIEW CARD WHILE GENERATING IMAGE */}
                {message.imageGeneration?.status === 'generating' && (
                  <div
                    data-testid="image-generating-card"
                    className="max-w-md rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-[#0d1220] shadow-sm"
                  >
                    <div className="relative aspect-[4/3] w-full overflow-hidden flex flex-col items-center justify-center p-5 text-center bg-gradient-to-br from-emerald-950/85 via-slate-900 to-teal-950/90">
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 bg-gradient-to-r from-emerald-500/15 via-teal-400/20 to-emerald-500/15 blur-xl animate-pulse"
                      />
                      <div className="relative z-10 flex flex-col items-center gap-3">
                        <div className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center justify-center shadow-lg">
                          <Loader2 className="w-5 h-5 text-emerald-400 animate-spin" />
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-semibold text-white tracking-tight">
                            {message.imageGeneration.isEdit ? 'Editing your image...' : 'Creating your image...'}
                          </p>
                          <p className="text-[11px] text-slate-300/90 line-clamp-2 max-w-[280px]">
                            {message.imageGeneration.prompt}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* IMAGE GENERATION ERROR & RETRY CARD */}
                {message.imageGeneration?.status === 'error' && (
                  <div
                    data-testid="image-error-card"
                    className="max-w-md flex items-start gap-2.5 p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/25 border border-red-200 dark:border-red-800/50 text-red-800 dark:text-red-200 text-xs"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                    <div className="space-y-1.5 min-w-0 flex-1">
                      <p className="font-semibold">Image generation could not complete</p>
                      <p className="text-red-700 dark:text-red-300/90 leading-relaxed break-words">
                        {message.imageGeneration.errorMessage || 'Please try again or refine your prompt.'}
                      </p>
                      {onRetryImageGeneration && (
                        <button
                          type="button"
                          onClick={() =>
                            onRetryImageGeneration(
                              message.id,
                              message.imageGeneration!.prompt,
                              message.imageGeneration!.isEdit
                            )
                          }
                          className="mt-1 inline-flex items-center gap-1.5 min-h-[34px] px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Retry Image</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {message.content && (
                  <div className="text-slate-800 dark:text-slate-100 text-[13.5px] sm:text-[14px] leading-[1.6] tracking-normal font-normal">
                    <RenderMarkdown content={message.content} />
                    {message.isStreaming && (
                      <span className="inline-block w-2 h-4 ml-1 bg-emerald-500 dark:bg-emerald-400 animate-pulse align-middle" />
                    )}
                  </div>
                )}

                {/* INLINE GENERATED / EDITED IMAGE DISPLAY */}
                {message.generatedImage && (
                  <div className="pt-1 pb-2 space-y-2 max-w-md" data-testid="generated-image-card">
                    {imageLoadFailed ? (
                      <div className="flex items-center justify-between gap-2.5 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 text-amber-800 dark:text-amber-200 text-xs">
                        <span className="flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0 text-amber-500" />
                          <span>Image failed to display cleanly.</span>
                        </span>
                        {onRetryImageGeneration && (
                          <button
                            type="button"
                            onClick={() =>
                              onRetryImageGeneration(
                                message.id,
                                message.generatedImage!.prompt,
                                message.generatedImage!.isEdit
                              )
                            }
                            className="px-2.5 py-1 rounded-lg bg-amber-600 text-white font-semibold shrink-0 cursor-pointer"
                          >
                            Retry
                          </button>
                        )}
                      </div>
                    ) : (
                      <>
                        <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950/90 shadow-md group">
                          <img
                            src={message.generatedImage.url}
                            alt={message.generatedImage.prompt}
                            referrerPolicy="no-referrer"
                            onError={() => setImageLoadFailed(true)}
                            className="w-full h-auto max-h-[460px] object-contain cursor-pointer transition-opacity duration-300"
                            onClick={() => setPreviewModalOpen(true)}
                          />
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setPreviewModalOpen(true)}
                              className="min-h-[34px] px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0e1322] hover:border-emerald-500 text-slate-700 dark:text-slate-200 font-medium inline-flex items-center gap-1.5 cursor-pointer"
                            >
                              <Maximize2 className="w-3.5 h-3.5" />
                              <span>Open</span>
                            </button>

                            {onSaveGeneratedImage && (
                              <button
                                type="button"
                                onClick={() => onSaveGeneratedImage(message.id)}
                                disabled={Boolean(message.generatedImage.savedToLibrary)}
                                className={`min-h-[34px] px-2.5 py-1 rounded-xl border font-medium inline-flex items-center gap-1.5 transition-colors ${
                                  message.generatedImage.savedToLibrary
                                    ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 cursor-default'
                                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0e1322] hover:border-emerald-500 text-slate-700 dark:text-slate-200 cursor-pointer'
                                }`}
                              >
                                <Bookmark
                                  className={`w-3.5 h-3.5 ${
                                    message.generatedImage.savedToLibrary ? 'fill-current' : ''
                                  }`}
                                />
                                <span>{message.generatedImage.savedToLibrary ? 'Saved' : 'Save to Library'}</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={handleDownloadImage}
                              className="min-h-[34px] px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0e1322] hover:border-emerald-500 text-slate-700 dark:text-slate-200 font-medium inline-flex items-center gap-1.5 cursor-pointer"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Download</span>
                            </button>

                            {onEditImageInChat && (
                              <button
                                type="button"
                                onClick={() => onEditImageInChat(message.generatedImage!.prompt)}
                                className="min-h-[34px] px-2.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                              >
                                <Wand2 className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>
                            )}
                          </div>

                          {(message.generatedImage.provider || message.generatedImage.model) && (
                            <span className="text-[10.5px] text-slate-400 dark:text-slate-500">
                              {[message.generatedImage.provider, message.generatedImage.model]
                                .filter(Boolean)
                                .join(' · ')}
                            </span>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Real Search Sources Chips (Clickable Links) */}
            {message.groundingSources && message.groundingSources.length > 0 && (
              <div className="pt-2">
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                  <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Verified Web Sources ({message.groundingSources.length})</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {message.groundingSources.map((source, sIdx) => (
                    <a
                      key={sIdx}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#121627] dark:hover:bg-[#181e33] border border-slate-200 dark:border-slate-800 text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors max-w-xs truncate shadow-xs"
                      title={source.title}
                    >
                      <span className="truncate">{source.title || new URL(source.uri).hostname}</span>
                      <ExternalLink className="w-3 h-3 shrink-0 opacity-60" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Assistant Action Row: Copy | TTS | Retry | Feedback */}
            {!message.error && !message.isStreaming && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1.5 text-slate-600 dark:text-slate-400 text-xs">
                {/* Copy */}
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                  title="Copy response"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[11px]">Copy</span>
                    </>
                  )}
                </button>

                {/* Natural Voice Output (Gemini Studio / ElevenLabs / Device TTS) */}
                {isSupported && (
                  isThisActive ? (
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-600/40 text-emerald-900 dark:text-emerald-200 shadow-xs animate-fadeIn">
                        <div className="flex items-center gap-1 px-1">
                          {isThisLoading ? (
                            <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 animate-pulse">
                              Preparing voice...
                            </span>
                          ) : isThisPlaying ? (
                            <div className="flex items-center gap-1">
                              <div className="flex items-center gap-0.5 h-3">
                                <span className="w-0.5 h-2 bg-emerald-600 dark:bg-emerald-400 rounded-full animate-pulse" />
                                <span className="w-0.5 h-3.5 bg-emerald-600 dark:bg-emerald-400 rounded-full animate-pulse" style={{ animationDelay: '150ms' }} />
                                <span className="w-0.5 h-1.5 bg-emerald-600 dark:bg-emerald-400 rounded-full animate-pulse" style={{ animationDelay: '300ms' }} />
                              </div>
                              {totalChunks > 1 && (
                                <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-300">
                                  {chunkIndex}/{totalChunks}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-[10px] uppercase tracking-wider font-semibold text-emerald-600 dark:text-emerald-400">
                              Paused
                            </span>
                          )}
                        </div>
                        {!isThisLoading && (
                          <button
                            type="button"
                            onClick={handleToggleSpeak}
                            className="p-1 rounded-lg text-emerald-700 dark:text-emerald-300 hover:text-emerald-900 dark:hover:text-white cursor-pointer"
                            title={isThisPlaying ? 'Pause' : 'Resume'}
                            aria-label={isThisPlaying ? 'Pause voice' : 'Resume voice'}
                          >
                            {isThisPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={handleStopSpeak}
                          className="p-1 rounded-lg text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 cursor-pointer"
                          title="Stop voice"
                          aria-label="Stop voice"
                        >
                          <Square className="w-3 h-3 fill-current" />
                        </button>
                        {voiceName && (ttsSource === 'gemini' || ttsSource === 'elevenlabs') && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-200/60 dark:bg-emerald-900/50 text-emerald-900 dark:text-emerald-200">
                            {voiceName}
                          </span>
                        )}
                      </div>
                      {ttsNotice && (
                        <span className="text-[10px] text-amber-600 dark:text-amber-400 pl-1">
                          {ttsNotice}
                        </span>
                      )}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleToggleSpeak}
                      className="flex items-center gap-1.5 px-2 py-1 rounded-lg hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer text-slate-500 dark:text-slate-400"
                      title="Read response aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span className="text-[11px]">Read aloud</span>
                    </button>
                  )
                )}

                {/* Regenerate Action */}
                {isLast && onRegenerate && (
                  <button
                    onClick={onRegenerate}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                    title="Retry / Regenerate this response"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Retry</span>
                  </button>
                )}

                {/* Feedback */}
                <div className="flex items-center ml-1 border-l border-slate-200 dark:border-slate-800 pl-2">
                  <button
                    onClick={() => setFeedback(feedback === 'up' ? null : 'up')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      feedback === 'up'
                        ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40'
                        : 'hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                    }`}
                    title="Helpful response"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setFeedback(feedback === 'down' ? null : 'down')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      feedback === 'down'
                        ? 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40'
                        : 'hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                    }`}
                    title="Could be improved"
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Fullscreen Image Preview Modal */}
      {previewModalOpen && message.generatedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fadeIn"
          onClick={() => setPreviewModalOpen(false)}
        >
          <div
            className="relative max-w-4xl w-full max-h-[90vh] bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-md">
                {message.generatedImage.prompt}
              </span>
              <button
                onClick={() => setPreviewModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-black/95">
              <img
                src={message.generatedImage.url}
                alt={message.generatedImage.prompt}
                className="max-h-[72vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
              />
            </div>
            <div className="flex items-center justify-between p-4 border-t border-slate-200 dark:border-slate-800 text-xs">
              <button
                onClick={handleDownloadImage}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-semibold text-white transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download PNG</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

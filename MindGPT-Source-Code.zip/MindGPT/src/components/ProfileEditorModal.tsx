import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Upload,
  Check,
  Loader2,
  AlertCircle,
  CheckCircle2,
  LogOut,
  ShieldCheck,
  Database,
  User as UserIcon,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import {
  PRESET_AVATARS,
  AVATAR_BG_COLORS,
  buildPresetAvatarUrl,
  validateAvatarFile,
  AvatarCategory,
} from '../utils/avatars';

interface ProfileEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignOut: () => void;
}

type EditorAvatarTab = AvatarCategory | 'upload';

export function ProfileEditorModal({ isOpen, onClose, onSignOut }: ProfileEditorModalProps) {
  const {
    user,
    profile,
    saveProfile,
    uploadAvatar,
    firestoreStatus,
    firestoreMessage,
  } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [avatarType, setAvatarType] = useState<'google' | 'preset' | 'color' | 'upload'>('google');
  const [avatarId, setAvatarId] = useState<string>('male-1');
  const [avatarBg, setAvatarBg] = useState<string>('#10b981');
  const [activeTab, setActiveTab] = useState<EditorAvatarTab>('google');

  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync form state whenever modal opens or profile loads
  useEffect(() => {
    if (!isOpen || !user) return;
    const initDisplayName = profile?.displayName || user.displayName || 'MindGPT User';
    const initUsername =
      profile?.username ||
      (user.email?.split('@')[0] || 'mindgpt_user').toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const initPhoto = profile?.photoURL || user.photoURL || '';
    const initType = profile?.avatarType || 'google';
    const initBg = profile?.avatarBg || '#10b981';
    const initAvatarId = profile?.avatarId || 'male-1';

    setDisplayName(initDisplayName);
    setUsername(initUsername);
    setPhotoURL(initPhoto);
    setAvatarType(initType);
    setAvatarBg(initBg);
    setAvatarId(initAvatarId);
    setErrorMsg(null);
    setSuccessMsg(null);

    if (initType === 'upload') setActiveTab('upload');
    else if (initType === 'color') setActiveTab('color');
    else if (initType === 'preset' && initAvatarId.startsWith('female-')) setActiveTab('female');
    else if (initType === 'preset' && initAvatarId.startsWith('ai-')) setActiveTab('ai');
    else if (initType === 'preset') setActiveTab('male');
    else setActiveTab('google');
  }, [isOpen, user, profile]);

  if (!isOpen || !user) return null;

  const initialChar = (displayName || username || user.email || 'M').trim().charAt(0).toUpperCase() || 'M';

  const handleSelectGooglePhoto = () => {
    setErrorMsg(null);
    setAvatarType('google');
    setPhotoURL(user.photoURL || '');
  };

  const handleSelectPresetAvatar = (id: string, category: 'male' | 'female' | 'ai' | 'color', bgHex = avatarBg) => {
    setErrorMsg(null);
    setAvatarId(id);
    setAvatarBg(bgHex);
    setAvatarType(category === 'color' ? 'color' : 'preset');
    setPhotoURL(buildPresetAvatarUrl(id, bgHex, initialChar));
  };

  const handleSelectBgColor = (hex: string) => {
    setErrorMsg(null);
    setAvatarBg(hex);
    if (avatarType === 'preset' || avatarType === 'color') {
      setPhotoURL(buildPresetAvatarUrl(avatarId, hex, initialChar));
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const validationError = validateAvatarFile(file);
    if (validationError) {
      setErrorMsg(validationError);
      return;
    }

    setErrorMsg(null);
    setIsUploading(true);
    try {
      const uploadedUrl = await uploadAvatar(file);
      setAvatarType('upload');
      setPhotoURL(uploadedUrl);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to upload image.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanName = displayName.trim();
    const cleanUser = username.trim().toLowerCase();

    if (!cleanName || cleanName.length > 60) {
      setErrorMsg('Display Name is required (1 to 60 characters).');
      return;
    }
    if (!/^[a-z0-9_]{3,24}$/.test(cleanUser)) {
      setErrorMsg('Username must be 3 to 24 characters using letters, numbers, or underscores.');
      return;
    }

    setIsSaving(true);
    try {
      await saveProfile({
        displayName: cleanName,
        username: cleanUser,
        photoURL,
        avatarType,
        avatarId: avatarType === 'preset' || avatarType === 'color' ? avatarId : undefined,
        avatarBg: avatarType === 'preset' || avatarType === 'color' ? avatarBg : undefined,
      });
      setSuccessMsg('Profile saved successfully.');
      setTimeout(() => {
        onClose();
      }, 600);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Could not save profile updates.');
    } finally {
      setIsSaving(false);
    }
  };

  const presetItemsForTab = PRESET_AVATARS.filter((item) => item.category === activeTab);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 dark:bg-black/75 backdrop-blur-xs animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl text-slate-900 dark:text-slate-100 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
        data-testid="profile-editor-modal"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#090c16] shrink-0">
          <div className="flex items-center gap-2.5">
            <UserIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Edit Profile</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close profile editor"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-5 space-y-5 text-xs">
          {/* Live Avatar Preview Header */}
          <div className="flex items-center gap-4 p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800">
            <div className="relative w-16 h-16 rounded-full overflow-hidden shrink-0 border-2 border-emerald-500/70 shadow-sm bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
              {photoURL ? (
                <img
                  src={photoURL}
                  alt={displayName || 'Profile preview'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  data-testid="profile-preview-avatar"
                />
              ) : (
                <span className="text-xl font-bold text-slate-700 dark:text-slate-200">
                  {initialChar}
                </span>
              )}
              {isUploading && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-white animate-spin" />
                </div>
              )}
            </div>

            <div className="min-w-0 flex-1 space-y-0.5">
              <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                {displayName || 'MindGPT User'}
              </div>
              <div className="text-xs font-medium text-emerald-700 dark:text-emerald-400 truncate">
                @{username || 'username'}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {user.email}
              </div>
            </div>
          </div>

          {/* Alerts */}
          {errorMsg && (
            <div
              role="alert"
              className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* ONLY 3 Editable Fields: 1. Display Name, 2. Username, 3. Profile Picture */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="space-y-1.5">
              <label htmlFor="profile-display-name" className="block font-semibold text-slate-700 dark:text-slate-300">
                Display Name
              </label>
              <input
                id="profile-display-name"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                maxLength={60}
                placeholder="Your display name"
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#121626] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none text-xs"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="profile-username" className="block font-semibold text-slate-700 dark:text-slate-300">
                Username
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-3 text-slate-400 font-semibold">@</span>
                <input
                  id="profile-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  maxLength={24}
                  placeholder="username"
                  className="w-full pl-7 pr-3 py-2 rounded-xl bg-white dark:bg-[#121626] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:border-emerald-500 focus:outline-none text-xs"
                />
              </div>
            </div>
          </div>

          {/* 3. Profile Picture / Avatar Editor */}
          <div className="space-y-3 pt-1 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 dark:text-white">Profile Picture</span>
              <span className="text-[11px] text-slate-500">Choose photo, upload, or customize avatar</span>
            </div>

            {/* Avatar Editor Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'google', label: 'Google Photo' },
                { id: 'upload', label: 'Upload' },
                { id: 'male', label: 'Male' },
                { id: 'female', label: 'Female' },
                { id: 'ai', label: 'AI Style' },
                { id: 'color', label: 'Color Icons' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    const nextTab = tab.id as EditorAvatarTab;
                    setActiveTab(nextTab);
                    if (nextTab === 'google') {
                      handleSelectGooglePhoto();
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-semibold text-[11px] transition-colors cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab: Google Photo */}
            {activeTab === 'google' && (
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt="Google account"
                      referrerPolicy="no-referrer"
                      className="w-11 h-11 rounded-full object-cover border border-slate-300 dark:border-slate-700 shrink-0"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center shrink-0">
                      {initialChar}
                    </div>
                  )}
                  <div className="min-w-0">
                    <span className="font-semibold text-slate-900 dark:text-white block">
                      Original Google Photo
                    </span>
                    <span className="text-[11px] text-slate-500 block truncate">
                      {user.photoURL ? 'Synced from your Google account' : 'No Google photo set on account'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleSelectGooglePhoto}
                  className={`px-3 py-1.5 rounded-xl font-semibold text-[11px] cursor-pointer shrink-0 ${
                    avatarType === 'google'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  {avatarType === 'google' ? 'Selected' : 'Use Photo'}
                </button>
              </div>
            )}

            {/* Tab: Upload Image */}
            {activeTab === 'upload' && (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-2.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Upload className="w-6 h-6 mx-auto text-emerald-600 dark:text-emerald-400" />
                <div>
                  <p className="font-semibold text-slate-800 dark:text-slate-200">
                    Upload profile photo from device
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Supports JPG, PNG, WebP up to 2 MB
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold text-xs hover:opacity-90 transition-opacity cursor-pointer disabled:opacity-50"
                >
                  {isUploading ? 'Uploading...' : 'Choose Image File'}
                </button>
              </div>
            )}

            {/* Tab: Male / Female / AI / Color Icons + Background Colors */}
            {(activeTab === 'male' || activeTab === 'female' || activeTab === 'ai' || activeTab === 'color') && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                  {presetItemsForTab.map((item) => {
                    const url = buildPresetAvatarUrl(item.id, avatarBg, initialChar);
                    const isSelected =
                      (avatarType === 'preset' || avatarType === 'color') && avatarId === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectPresetAvatar(item.id, item.category, avatarBg)}
                        className={`p-1.5 rounded-2xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 ring-2 ring-emerald-500/20'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080b14] hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <img
                          src={url}
                          alt={item.label}
                          className="w-11 h-11 rounded-full object-cover"
                        />
                        <span className="text-[10px] font-medium text-slate-700 dark:text-slate-300 truncate max-w-full">
                          {item.label}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Selectable Background Colors */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                    Background Color:
                  </span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {AVATAR_BG_COLORS.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => handleSelectBgColor(c.hex)}
                        title={c.label}
                        style={{ backgroundColor: c.hex }}
                        className={`w-5 h-5 rounded-full flex items-center justify-center cursor-pointer transition-transform ${
                          avatarBg === c.hex ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white scale-110' : ''
                        }`}
                      >
                        {avatarBg === c.hex && <Check className="w-3 h-3 text-white stroke-[3]" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Transparent Auth vs Profile DB Status (Requirement 7) */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2 text-[11px]">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                Firebase Authentication
              </span>
              <span className="font-mono text-slate-600 dark:text-slate-400 truncate max-w-[190px]">
                UID: {user.uid}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
                <Database className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                User Profile Record
              </span>
              <span
                className={`font-semibold ${
                  firestoreStatus === 'synced'
                    ? 'text-emerald-700 dark:text-emerald-400'
                    : 'text-amber-700 dark:text-amber-400'
                }`}
              >
                {firestoreStatus === 'synced' ? 'Firestore Synced' : 'Verified API Stored'}
              </span>
            </div>
            {firestoreMessage && firestoreStatus !== 'synced' && (
              <p className="text-[10px] text-amber-700 dark:text-amber-300 leading-normal">
                {firestoreMessage}
              </p>
            )}
          </div>

          {/* Footer Save / Cancel + Sign Out */}
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                onClose();
                onSignOut();
              }}
              data-testid="profile-modal-logout"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 font-semibold text-xs transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving || isUploading}
                data-testid="profile-save-button"
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center gap-1.5 shadow-xs"
              >
                {isSaving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

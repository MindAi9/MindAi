import React from 'react';
import {
  MessageSquare,
  Sparkles,
  Paperclip,
  Mic,
  Code2,
  Compass,
  Lightbulb,
} from 'lucide-react';

interface WelcomeScreenProps {
  onSelectPrompt: (promptText: string) => void;
  onNewChat?: () => void;
  onTriggerImagePrompt?: () => void;
  onUploadFiles?: () => void;
  onVoiceInput?: () => void;
}

export function WelcomeScreen({
  onSelectPrompt,
  onNewChat,
  onTriggerImagePrompt,
  onUploadFiles,
  onVoiceInput,
}: WelcomeScreenProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 max-w-2xl mx-auto w-full text-center animate-fadeIn select-none">
      {/* Official MindGPT Brand Logo (Exact Uploaded Asset) */}
      <div className="relative mb-5">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-black border border-purple-500/40 shadow-xl shadow-purple-950/20 flex items-center justify-center mx-auto">
          <img
            src="/mindgpt-badge.png"
            alt="MindGPT"
            className="w-full h-full object-contain p-1"
          />
        </div>
      </div>

      {/* Main Home Screen Heading */}
      <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-2">
        What do you want to make?
      </h1>

      {/* Subtitle */}
      <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mb-6 leading-relaxed max-w-md mx-auto">
        Ask anything, create visual designs, write clean code, or explore ideas in English, Hindi, and Hinglish.
      </p>

      {/* Quick Action Options: New Chat | Image Generation | Upload Files | Voice Input */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full max-w-xl mx-auto mb-8">
        <button
          type="button"
          onClick={() => {
            if (onNewChat) onNewChat();
            else onSelectPrompt('Hello! How can you help me today?');
          }}
          className="flex flex-col items-center justify-center p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 group-hover:scale-105 transition-transform mb-2">
            <MessageSquare className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
            New Chat
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            if (onTriggerImagePrompt) onTriggerImagePrompt();
            else onSelectPrompt('Create a cinematic 3D wallpaper of a futuristic neon city at twilight');
          }}
          className="flex flex-col items-center justify-center p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 group-hover:scale-105 transition-transform mb-2">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
            Create Image
          </span>
        </button>

        <button
          type="button"
          onClick={onUploadFiles}
          className="flex flex-col items-center justify-center p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 group-hover:scale-105 transition-transform mb-2">
            <Paperclip className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400">
            Upload Files
          </span>
        </button>

        <button
          type="button"
          onClick={onVoiceInput}
          className="flex flex-col items-center justify-center p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 hover:border-amber-500 dark:hover:border-amber-500 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 group-hover:scale-105 transition-transform mb-2">
            <Mic className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-amber-600 dark:group-hover:text-amber-400">
            Voice Input
          </span>
        </button>
      </div>

      {/* Clean Conversation Starters */}
      <div className="w-full max-w-xl mx-auto space-y-2 text-left">
        {[
          {
            icon: Sparkles,
            text: 'Create a cinematic gaming poster of a cybernetic warrior',
          },
          {
            icon: Lightbulb,
            text: 'When is Diwali and Holi in 2026? Give exact dates and significance.',
          },
          {
            icon: Code2,
            text: 'Write a clean TypeScript utility for deep object comparison with edge cases.',
          },
          {
            icon: Compass,
            text: 'Who created MindGPT and what is the developer vision behind it?',
          },
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={() => onSelectPrompt(item.text)}
              className="w-full flex items-center gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-[#0a0d18] border border-slate-200/80 dark:border-slate-800/80 hover:border-emerald-500/40 hover:bg-slate-100 dark:hover:bg-[#121626] transition-all cursor-pointer text-left group"
            >
              <div className="p-1.5 rounded-lg bg-white dark:bg-slate-800/60 text-slate-500 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 shrink-0">
                <Icon className="w-4 h-4" />
              </div>
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white truncate">
                {item.text}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

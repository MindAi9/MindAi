import React from 'react';
import {
  ArrowRight,
  Code2,
  Brain,
  Shield,
  Zap,
  Layers,
  Image as ImageIcon,
  Video,
  PhoneCall,
  Bot,
  ChevronRight,
  MessageSquare,
  Globe2,
} from 'lucide-react';
import { ComingSoonFeature } from './ComingSoonModal';

interface LandingPageProps {
  onLaunchChat: () => void;
  onOpenLiveVoice: () => void;
  onOpenImageStudio: () => void;
  onOpenComingSoon: (feature: ComingSoonFeature) => void;
  onSelectPrompt: (prompt: string) => void;
}

export function LandingPage({
  onLaunchChat,
  onOpenLiveVoice,
  onOpenImageStudio,
  onOpenComingSoon,
  onSelectPrompt,
}: LandingPageProps) {
  return (
    <div className="min-h-full bg-[#07090e] text-slate-100 flex flex-col">
      {/* 3-Zone Top Bar Contract */}
      <nav className="sticky top-0 z-30 flex items-center justify-between gap-8 px-6 lg:px-12 py-4 bg-[#07090e]/95 backdrop-blur-md border-b border-slate-800/80">
        {/* Zone 1: Official Brand Logo & Wordmark */}
        <div className="flex items-center gap-3 shrink-0 cursor-pointer" onClick={onLaunchChat}>
          <div className="w-9 h-9 rounded-xl overflow-hidden bg-black border border-purple-500/40 shadow-sm flex items-center justify-center">
            <img
              src="/mindgpt-badge.png"
              alt="MindGPT Official"
              className="w-full h-full object-contain"
            />
          </div>
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            MindGPT
          </span>
        </div>

        {/* Zone 2: Nav Links */}
        <div className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-300">
          <a href="#features" className="hover:text-purple-300 transition-colors whitespace-nowrap">
            Features
          </a>
          <button
            onClick={onOpenLiveVoice}
            className="hover:text-purple-300 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
            <span>Live Voice</span>
          </button>
          <button
            onClick={onOpenImageStudio}
            className="hover:text-purple-300 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <ImageIcon className="w-3.5 h-3.5 text-blue-400" />
            <span>Image Studio</span>
          </button>
          <a href="#suite" className="hover:text-purple-300 transition-colors whitespace-nowrap">
            Cognitive Suite
          </a>
        </div>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onLaunchChat}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl transition-all shadow-md shadow-purple-900/30 cursor-pointer whitespace-nowrap"
          >
            <span>Launch Workspace</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative px-6 lg:px-12 pt-12 pb-16 max-w-6xl mx-auto w-full text-center overflow-hidden">
        {/* Ambient atmospheric gradients */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-purple-700/15 via-blue-700/10 to-transparent blur-[120px] pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          {/* Official Full Resolution Logo Card */}
          <div className="w-full max-w-md mx-auto rounded-3xl overflow-hidden shadow-2xl border border-purple-500/30 bg-black p-2 mb-4">
            <img
              src="/mindgpt-full-logo.png"
              alt="MindGPT Original Official Brand Asset"
              className="w-full h-auto object-contain rounded-2xl"
            />
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/40 border border-purple-800/40 text-xs text-purple-300">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            <span>Mind Turbo One & Mind Live Voice Engine</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] text-balance">
            High-velocity intelligence for{' '}
            <span className="bg-gradient-to-r from-purple-400 via-indigo-300 to-blue-400 bg-clip-text text-transparent">
              deep thought & code
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed text-balance">
            MindGPT is an original, production-grade AI cognitive workspace built for architects, engineers, and strategists. Real-time conversation in English, Hindi & Hinglish, real-time Live Voice, and native Image Generation.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={onLaunchChat}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:via-indigo-500 hover:to-blue-500 rounded-xl transition-all shadow-xl shadow-purple-900/40 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Start Free Conversation</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
            <button
              onClick={onOpenLiveVoice}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-[#0e1322] border border-purple-500/30 rounded-xl hover:border-purple-500/60 transition-colors cursor-pointer"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>Try Live Voice</span>
            </button>
            <button
              onClick={onOpenImageStudio}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-[#0e1322] border border-blue-500/30 rounded-xl hover:border-blue-500/60 transition-colors cursor-pointer"
            >
              <ImageIcon className="w-4 h-4 text-blue-400" />
              <span>Image Studio</span>
            </button>
          </div>

          <div className="flex items-center justify-center gap-6 pt-4 text-xs text-slate-400">
            <span>Server-side security</span>
            <span>·</span>
            <span>Sub-200ms latency</span>
            <span>·</span>
            <span>Zero login required</span>
          </div>
        </div>
      </section>

      {/* Core Features Bento Grid */}
      <section id="features" className="px-6 lg:px-12 py-16 max-w-6xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold tracking-wider uppercase text-purple-400">
            01. Core Architecture
          </span>
          <h2 className="text-3xl font-extrabold tracking-tight text-white mt-2">
            Engineered for precision and intellectual momentum
          </h2>
          <p className="text-sm text-slate-400 mt-2 leading-relaxed">
            Eliminate cognitive friction with native tools tailored for serious technical workflows.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: Live Voice */}
          <div
            onClick={onOpenLiveVoice}
            className="md:col-span-2 p-6 rounded-3xl bg-[#0b0f1b] border border-purple-500/30 hover:border-purple-500/60 transition-all shadow-xl cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <PhoneCall className="w-5 h-5 animate-pulse" />
              </div>
              <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2.5 py-0.5 rounded-full">
                Mind Live Voice
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-purple-200 transition-colors">
              Real-Time Two-Way Live Voice
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Low-latency conversational voice powered by Mind Live Voice. Speak naturally into your mic and listen to instant spoken answers. Interrupt the AI freely whenever you want.
            </p>
            <span className="text-xs font-semibold text-purple-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              <span>Start voice session</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Card 2: Multilingual Hindi/Hinglish */}
          <div className="p-6 rounded-3xl bg-[#0b0f1b] border border-slate-800 hover:border-slate-700 transition-all shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-4">
              <Globe2 className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Hindi & Hinglish Fluency</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              MindGPT understands and writes natural Hindi (हिंदी) and colloquial Hinglish natively alongside English without awkward literal translation.
            </p>
          </div>

          {/* Card 3: Image Studio */}
          <div
            onClick={onOpenImageStudio}
            className="p-6 rounded-3xl bg-[#0b0f1b] border border-blue-500/30 hover:border-blue-500/60 transition-all shadow-xl cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <ImageIcon className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-blue-400 bg-blue-950/40 border border-blue-800/40 px-2.5 py-0.5 rounded-full">
                Image Studio
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-blue-200 transition-colors">
              Native AI Image Synthesis
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              Generate original artwork, photorealistic concept renders, and diagrams with custom aspect ratios and lossless PNG downloads.
            </p>
            <span className="text-xs font-semibold text-blue-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              <span>Open Image Studio</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Card 4: Code & Architecture */}
          <div className="md:col-span-2 p-6 rounded-3xl bg-[#0b0f1b] border border-slate-800 hover:border-slate-700 transition-all shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4">
              <Code2 className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Production-Grade Code Synthesis</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              MindGPT structures typed interfaces, robust error boundaries, algorithm implementations, and unit test suites across modern stacks.
            </p>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="mt-auto px-6 lg:px-12 py-8 border-t border-slate-800/80 bg-[#06080d] text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-slate-400">
            <img src="/mindgpt-badge.png" alt="MindGPT" className="w-5 h-5 rounded-md object-contain" />
            <span className="font-bold text-white">MindGPT</span>
            <span>·</span>
            <span>Next-Generation AI Intelligence Platform</span>
          </div>

          <div className="flex items-center gap-6">
            <button onClick={onLaunchChat} className="hover:text-slate-300 transition-colors cursor-pointer">
              Workspace
            </button>
            <button onClick={onOpenLiveVoice} className="hover:text-slate-300 transition-colors cursor-pointer">
              Live Voice
            </button>
            <button onClick={onOpenImageStudio} className="hover:text-slate-300 transition-colors cursor-pointer">
              Image Studio
            </button>
          </div>

          <div className="text-[11px] text-slate-600">
            © {new Date().getFullYear()} MindGPT Cognitive Systems.
          </div>
        </div>
      </footer>
    </div>
  );
}

import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  X,
  Search,
  Sparkles,
  Layers,
  Archive,
  LogOut,
  Shuffle,
  Heart,
  Trash2,
  Download,
  Send,
  Calendar,
  Settings as SettingsIcon,
  Edit3,
  ChevronRight,
  Image as ImageIcon,
  Maximize2,
  Loader2,
} from 'lucide-react';
import { AppSettings, Conversation, LibraryImageRecord } from '../types';
import type { FirebaseUser, UserProfileRecord } from '../services/firebase';
import {
  CURATED_IMAGE_IDEAS,
  IMAGE_GALLERY_CATEGORIES,
  ImageGalleryIdea,
  shuffleGalleryIdeas,
} from '../data/imageGalleryIdeas';
import { GalleryArtwork } from './GalleryArtwork';
import { SettingsDrawerContent } from './SettingsDrawerContent';

export type DrawerType = 'settings' | 'profile' | 'image-library' | 'library' | 'archived' | null;

interface NavigationDrawerProps {
  type: DrawerType;
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  conversations: Conversation[];
  onSelectConversation: (id: string) => void;
  onClearAllConversations: () => void;
  onRestoreConversation?: (id: string) => void;
  onUsePromptInNewChat: (prompt: string) => void;
  onGenerateFromGallery?: (prompt: string) => void;
  onSwitchDrawer?: (type: DrawerType) => void;
  firebaseUser?: FirebaseUser | null;
  userProfile?: UserProfileRecord | null;
  onOpenProfileEditor?: () => void;
  onSignOut?: () => void;
  libraryImages: LibraryImageRecord[];
  libraryLoading?: boolean;
  onToggleLibraryFavorite: (id: string) => Promise<void>;
  onDeleteLibraryImage: (id: string) => Promise<void>;
}

export function NavigationDrawer({
  type,
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  conversations,
  onClearAllConversations,
  onRestoreConversation,
  onUsePromptInNewChat,
  onGenerateFromGallery,
  onSwitchDrawer,
  firebaseUser,
  userProfile,
  onOpenProfileEditor,
  onSignOut,
  libraryImages,
  libraryLoading = false,
  onToggleLibraryFavorite,
  onDeleteLibraryImage,
}: NavigationDrawerProps) {
  // Image Discovery Gallery state
  const [shuffledIdeas, setShuffledIdeas] = useState<ImageGalleryIdea[]>(() =>
    shuffleGalleryIdeas(CURATED_IMAGE_IDEAS)
  );
  const [selectedGalleryCategory, setSelectedGalleryCategory] = useState<string>('All Images');
  const [gallerySearch, setGallerySearch] = useState('');
  const [selectedGalleryIdea, setSelectedGalleryIdea] = useState<ImageGalleryIdea | null>(null);
  const [editedGalleryPrompt, setEditedGalleryPrompt] = useState('');

  // Private Library state
  const [libraryFilter, setLibraryFilter] = useState<'all' | 'favorites'>('all');
  const [librarySearch, setLibrarySearch] = useState('');
  const [previewImage, setPreviewImage] = useState<LibraryImageRecord | null>(null);
  const [confirmDeleteImgId, setConfirmDeleteImgId] = useState<string | null>(null);

  // Randomize discovery cards whenever Images gallery opens
  useEffect(() => {
    if (isOpen && type === 'image-library') {
      setShuffledIdeas(shuffleGalleryIdeas(CURATED_IMAGE_IDEAS));
    }
    if (!isOpen) {
      setPreviewImage(null);
      setSelectedGalleryIdea(null);
      setConfirmDeleteImgId(null);
    }
  }, [isOpen, type]);

  const filteredGalleryIdeas = useMemo(() => {
    const q = gallerySearch.trim().toLowerCase();
    return shuffledIdeas.filter((item) => {
      if (selectedGalleryCategory !== 'All Images' && item.category !== selectedGalleryCategory) {
        return false;
      }
      if (q) {
        return (
          item.title.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.prompt.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [shuffledIdeas, selectedGalleryCategory, gallerySearch]);

  const filteredLibraryImages = useMemo(() => {
    return libraryImages.filter((item) => {
      if (libraryFilter === 'favorites' && !item.favorite) return false;
      if (librarySearch.trim()) {
        return item.prompt.toLowerCase().includes(librarySearch.trim().toLowerCase());
      }
      return true;
    });
  }, [libraryImages, libraryFilter, librarySearch]);

  // Keep fullscreen preview image synced when favorite toggles
  const activePreviewImage = useMemo(() => {
    if (!previewImage) return null;
    return libraryImages.find((img) => img.id === previewImage.id) || previewImage;
  }, [previewImage, libraryImages]);

  if (!isOpen || !type) return null;

  const archivedConversations = conversations.filter((c) => c.isArchived);

  const getTitle = () => {
    switch (type) {
      case 'settings':
        return 'Settings';
      case 'profile':
        return 'Account & Profile';
      case 'image-library':
        return 'Images · Discovery Gallery';
      case 'library':
        return 'My Library';
      case 'archived':
        return 'Archived Chats';
      default:
        return '';
    }
  };

  const handleDownloadLibraryImage = (img: LibraryImageRecord) => {
    const a = document.createElement('a');
    a.href = img.imageUrl;
    a.download = `mindgpt-${img.id}.jpg`;
    a.click();
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-black/50 dark:bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Full-Height Slide-in Panel */}
      <aside
        data-testid={`drawer-panel-${type}`}
        className="fixed inset-y-0 right-0 z-50 w-full sm:w-[490px] md:w-[540px] bg-white dark:bg-[#0c101c] border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col text-slate-800 dark:text-slate-100 select-none animate-fadeIn"
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between h-14 px-4 sm:px-5 border-b border-slate-200 dark:border-slate-800 shrink-0 bg-slate-50/80 dark:bg-[#090c16]">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onClose}
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
              title="Back to chat"
              aria-label="Back to chat"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white truncate">
              {getTitle()}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close drawer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1. IMAGES: CURATED DISCOVERY GALLERY */}
        {type === 'image-library' && (
          <div className="flex-1 flex flex-col min-h-0" data-testid="image-discovery-gallery">
            {/* Subheader + Search + Shuffle */}
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-[#080b14] space-y-2.5 shrink-0">
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Tap any image to inspect, customize its prompt, and generate.
                </p>
                <button
                  type="button"
                  onClick={() => setShuffledIdeas(shuffleGalleryIdeas(CURATED_IMAGE_IDEAS))}
                  data-testid="gallery-shuffle-button"
                  className="shrink-0 min-h-[36px] px-3 py-1.5 rounded-xl bg-white dark:bg-[#131929] border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-emerald-500 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Shuffle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Shuffle</span>
                </button>
              </div>

              {/* Search Input */}
              <div className="relative flex items-center">
                <Search className="absolute left-3 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={gallerySearch}
                  onChange={(e) => setGallerySearch(e.target.value)}
                  placeholder="Search styles, subjects, or prompts..."
                  data-testid="gallery-search-input"
                  className="w-full pl-8 pr-7 py-2 text-xs rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none"
                />
                {gallerySearch && (
                  <button
                    type="button"
                    onClick={() => setGallerySearch('')}
                    className="absolute right-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                    aria-label="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Horizontal Category Scroller */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {IMAGE_GALLERY_CATEGORIES.map((cat) => {
                  const isActive = selectedGalleryCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedGalleryCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                        isActive
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-emerald-500/50'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Responsive Inspiration Grid */}
            <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5 content-start">
              {filteredGalleryIdeas.length === 0 ? (
                <div className="sm:col-span-2 py-14 px-6 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl space-y-2">
                  <ImageIcon className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                    No matching image styles found
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setGallerySearch('');
                      setSelectedGalleryCategory('All Images');
                    }}
                    className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                  >
                    Reset filters
                  </button>
                </div>
              ) : (
                filteredGalleryIdeas.map((idea) => {
                  const openDetail = () => {
                    setSelectedGalleryIdea(idea);
                    setEditedGalleryPrompt(idea.prompt);
                  };
                  return (
                    <div
                      key={idea.id}
                      onClick={openDetail}
                      data-testid={`gallery-idea-${idea.id}`}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          openDetail();
                        }
                      }}
                      className="group text-left rounded-2xl overflow-hidden bg-white dark:bg-[#0e1322] border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs hover:shadow-md transition-all flex flex-col cursor-pointer"
                    >
                      <GalleryArtwork idea={idea} />
                      <div className="p-3.5 flex-1 flex flex-col justify-between gap-2.5">
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
                            {idea.category}
                          </span>
                          <h3 className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                            {idea.title}
                          </h3>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
                            {idea.description}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onGenerateFromGallery) {
                              onGenerateFromGallery(idea.prompt);
                              onClose();
                            } else {
                              onUsePromptInNewChat(idea.prompt);
                              onClose();
                            }
                          }}
                          className="w-full min-h-[38px] px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Generate</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* 2. LIBRARY: PRIVATE AUTHENTICATED USER GENERATED & EDITED IMAGES ONLY */}
        {type === 'library' && (
          <div className="flex-1 flex flex-col min-h-0" data-testid="user-private-library">
            {/* Search & All / Favorites Filter */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-[#080b14] space-y-3 shrink-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Private to {userProfile?.displayName || firebaseUser?.email || 'your account'} · {libraryImages.length} saved
                </span>
                <div className="flex items-center gap-1 bg-slate-200/70 dark:bg-slate-800/80 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setLibraryFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                      libraryFilter === 'all'
                        ? 'bg-white dark:bg-[#0c101c] text-slate-900 dark:text-white shadow-2xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    All ({libraryImages.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLibraryFilter('favorites')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors flex items-center gap-1 ${
                      libraryFilter === 'favorites'
                        ? 'bg-white dark:bg-[#0c101c] text-rose-600 dark:text-rose-400 shadow-2xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Heart className="w-3 h-3" />
                    <span>Saved ({libraryImages.filter((i) => i.favorite).length})</span>
                  </button>
                </div>
              </div>

              {libraryImages.length > 0 && (
                <div className="relative flex items-center">
                  <Search className="absolute left-3 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
                  <input
                    type="text"
                    value={librarySearch}
                    onChange={(e) => setLibrarySearch(e.target.value)}
                    placeholder="Filter your saved prompts..."
                    className="w-full pl-8 pr-7 py-2 text-xs rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none"
                  />
                  {librarySearch && (
                    <button
                      type="button"
                      onClick={() => setLibrarySearch('')}
                      className="absolute right-2.5 text-slate-400 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Library Grid */}
            <div className="flex-1 overflow-y-auto p-4 text-xs">
              {libraryLoading ? (
                <div className="py-20 flex flex-col items-center justify-center gap-2 text-slate-500">
                  <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
                  <span>Loading your private library...</span>
                </div>
              ) : filteredLibraryImages.length === 0 ? (
                <div className="py-16 px-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl space-y-3">
                  <Layers className="w-9 h-9 text-slate-400 mx-auto" />
                  <div className="space-y-1">
                    <p className="font-bold text-sm text-slate-800 dark:text-slate-200">
                      {libraryFilter === 'favorites'
                        ? 'No favorited images yet'
                        : 'Your Library is empty'}
                    </p>
                    <p className="text-slate-500 dark:text-slate-400 max-w-xs mx-auto leading-relaxed">
                      {libraryFilter === 'favorites'
                        ? 'Tap the heart button on any of your generated images to bookmark it here.'
                        : 'Images you generate or edit in MindGPT chats are saved here privately under your account.'}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => onSwitchDrawer?.('image-library')}
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>Browse Image Ideas</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {filteredLibraryImages.map((img) => (
                    <div
                      key={img.id}
                      className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0e1322] shadow-xs flex flex-col"
                    >
                      <div
                        onClick={() => setPreviewImage(img)}
                        className="relative aspect-square bg-slate-100 dark:bg-slate-900 cursor-pointer group overflow-hidden"
                      >
                        <img
                          src={img.imageUrl}
                          alt={img.prompt}
                          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                        />
                        <div className="absolute top-2 right-2 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              void onToggleLibraryFavorite(img.id);
                            }}
                            className={`w-8 h-8 rounded-full backdrop-blur-md flex items-center justify-center transition-colors cursor-pointer ${
                              img.favorite
                                ? 'bg-rose-600 text-white shadow-sm'
                                : 'bg-black/45 text-white hover:bg-black/65'
                            }`}
                            title={img.favorite ? 'Remove from saved favorites' : 'Save favorite'}
                            aria-label="Toggle favorite"
                          >
                            <Heart className={`w-3.5 h-3.5 ${img.favorite ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="p-1.5 rounded-lg bg-black/55 text-white inline-flex">
                            <Maximize2 className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>

                      <div className="p-3 space-y-2.5 flex-1 flex flex-col justify-between">
                        <div>
                          <p className="text-xs font-medium text-slate-800 dark:text-slate-100 line-clamp-2 leading-snug">
                            {img.prompt}
                          </p>
                          <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[10px] text-slate-400">
                            <Calendar className="w-3 h-3 shrink-0" />
                            <span>{new Date(img.createdAt).toLocaleDateString()}</span>
                            {img.provider && <span>· {img.provider}</span>}
                            {img.model && <span className="truncate max-w-[110px]">· {img.model}</span>}
                            {img.isEdit && <span>· Edited</span>}
                          </div>
                        </div>

                        {confirmDeleteImgId === img.id ? (
                          <div className="p-2 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 flex items-center justify-between gap-2">
                            <span className="text-[11px] font-semibold text-red-700 dark:text-red-300">
                              Delete image?
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  void onDeleteLibraryImage(img.id);
                                  setConfirmDeleteImgId(null);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-red-600 text-white text-[11px] font-semibold cursor-pointer"
                              >
                                Delete
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteImgId(null)}
                                className="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between gap-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                            <button
                              type="button"
                              onClick={() => {
                                onUsePromptInNewChat(img.prompt);
                                onClose();
                              }}
                              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold text-[11px] hover:bg-emerald-100 dark:hover:bg-emerald-900/50 cursor-pointer"
                              title="Reuse prompt in new chat"
                            >
                              <Send className="w-3 h-3" />
                              <span>Use Prompt</span>
                            </button>

                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleDownloadLibraryImage(img)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                title="Download image"
                                aria-label="Download image"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteImgId(img.id)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                                title="Delete from Library"
                                aria-label="Delete image"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. PROFILE DRAWER VIEW */}
        {type === 'profile' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs" data-testid="profile-drawer-view">
            {/* Profile Header Card */}
            <div className="p-4 rounded-3xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center gap-3.5">
                {(userProfile?.photoURL || firebaseUser?.photoURL) ? (
                  <img
                    src={userProfile?.photoURL || firebaseUser?.photoURL || ''}
                    alt={userProfile?.displayName || firebaseUser?.displayName || 'User'}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-full object-cover shrink-0 border-2 border-emerald-500/60 shadow-xs"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-emerald-600 text-white font-bold text-xl flex items-center justify-center shrink-0 shadow-xs">
                    {(userProfile?.displayName || firebaseUser?.displayName || settings.userNickname || 'M')
                      .charAt(0)
                      .toUpperCase()}
                  </div>
                )}

                <div className="min-w-0 flex-1 space-y-0.5">
                  <h3
                    data-testid="profile-drawer-name"
                    className="font-bold text-slate-900 dark:text-white text-base truncate"
                  >
                    {userProfile?.displayName || firebaseUser?.displayName || settings.userNickname || 'MindGPT User'}
                  </h3>
                  {userProfile?.username && (
                    <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 truncate">
                      @{userProfile.username}
                    </p>
                  )}
                  <p
                    data-testid="profile-drawer-email"
                    className="text-slate-500 dark:text-slate-400 text-[11px] truncate"
                  >
                    {firebaseUser?.email || 'Signed in with Google'}
                  </p>
                </div>
              </div>

              {onOpenProfileEditor && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenProfileEditor();
                  }}
                  data-testid="profile-drawer-edit-button"
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 text-center">
                <div>
                  <span className="text-[11px] text-slate-400 block">Chats</span>
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{conversations.length}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Library</span>
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{libraryImages.length}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Theme</span>
                  <span className="font-bold text-sm text-slate-900 dark:text-white capitalize">{settings.theme}</span>
                </div>
              </div>
            </div>

            {/* Quick Navigation Cards */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => onSwitchDrawer?.('settings')}
                data-testid="profile-open-settings-button"
                className="w-full min-h-[52px] px-4 py-3 rounded-2xl bg-white dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 flex items-center justify-between cursor-pointer transition-colors"
              >
                <span className="flex items-center gap-3 font-semibold text-slate-900 dark:text-white">
                  <SettingsIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Open Full Settings (16 Categories)</span>
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                type="button"
                onClick={() => onSwitchDrawer?.('library')}
                className="w-full min-h-[52px] px-4 py-3 rounded-2xl bg-white dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 hover:border-blue-500/60 flex items-center justify-between cursor-pointer transition-colors"
              >
                <span className="flex items-center gap-3 font-semibold text-slate-900 dark:text-white">
                  <Layers className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span>My Image Library ({libraryImages.length})</span>
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                type="button"
                onClick={() => onSwitchDrawer?.('archived')}
                className="w-full min-h-[52px] px-4 py-3 rounded-2xl bg-white dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 hover:border-slate-400 flex items-center justify-between cursor-pointer transition-colors"
              >
                <span className="flex items-center gap-3 font-semibold text-slate-900 dark:text-white">
                  <Archive className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>Archived Chats ({archivedConversations.length})</span>
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Creator Credit */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                <span>About MindGPT</span>
              </span>
              <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                Created by Ragib with the vision to make AI useful, accessible, and intelligent for everyone.
              </p>
            </div>

            {/* Sign Out */}
            {firebaseUser && onSignOut && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onSignOut();
                }}
                data-testid="drawer-logout-button"
                className="w-full min-h-[46px] py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of MindGPT</span>
              </button>
            )}
          </div>
        )}

        {/* 4. COMPLETE SEARCHABLE SETTINGS SYSTEM */}
        {type === 'settings' && (
          <SettingsDrawerContent
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            conversations={conversations}
            libraryImages={libraryImages}
            onClearAllConversations={onClearAllConversations}
            onOpenArchived={() => onSwitchDrawer?.('archived')}
            onOpenProfileEditor={() => {
              onClose();
              onOpenProfileEditor?.();
            }}
            onSignOut={onSignOut ? () => { onClose(); onSignOut(); } : undefined}
            firebaseUser={firebaseUser}
            userProfile={userProfile}
          />
        )}

        {/* 5. ARCHIVED CHATS VIEW */}
        {type === 'archived' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-3 text-xs">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-0.5">Archived Chats</h3>
              <p className="text-slate-500">
                Conversations moved out of your active history ({archivedConversations.length})
              </p>
            </div>

            {archivedConversations.length === 0 ? (
              <div className="py-16 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-6">
                <Archive className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-700 dark:text-slate-300">No archived chats</p>
              </div>
            ) : (
              <div className="space-y-2">
                {archivedConversations.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0e1220] border border-slate-200 dark:border-slate-800 gap-2"
                  >
                    <span className="truncate font-medium text-slate-800 dark:text-slate-200">{c.title}</span>
                    {onRestoreConversation && (
                      <button
                        type="button"
                        onClick={() => onRestoreConversation(c.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold cursor-pointer shrink-0"
                      >
                        Unarchive
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </aside>

      {/* Detail View Modal for Gallery Image Idea */}
      {selectedGalleryIdea && (
        <div
          className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn"
          onClick={() => setSelectedGalleryIdea(null)}
          data-testid="gallery-detail-modal"
        >
          <div
            className="w-full max-w-xl bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
              <div className="min-w-0">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
                  {selectedGalleryIdea.category}
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {selectedGalleryIdea.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedGalleryIdea(null)}
                className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                aria-label="Close detail view"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1">
              <div className="aspect-[4/3] w-full bg-slate-950 overflow-hidden">
                <img
                  src={selectedGalleryIdea.previewImageUrl}
                  alt={selectedGalleryIdea.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="p-4 space-y-3 text-xs">
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {selectedGalleryIdea.description}
                </p>

                <div className="space-y-1.5">
                  <label
                    htmlFor="gallery-detail-prompt"
                    className="block text-[11px] font-semibold text-slate-700 dark:text-slate-200"
                  >
                    Prompt
                  </label>
                  <textarea
                    id="gallery-detail-prompt"
                    value={editedGalleryPrompt}
                    onChange={(e) => setEditedGalleryPrompt(e.target.value)}
                    rows={3}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-100 leading-relaxed focus:border-emerald-500 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-end gap-2 bg-slate-50/70 dark:bg-[#090c16]">
              <button
                type="button"
                onClick={() => {
                  const finalPrompt = editedGalleryPrompt.trim() || selectedGalleryIdea.prompt;
                  setSelectedGalleryIdea(null);
                  onUsePromptInNewChat(finalPrompt);
                  onClose();
                }}
                className="min-h-[42px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit in Composer</span>
              </button>
              <button
                type="button"
                data-testid="gallery-detail-generate-btn"
                onClick={() => {
                  const finalPrompt = editedGalleryPrompt.trim() || selectedGalleryIdea.prompt;
                  setSelectedGalleryIdea(null);
                  if (onGenerateFromGallery) {
                    onGenerateFromGallery(finalPrompt);
                  } else {
                    onUsePromptInNewChat(finalPrompt);
                  }
                  onClose();
                }}
                className="min-h-[42px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Generate</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Lightbox Preview for User's Library Image */}
      {activePreviewImage && (
        <div
          className="fixed inset-0 z-[60] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="w-full max-w-2xl bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold text-slate-500">
                <span>Created {new Date(activePreviewImage.createdAt).toLocaleString()}</span>
                {activePreviewImage.provider && <span>· {activePreviewImage.provider}</span>}
                {activePreviewImage.model && <span>· {activePreviewImage.model}</span>}
              </div>
              <button
                type="button"
                onClick={() => setPreviewImage(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                aria-label="Close preview"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-black flex items-center justify-center max-h-[55vh] overflow-hidden">
              <img
                src={activePreviewImage.imageUrl}
                alt={activePreviewImage.prompt}
                className="max-h-[55vh] w-auto object-contain"
              />
            </div>

            <div className="p-4 space-y-3 text-xs">
              <p className="text-slate-800 dark:text-slate-100 leading-relaxed font-medium">
                {activePreviewImage.prompt}
              </p>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    onUsePromptInNewChat(activePreviewImage.prompt);
                    setPreviewImage(null);
                    onClose();
                  }}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Use Prompt in New Chat</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void onToggleLibraryFavorite(activePreviewImage.id)}
                    className={`min-h-[40px] px-3 py-2 rounded-xl border font-semibold flex items-center gap-1.5 cursor-pointer ${
                      activePreviewImage.favorite
                        ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${activePreviewImage.favorite ? 'fill-current' : ''}`} />
                    <span>{activePreviewImage.favorite ? 'Saved' : 'Save'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDownloadLibraryImage(activePreviewImage)}
                    className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const targetId = activePreviewImage.id;
                      setPreviewImage(null);
                      void onDeleteLibraryImage(targetId);
                    }}
                    className="min-h-[40px] px-3 py-2 rounded-xl border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 font-semibold flex items-center gap-1.5 cursor-pointer hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

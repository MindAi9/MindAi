import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Download,
  Copy,
  Check,
  AlertCircle,
  Maximize2,
  X,
  Layers,
  Image as ImageIcon,
  Wand2,
  RotateCcw,
  Upload,
} from 'lucide-react';

interface GeneratedImage {
  id: string;
  imageUrl: string;
  prompt: string;
  aspectRatio: string;
  style: string;
  isEdit?: boolean;
  createdAt: number;
}

interface ImageStudioProps {
  initialMode?: 'generate' | 'edit';
  onBackToChat?: () => void;
}

export function ImageStudio({ initialMode = 'generate' }: ImageStudioProps) {
  const [activeTab, setActiveTab] = useState<'generate' | 'edit'>(initialMode);
  const [prompt, setPrompt] = useState('');
  const [editPrompt, setEditPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [style, setStyle] = useState('photorealistic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStage, setLoadingStage] = useState(1);
  const [error, setError] = useState<string | null>(null);

  // Reference image for editing
  const [referenceImage, setReferenceImage] = useState<{
    data: string;
    name: string;
    type: string;
  } | null>(null);

  const [history, setHistory] = useState<GeneratedImage[]>(() => {
    try {
      const saved = localStorage.getItem('mindgpt_image_history_v2');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [previewImage, setPreviewImage] = useState<GeneratedImage | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const refFileInputRef = useRef<HTMLInputElement>(null);

  // Dream Core Loading Animation Stage Stepper
  useEffect(() => {
    if (!isGenerating) {
      setLoadingStage(1);
      return;
    }
    const t1 = setTimeout(() => setLoadingStage(2), 2200);
    const t2 = setTimeout(() => setLoadingStage(3), 5200);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [isGenerating]);

  const saveHistory = (items: GeneratedImage[]) => {
    setHistory(items);
    try {
      localStorage.setItem('mindgpt_image_history_v2', JSON.stringify(items));
    } catch {}
  };

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setError(null);

    try {
      const res = await fetch('/api/images/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          style,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate image.');
      }

      const newImage: GeneratedImage = {
        id: `img-${Date.now()}`,
        imageUrl: data.imageUrl,
        prompt: data.prompt,
        aspectRatio: data.aspectRatio,
        style: data.style,
        createdAt: data.createdAt || Date.now(),
      };

      saveHistory([newImage, ...history]);
      setPreviewImage(newImage);
    } catch (err: any) {
      console.error('Image gen failed:', err);
      setError(err?.message || 'Failed to generate image. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEditImage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editPrompt.trim() || !referenceImage || isGenerating) return;

    setIsGenerating(true);
    setError(null);

    try {
      const res = await fetch('/api/images/edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: editPrompt.trim(),
          imageBase64: referenceImage.data,
          mimeType: referenceImage.type,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to edit image.');
      }

      const newImage: GeneratedImage = {
        id: `img-edit-${Date.now()}`,
        imageUrl: data.imageUrl,
        prompt: data.prompt,
        aspectRatio: 'Original',
        style: 'Custom Edit',
        isEdit: true,
        createdAt: data.createdAt || Date.now(),
      };

      saveHistory([newImage, ...history]);
      setPreviewImage(newImage);
    } catch (err: any) {
      console.error('Image edit failed:', err);
      setError(err?.message || 'Failed to edit image. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRefImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setReferenceImage({
        data: reader.result as string,
        name: file.name,
        type: file.type || 'image/png',
      });
    };
    reader.readAsDataURL(file);
  };

  const handleDownload = (img: GeneratedImage) => {
    const a = document.createElement('a');
    a.href = img.imageUrl;
    a.download = `mindgpt-${img.prompt.slice(0, 24).replace(/[^a-zA-Z0-9]/g, '_')}-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const handleCopyPrompt = (img: GeneratedImage) => {
    navigator.clipboard.writeText(img.prompt);
    setCopiedId(img.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-slate-50 dark:bg-[#07090e] text-slate-800 dark:text-slate-100 p-4 sm:p-8 transition-colors">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                MindGPT Generative Vision
              </span>
              <span className="text-[10px] font-mono text-purple-700 dark:text-purple-300 bg-purple-100 dark:bg-purple-950/50 border border-purple-200 dark:border-purple-800/40 px-2 py-0.5 rounded">
                Mind Neural Vision
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Image Studio
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Create original visuals from text or modify existing photos with AI.
            </p>
          </div>

          {/* Mode Switcher: Text to Image vs Image Editing */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 dark:bg-[#101424] rounded-2xl border border-slate-300 dark:border-slate-800 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setActiveTab('generate')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'generate'
                  ? 'bg-white dark:bg-emerald-600 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Create</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('edit')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'edit'
                  ? 'bg-white dark:bg-emerald-600 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>Edit Image</span>
            </button>
          </div>
        </div>

        {/* DREAM CORE LOADING ANIMATION (Rendered while isGenerating is true) */}
        {isGenerating && (
          <div className="relative overflow-hidden rounded-3xl p-8 sm:p-12 bg-slate-900 text-white flex flex-col items-center justify-center text-center shadow-2xl border border-purple-500/30 animate-fadeIn">
            {/* Ambient Background Aura */}
            <div className="absolute inset-0 bg-radial from-purple-900/40 via-cyan-950/20 to-black/90 pointer-events-none" />

            {/* Glowing Orb & Concentric Rings */}
            <div className="relative w-36 h-36 sm:w-44 sm:h-44 flex items-center justify-center my-4">
              {/* Outer Cyan Ring */}
              <div
                className="absolute inset-0 rounded-full border-2 border-dashed border-cyan-400/50 animate-spin"
                style={{ animationDuration: '9s' }}
              />
              {/* Middle Purple Ring */}
              <div
                className="absolute inset-3 rounded-full border-2 border-dashed border-purple-500/60 animate-spin"
                style={{ animationDuration: '6s', animationDirection: 'reverse' }}
              />
              {/* Inner Glowing Energy Core */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-cyan-400 via-purple-600 to-indigo-500 animate-pulse shadow-[0_0_60px_rgba(168,85,247,0.9)] flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-white animate-spin" style={{ animationDuration: '4s' }} />
              </div>
            </div>

            {/* Stage Indicators */}
            <div className="relative z-10 space-y-2 mt-4 max-w-md">
              <span className="text-[11px] font-mono uppercase tracking-widest text-cyan-300">
                Dream Core Synthesis · Stage {loadingStage} of 3
              </span>
              <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white transition-all">
                {loadingStage === 1 && '1. Prompt understood'}
                {loadingStage === 2 && '2. Building your visual universe'}
                {loadingStage === 3 && '3. Revealing your masterpiece'}
              </h3>
              <p className="text-xs text-slate-300/80">
                MindGPT's neural rendering pipeline is synthesizing high-resolution details...
              </p>
            </div>
          </div>
        )}

        {/* 1. TEXT TO IMAGE TAB */}
        {activeTab === 'generate' && !isGenerating && (
          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 focus-within:border-emerald-500 dark:focus-within:border-emerald-500/70 shadow-sm transition-all">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to create... (e.g. 'A futuristic city floating inside a glass bubble at twilight, cinematic lighting, sharp reflections, 8k resolution')"
                rows={3}
                className="w-full bg-transparent text-sm sm:text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none resize-none leading-relaxed"
              />

              <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                {/* Aspect Ratio */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Aspect Ratio:</span>
                  <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#121626] rounded-xl border border-slate-200 dark:border-slate-800">
                    {[
                      { id: '1:1', label: '1:1 Square' },
                      { id: '16:9', label: '16:9 Wide' },
                      { id: '9:16', label: '9:16 Tall' },
                      { id: '4:3', label: '4:3 Classic' },
                    ].map((ratio) => (
                      <button
                        key={ratio.id}
                        type="button"
                        onClick={() => setAspectRatio(ratio.id)}
                        className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                          aspectRatio === ratio.id
                            ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {ratio.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Art Style */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Style:</span>
                  <select
                    value={style}
                    onChange={(e) => setStyle(e.target.value)}
                    className="px-3 py-1.5 text-xs font-medium bg-slate-100 dark:bg-[#121626] border border-slate-200 dark:border-slate-800 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
                  >
                    <option value="photorealistic">Photorealistic</option>
                    <option value="digital-art">Digital Concept Art</option>
                    <option value="cyberpunk">Cyberpunk Neon</option>
                    <option value="3d-render">3D Isometric Render</option>
                    <option value="anime">Anime Cinema</option>
                    <option value="natural">Natural Style</option>
                  </select>
                </div>

                {/* Generate Button */}
                <button
                  type="submit"
                  disabled={!prompt.trim() || isGenerating}
                  className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white transition-all shadow-md cursor-pointer ${
                    !prompt.trim() || isGenerating
                      ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Image</span>
                </button>
              </div>
            </div>
          </form>
        )}

        {/* 2. IMAGE EDITING TAB */}
        {activeTab === 'edit' && !isGenerating && (
          <form onSubmit={handleEditImage} className="space-y-4">
            <input
              ref={refFileInputRef}
              type="file"
              accept="image/*"
              onChange={handleRefImageSelect}
              className="hidden"
            />

            <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-[#0c101d] border border-slate-200 dark:border-slate-800 focus-within:border-emerald-500 dark:focus-within:border-emerald-500/70 shadow-sm transition-all space-y-4">
              {/* Reference image upload area */}
              {referenceImage ? (
                <div className="relative w-full max-h-56 bg-slate-100 dark:bg-[#101424] rounded-2xl overflow-hidden flex items-center justify-center border border-slate-200 dark:border-slate-800 p-2">
                  <img
                    src={referenceImage.data}
                    alt={referenceImage.name}
                    className="max-h-52 w-auto object-contain rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => setReferenceImage(null)}
                    className="absolute top-3 right-3 p-1.5 rounded-full bg-black/60 text-white hover:bg-black transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => refFileInputRef.current?.click()}
                  className="py-10 px-4 text-center rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 cursor-pointer bg-slate-50/50 dark:bg-[#0d1222] transition-colors"
                >
                  <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Click to upload a reference image to edit
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">Supports JPG, PNG, WEBP</p>
                </div>
              )}

              {/* Edit instruction prompt */}
              <textarea
                value={editPrompt}
                onChange={(e) => setEditPrompt(e.target.value)}
                placeholder="Describe how to edit this image... (e.g. 'Add neon glowing highlights, replace the background with an ethereal night sky, increase sharpness')"
                rows={2}
                className="w-full bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none resize-none leading-relaxed"
              />

              <div className="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="submit"
                  disabled={!editPrompt.trim() || !referenceImage || isGenerating}
                  className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white transition-all shadow-md cursor-pointer ${
                    !editPrompt.trim() || !referenceImage || isGenerating
                      ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20'
                  }`}
                >
                  <Wand2 className="w-4 h-4" />
                  <span>Apply Modification</span>
                </button>
              </div>
            </div>
          </form>
        )}

        {/* Error Notification */}
        {error && (
          <div className="flex items-start gap-3 p-4 rounded-2xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800/40 text-red-700 dark:text-red-300 text-xs sm:text-sm">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-800 dark:text-red-200">Image Generation Notice</p>
              <p className="text-red-700 dark:text-red-300/80 mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Studio Gallery */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Image Library</span>
              <span className="text-xs font-mono text-slate-400">({history.length})</span>
            </h2>
          </div>

          {history.length === 0 ? (
            <div className="py-14 text-center rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-[#090c16] p-8">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mx-auto mb-3">
                <ImageIcon className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">No images created yet</p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Type any description above to generate high-resolution visuals.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {history.map((item) => (
                <div
                  key={item.id}
                  className="group relative rounded-2xl overflow-hidden bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 shadow-sm transition-all"
                >
                  <div
                    className="relative w-full aspect-square bg-slate-900 overflow-hidden cursor-pointer"
                    onClick={() => setPreviewImage(item)}
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.prompt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                      <span className="text-xs font-medium text-white flex items-center gap-1.5">
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>View Fullscreen</span>
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 space-y-2">
                    <p className="text-xs text-slate-800 dark:text-slate-200 line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800/80">
                      <span className="font-mono">{item.aspectRatio}</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleCopyPrompt(item)}
                          className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                          title="Copy prompt"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => handleDownload(item)}
                          className="p-1 rounded text-emerald-600 dark:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                          title="Download PNG"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI DISCLAIMER BELOW IMAGE STUDIO */}
        <p className="text-center text-[11px] text-slate-400 dark:text-slate-500 pt-4 pb-2">
          MindGPT is an AI-powered assistant. It may sometimes make mistakes or provide inaccurate information. Please verify important information before relying on it.
        </p>
      </div>

      {/* Fullscreen Image Zoom Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="relative max-w-4xl w-full max-h-[90vh] bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-md">
                {previewImage.prompt}
              </span>
              <button
                onClick={() => setPreviewImage(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-black/90">
              <img
                src={previewImage.imageUrl}
                alt={previewImage.prompt}
                className="max-h-[70vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
              />
            </div>

            <div className="flex items-center justify-between p-4 border-t border-slate-200 dark:border-slate-800 text-xs">
              <span className="text-slate-500 font-mono">Aspect: {previewImage.aspectRatio}</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopyPrompt(previewImage)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Prompt</span>
                </button>
                <button
                  onClick={() => handleDownload(previewImage)}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-semibold text-white transition-colors cursor-pointer shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Image</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

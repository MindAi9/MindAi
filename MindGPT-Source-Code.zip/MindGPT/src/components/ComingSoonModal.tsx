import React, { useState } from 'react';
import { X, Image, Video, PhoneCall, Bot, Globe, Volume2, Paperclip, ArrowRight, Check } from 'lucide-react';

export type ComingSoonFeature = 'image' | 'image-upload' | 'video' | 'voice' | 'tts' | 'search' | 'agent';

interface ComingSoonModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature: ComingSoonFeature;
}

const FEATURE_DATA: Record<
  ComingSoonFeature,
  {
    title: string;
    badge: string;
    icon: React.ComponentType<{ className?: string }>;
    description: string;
    highlights: string[];
    specs: string;
  }
> = {
  image: {
    title: 'Image Generation — Coming Soon.',
    badge: 'Coming Soon',
    icon: Image,
    description:
      'MindGPT visual synthesis with fine style control, photorealistic textures, and high-fidelity rendering is currently in active development.',
    highlights: [
      'Native ultra-high resolution image generation',
      'Granular stylistic tuning and spatial controls',
      'Aspect ratio customisation (16:9, 1:1, 9:16, 4:3)',
    ],
    specs: 'Status: Planned for Future Release',
  },
  'image-upload': {
    title: 'Image Understanding — Coming Soon.',
    badge: 'Coming Soon',
    icon: Paperclip,
    description:
      'Multimodal image upload, visual inspection, diagram reading, and OCR analysis will be activated in an upcoming update.',
    highlights: [
      'Visual diagram and screenshot analysis',
      'Handwritten note and document OCR',
      'Code extraction from architecture diagrams',
    ],
    specs: 'Status: Planned for Future Release',
  },
  voice: {
    title: 'Live Voice — Coming Soon.',
    badge: 'Coming Soon',
    icon: PhoneCall,
    description:
      'Two-way conversational live voice with natural spoken pauses, real-time interruptions, and bilingual speech synthesis is coming soon.',
    highlights: [
      'Low-latency two-way voice streaming',
      'Natural interruption handling',
      'Fluent spoken English, Hindi, and Hinglish',
    ],
    specs: 'Status: Planned for Future Release',
  },
  tts: {
    title: 'Text-to-Speech — Coming Soon.',
    badge: 'Coming Soon',
    icon: Volume2,
    description:
      'High-clarity neural speech synthesis for reading chat responses aloud in natural accents is coming soon.',
    highlights: [
      'Natural prosody and inflection',
      'Multilingual audio playback (English & Hindi)',
      'Adjustable reading rates and voice timbres',
    ],
    specs: 'Status: Planned for Future Release',
  },
  search: {
    title: 'Web Search — Coming Soon.',
    badge: 'Coming Soon',
    icon: Globe,
    description:
      'Live internet search grounding for real-time citations, stock updates, and live facts is coming soon.',
    highlights: [
      'Real-time web search retrieval',
      'Source citations and domain verification',
      'Fresh data synthesis for news and technical releases',
    ],
    specs: 'Status: Planned for Future Release',
  },
  video: {
    title: 'Video Motion — Coming Soon.',
    badge: 'Coming Soon',
    icon: Video,
    description:
      'Neural video synthesis and camera motion generation are scheduled for the next major release.',
    highlights: [
      'Cinematic text-to-video rendering',
      'Camera trajectory controls',
      'High-frame-rate output',
    ],
    specs: 'Status: Planned for Future Release',
  },
  agent: {
    title: 'Autonomous Agents — Coming Soon.',
    badge: 'Coming Soon',
    icon: Bot,
    description:
      'Autonomous cognitive agents for executing multi-step workflows are coming in a future update.',
    highlights: [
      'Long-horizon planning',
      'Automated multi-step tool use',
      'Deep research pipelines',
    ],
    specs: 'Status: Planned for Future Release',
  },
};

export function ComingSoonModal({ isOpen, onClose, feature }: ComingSoonModalProps) {
  const [email, setEmail] = useState('');
  const [notified, setNotified] = useState(false);

  if (!isOpen) return null;

  const data = FEATURE_DATA[feature] || FEATURE_DATA.image;
  const IconComponent = data.icon;

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setNotified(true);
    setTimeout(() => {
      setEmail('');
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div
        className="relative w-full max-w-lg bg-white dark:bg-[#0d121f] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-2xl text-slate-800 dark:text-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10 border border-purple-200 dark:border-purple-500/30 flex items-center justify-center text-purple-600 dark:text-purple-400">
              <IconComponent className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">{data.title}</h3>
              <p className="text-xs text-purple-600 dark:text-purple-400 font-medium tracking-wide mt-0.5">
                {data.specs}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-5 space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{data.description}</p>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800/80 space-y-2.5">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
              Feature Roadmap
            </span>
            <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
              {data.highlights.map((highlight, idx) => (
                <li key={idx} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-600 dark:bg-purple-400 shrink-0" />
                  <span>{highlight}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-2">
            {notified ? (
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-medium p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/30">
                <Check className="w-4 h-4" />
                <span>We will notify you when this feature launches!</span>
              </div>
            ) : (
              <form onSubmit={handleNotify} className="space-y-2">
                <label className="text-xs text-slate-500 dark:text-slate-400 block font-medium">
                  Get notified when this feature is ready:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-white dark:bg-[#070a12] border border-slate-300 dark:border-slate-800 focus:border-purple-500 focus:outline-none text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
                  />
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 rounded-xl transition-all cursor-pointer whitespace-nowrap shadow-lg shadow-purple-900/30"
                  >
                    <span>Notify Me</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-slate-800/60">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

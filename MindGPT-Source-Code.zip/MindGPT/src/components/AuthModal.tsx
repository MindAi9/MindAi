import React, { useState } from 'react';
import {
  X,
  Lock,
  Mail,
  User,
  Check,
  Copy,
  AlertCircle,
  KeyRound,
  ShieldCheck,
  Database,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import {
  isSupabaseConfigured,
  signUpWithEmail,
  signInWithEmail,
  resetPasswordForEmail,
  SUPABASE_RLS_SCHEMA_SQL,
} from '../services/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: any) => void;
}

export function AuthModal({ isOpen, onClose, onAuthSuccess }: AuthModalProps) {
  const [tab, setTab] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [showSqlSchema, setShowSqlSchema] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // Runtime Supabase credential injection for testing if not set in Vite env
  const [customSupabaseUrl, setCustomSupabaseUrl] = useState('');
  const [customAnonKey, setCustomAnonKey] = useState('');
  const [savedConfigNotice, setSavedConfigNotice] = useState(false);

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_RLS_SCHEMA_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const handleApplyRuntimeConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSupabaseUrl || !customAnonKey) return;
    try {
      localStorage.setItem('mindgpt_supabase_url_override', customSupabaseUrl.trim());
      localStorage.setItem('mindgpt_supabase_key_override', customAnonKey.trim());
      (window as any).__SUPABASE_URL__ = customSupabaseUrl.trim();
      (window as any).__SUPABASE_ANON_KEY__ = customAnonKey.trim();
      setSavedConfigNotice(true);
      setTimeout(() => {
        window.location.reload();
      }, 800);
    } catch (e: any) {
      setStatusMessage({ type: 'error', text: e.message || 'Failed to save configuration' });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!isSupabaseConfigured) {
      setStatusMessage({
        type: 'error',
        text: 'Supabase credentials are required. Please configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.',
      });
      return;
    }

    if (!email) {
      setStatusMessage({ type: 'error', text: 'Please enter your email address.' });
      return;
    }

    setIsLoading(true);

    try {
      if (tab === 'signup') {
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters.');
        }
        const data = await signUpWithEmail(email, password);
        if (data?.user) {
          setStatusMessage({
            type: 'success',
            text: 'Account created successfully! Check your email if verification is required.',
          });
          onAuthSuccess(data.user);
        }
      } else if (tab === 'signin') {
        const data = await signInWithEmail(email, password);
        if (data?.user) {
          setStatusMessage({ type: 'success', text: 'Signed in successfully!' });
          onAuthSuccess(data.user);
          setTimeout(() => onClose(), 600);
        }
      } else if (tab === 'reset') {
        await resetPasswordForEmail(email);
        setStatusMessage({
          type: 'success',
          text: 'Password recovery email sent. Please check your inbox.',
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Authentication error. Please check your credentials.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        className="relative w-full max-w-md bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl text-slate-800 dark:text-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl overflow-hidden bg-black border border-purple-500/40 shadow-sm flex items-center justify-center">
              <img
                src="/mindgpt-badge.png"
                alt="MindGPT"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                MindGPT Account
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Secure multi-device sync with Supabase
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Supabase status banner if not configured */}
        {!isSupabaseConfigured && (
          <div className="p-4 mx-6 mt-4 rounded-2xl bg-amber-500/10 dark:bg-amber-950/30 border border-amber-500/30 text-xs space-y-2">
            <div className="flex items-start gap-2 text-amber-800 dark:text-amber-300 font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
              <span>Supabase Project Settings Required</span>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              To activate cloud login and user-scoped conversation protection for project <strong className="text-slate-900 dark:text-white">MindGPT</strong>, the following environment variables are required:
            </p>
            <ul className="space-y-1 font-mono text-[11px] text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/40 p-2.5 rounded-xl border border-purple-200 dark:border-purple-800/40">
              <li>• VITE_SUPABASE_URL</li>
              <li>• VITE_SUPABASE_ANON_KEY</li>
            </ul>
            <div className="pt-1 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setShowSqlSchema(!showSqlSchema)}
                className="text-purple-600 dark:text-purple-400 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Database className="w-3.5 h-3.5" />
                <span>{showSqlSchema ? 'Hide RLS Schema' : 'View Required RLS SQL'}</span>
              </button>
              <span className="text-[10px] text-slate-400">No mock login created</span>
            </div>
          </div>
        )}

        {/* Collapsible Supabase RLS Schema Viewer */}
        {showSqlSchema && (
          <div className="px-6 pt-3 pb-1">
            <div className="p-3 bg-slate-900 text-slate-200 rounded-2xl border border-slate-700 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Row Level Security (RLS) SQL</span>
                </span>
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-[11px] transition-colors cursor-pointer"
                >
                  {copiedSql ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedSql ? 'Copied' : 'Copy SQL'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                Execute this in your Supabase SQL editor to create the <code className="text-purple-300">profiles</code> and <code className="text-purple-300">conversations</code> tables with strict RLS policies.
              </p>
              <pre className="max-h-36 overflow-y-auto text-[10px] font-mono p-2 bg-black/60 rounded-lg text-slate-300">
                {SUPABASE_RLS_SCHEMA_SQL}
              </pre>
            </div>
          </div>
        )}

        {/* Tabs */}
        {isSupabaseConfigured && (
          <div className="flex items-center gap-2 px-6 pt-4 border-b border-slate-200 dark:border-slate-800">
            <button
              onClick={() => {
                setTab('signin');
                setStatusMessage(null);
              }}
              className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                tab === 'signin'
                  ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setTab('signup');
                setStatusMessage(null);
              }}
              className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                tab === 'signup'
                  ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Create Account
            </button>
            <button
              onClick={() => {
                setTab('reset');
                setStatusMessage(null);
              }}
              className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                tab === 'reset'
                  ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Reset Password
            </button>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {statusMessage && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                  : 'bg-red-500/10 border border-red-500/30 text-red-700 dark:text-red-300'
              }`}
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{statusMessage.text}</span>
            </div>
          )}

          {isSupabaseConfigured ? (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              {tab === 'signup' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Full Name (Optional)
                  </label>
                  <div className="relative flex items-center">
                    <User className="absolute left-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Maya Sharma"
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-300 dark:border-slate-800 focus:border-purple-500 dark:focus:border-purple-500 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative flex items-center">
                  <Mail className="absolute left-3 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="user@example.com"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-300 dark:border-slate-800 focus:border-purple-500 dark:focus:border-purple-500 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              {tab !== 'reset' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Password
                  </label>
                  <div className="relative flex items-center">
                    <Lock className="absolute left-3 w-4 h-4 text-slate-400" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="Minimum 6 characters"
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-300 dark:border-slate-800 focus:border-purple-500 dark:focus:border-purple-500 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs transition-all shadow-md shadow-purple-900/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <span>Processing...</span>
                ) : tab === 'signup' ? (
                  <span>Create MindGPT Account</span>
                ) : tab === 'signin' ? (
                  <span>Sign In</span>
                ) : (
                  <span>Send Recovery Email</span>
                )}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          ) : (
            <div className="space-y-3 pt-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                Connect Supabase Keys Directly (Optional Session Setup)
              </span>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                You can enter your Supabase project keys below to test the connection in this session:
              </p>
              <form onSubmit={handleApplyRuntimeConfig} className="space-y-2.5">
                <div>
                  <label className="block text-[11px] font-mono text-slate-600 dark:text-slate-400 mb-1">
                    Project URL:
                  </label>
                  <input
                    type="url"
                    value={customSupabaseUrl}
                    onChange={(e) => setCustomSupabaseUrl(e.target.value)}
                    placeholder="https://xyzcompany.supabase.co"
                    className="w-full px-3 py-1.5 text-xs font-mono rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-600 dark:text-slate-400 mb-1">
                    Anon Public Key:
                  </label>
                  <input
                    type="text"
                    value={customAnonKey}
                    onChange={(e) => setCustomAnonKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="w-full px-3 py-1.5 text-xs font-mono rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!customSupabaseUrl || !customAnonKey}
                  className="w-full py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors cursor-pointer disabled:opacity-40"
                >
                  Save & Reload Session
                </button>
                {savedConfigNotice && (
                  <p className="text-[11px] text-emerald-500 font-medium text-center">
                    Saved! Reloading interface...
                  </p>
                )}
              </form>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080b13] text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Row Level Security Enforced</span>
          </div>
          <button
            onClick={onClose}
            className="text-xs font-medium text-slate-600 dark:text-slate-400 hover:underline cursor-pointer"
          >
            Continue as Guest
          </button>
        </div>
      </div>
    </div>
  );
}

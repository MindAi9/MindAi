import React, { useState } from 'react';
import { X, Sparkles, MessageSquare, PhoneCall, Image as ImageIcon, ArrowRight, ShieldCheck } from 'lucide-react';

interface WelcomePopupProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLiveVoice: () => void;
  onOpenImageStudio: () => void;
}

export function WelcomePopup({
  isOpen,
  onClose,
  onOpenLiveVoice,
  onOpenImageStudio,
}: WelcomePopupProps) {
  const [dontShowAgain, setDontShowAgain] = useState(true);

  if (!isOpen) return null;

  const handleDismiss = () => {
    if (dontShowAgain) {
      try {
        localStorage.setItem('mindgpt_welcome_dismissed_v1', 'true');
      } catch {}
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        className="relative w-full max-w-md bg-white dark:bg-[#0c101c] border border-purple-300 dark:border-purple-500/40 rounded-3xl p-6 shadow-2xl text-slate-800 dark:text-slate-200 overflow-hidden text-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Background ambient glow */}
        <div className="absolute -top-24 -left-24 w-60 h-60 bg-purple-600/10 dark:bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-60 h-60 bg-blue-600/10 dark:bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
          aria-label="Close welcome popup"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Official Brand Logo */}
        <div className="relative mx-auto w-24 h-24 mb-4 rounded-2xl overflow-hidden shadow-2xl border border-purple-500/40 bg-black flex items-center justify-center">
          <img
            src="/mindgpt-badge.png"
            alt="MindGPT Official Logo"
            className="w-full h-full object-contain"
          />
        </div>

        {/* Heading */}
        <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white mb-2">
          Welcome to{' '}
          <span className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 dark:from-purple-400 dark:via-indigo-300 dark:to-blue-400 bg-clip-text text-transparent">
            MindGPT
          </span>
        </h2>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed max-w-sm mx-auto">
          Your modern, responsive AI cognitive workspace. Experience fluent conversational intelligence, live two-way voice, and AI image generation.
        </p>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 gap-2.5 mb-6 text-left text-xs">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800">
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-600 dark:text-purple-400 shrink-0">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <span className="font-semibold text-slate-900 dark:text-white block">Conversational Intelligence</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">Understands English, Hindi (हिंदी) & Hinglish</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
              <PhoneCall className="w-4 h-4" />
            </div>
            <div>
              <span className="font-semibold text-slate-900 dark:text-white block">Real-Time Mind Live Voice</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">Two-way spoken conversations with instant interruptions</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <span className="font-semibold text-slate-900 dark:text-white block">AI Image Studio</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">Generate and download native high-resolution artwork</span>
            </div>
          </div>
        </div>

        {/* Don't show again toggle */}
        <div className="flex items-center justify-center gap-2 mb-5">
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={(e) => setDontShowAgain(e.target.checked)}
              className="accent-purple-600 rounded cursor-pointer"
            />
            <span>Don't show this popup on next visit</span>
          </label>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={handleDismiss}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 transition-all shadow-xl shadow-purple-900/40 cursor-pointer"
        >
          <span>Get Started</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

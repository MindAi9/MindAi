import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  ArrowLeft,
  ChevronRight,
  User,
  Briefcase,
  Sparkles,
  Sliders,
  Brain,
  Settings as SettingsIcon,
  BarChart3,
  Bell,
  Mic,
  HeartHandshake,
  ShieldCheck,
  Code2,
  HardDrive,
  Lock,
  History,
  Ban,
  Bug,
  Info,
  LogOut,
  Check,
  Sun,
  Moon,
  Play,
  Square,
  Download,
  Trash2,
  Copy,
  CheckCircle2,
  Globe,
  Volume2,
  Loader2,
} from 'lucide-react';
import { AppSettings, Conversation, LibraryImageRecord } from '../types';
import { ttsEngine, ServerVoiceInfo, TTSState } from '../utils/tts';
import {
  LANGUAGE_CATALOG,
  getLanguageOption,
  normalizeLocaleCode,
} from '../data/languages';
import type { FirebaseUser, UserProfileRecord } from '../services/firebase';

export type SettingsCategoryId =
  | 'account'
  | 'workspace'
  | 'upgrade'
  | 'personalization'
  | 'memory'
  | 'general'
  | 'usage'
  | 'notifications'
  | 'voice'
  | 'safety'
  | 'security'
  | 'codex'
  | 'storage'
  | 'privacy'
  | 'history'
  | 'ads';

interface SettingsDrawerContentProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  conversations: Conversation[];
  libraryImages: LibraryImageRecord[];
  onClearAllConversations: () => void;
  onOpenArchived?: () => void;
  onOpenProfileEditor?: () => void;
  onSignOut?: () => void;
  firebaseUser?: FirebaseUser | null;
  userProfile?: UserProfileRecord | null;
}

interface CategoryItem {
  id: SettingsCategoryId;
  title: string;
  subtitle: string;
  keywords: string[];
  icon: React.ComponentType<{ className?: string }>;
  iconBg: string;
}

const SETTINGS_CATEGORIES: CategoryItem[] = [
  {
    id: 'account',
    title: 'Account',
    subtitle: 'Display name, username, email & Google identity',
    keywords: ['name', 'username', 'email', 'avatar', 'profile', 'google', 'uid'],
    icon: User,
    iconBg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400',
  },
  {
    id: 'workspace',
    title: 'Workspace',
    subtitle: 'Personal workspace stats & archived chats',
    keywords: ['workspace', 'archive', 'chats', 'folder'],
    icon: Briefcase,
    iconBg: 'bg-blue-500/15 text-blue-600 dark:text-blue-400',
  },
  {
    id: 'upgrade',
    title: 'Upgrade',
    subtitle: 'Plan status & roadmap availability',
    keywords: ['plan', 'pro', 'subscription', 'pricing', 'upgrade'],
    icon: Sparkles,
    iconBg: 'bg-purple-500/15 text-purple-600 dark:text-purple-400',
  },
  {
    id: 'personalization',
    title: 'Personalization',
    subtitle: 'Nickname, custom instructions, persona & accent',
    keywords: ['custom', 'instructions', 'persona', 'nickname', 'accent', 'color'],
    icon: Sliders,
    iconBg: 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
  },
  {
    id: 'memory',
    title: 'Memory',
    subtitle: 'How MindGPT handles chat context & instructions',
    keywords: ['memory', 'context', 'remember', 'history'],
    icon: Brain,
    iconBg: 'bg-pink-500/15 text-pink-600 dark:text-pink-400',
  },
  {
    id: 'general',
    title: 'General',
    subtitle: 'Theme, language, Enter key & auto-scroll',
    keywords: ['theme', 'light', 'dark', 'language', 'hindi', 'english', 'hinglish', 'enter', 'scroll'],
    icon: SettingsIcon,
    iconBg: 'bg-slate-500/15 text-slate-700 dark:text-slate-300',
  },
  {
    id: 'usage',
    title: 'Usage and Limits',
    subtitle: 'Local conversation & library activity counts',
    keywords: ['usage', 'limits', 'quota', 'tokens', 'stats', 'messages'],
    icon: BarChart3,
    iconBg: 'bg-cyan-500/15 text-cyan-600 dark:text-cyan-400',
  },
  {
    id: 'notifications',
    title: 'Notifications',
    subtitle: 'In-app sound cues & browser status',
    keywords: ['sound', 'chime', 'alert', 'notifications', 'audio'],
    icon: Bell,
    iconBg: 'bg-orange-500/15 text-orange-600 dark:text-orange-400',
  },
  {
    id: 'voice',
    title: 'Voice',
    subtitle: 'Female/Male speech output & dictation language',
    keywords: ['voice', 'tts', 'speech', 'microphone', 'dictation', 'sample', 'male', 'female'],
    icon: Mic,
    iconBg: 'bg-indigo-500/15 text-indigo-600 dark:text-indigo-400',
  },
  {
    id: 'safety',
    title: 'Safety & Wellbeing',
    subtitle: 'Response verification & balanced session mode',
    keywords: ['safety', 'wellbeing', 'verify', 'break', 'concise'],
    icon: HeartHandshake,
    iconBg: 'bg-teal-500/15 text-teal-600 dark:text-teal-400',
  },
  {
    id: 'security',
    title: 'Security and Login',
    subtitle: 'Firebase Google session & sign out',
    keywords: ['security', 'login', 'google', 'session', 'firebase', 'logout', 'password'],
    icon: ShieldCheck,
    iconBg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400',
  },
  {
    id: 'codex',
    title: 'Codex',
    subtitle: 'AI reasoning mode & code block formatting',
    keywords: ['codex', 'code', 'model', 'turbo', 'reasoning', 'line numbers', 'developer'],
    icon: Code2,
    iconBg: 'bg-violet-500/15 text-violet-600 dark:text-violet-400',
  },
  {
    id: 'storage',
    title: 'Storage',
    subtitle: 'Browser storage footprint & library count',
    keywords: ['storage', 'cache', 'localstorage', 'size', 'disk', 'clear'],
    icon: HardDrive,
    iconBg: 'bg-sky-500/15 text-sky-600 dark:text-sky-400',
  },
  {
    id: 'privacy',
    title: 'Privacy Center',
    subtitle: 'Local-first chat storage & UID isolation',
    keywords: ['privacy', 'data', 'telemetry', 'tracking', 'private'],
    icon: Lock,
    iconBg: 'bg-slate-500/15 text-slate-700 dark:text-slate-300',
  },
  {
    id: 'history',
    title: 'History and Data',
    subtitle: 'Export chats (JSON/Markdown) & clear history',
    keywords: ['export', 'download', 'json', 'markdown', 'delete', 'clear', 'history'],
    icon: History,
    iconBg: 'bg-rose-500/15 text-rose-600 dark:text-rose-400',
  },
  {
    id: 'ads',
    title: 'Ads Controls',
    subtitle: 'Zero ads & zero ad-tracking policy',
    keywords: ['ads', 'advertising', 'sponsors', 'tracking'],
    icon: Ban,
    iconBg: 'bg-lime-500/15 text-lime-700 dark:text-lime-400',
  },
];

function computeLocalStorageBytes(): { totalKb: string; chatsKb: string } {
  if (typeof window === 'undefined') return { totalKb: '0 KB', chatsKb: '0 KB' };
  try {
    let totalBytes = 0;
    let chatBytes = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i) || '';
      const v = localStorage.getItem(k) || '';
      const bytes = (k.length + v.length) * 2;
      totalBytes += bytes;
      if (k.includes('mindgpt_conversations')) {
        chatBytes += bytes;
      }
    }
    const fmt = (b: number) => (b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`);
    return { totalKb: fmt(totalBytes), chatsKb: fmt(chatBytes) };
  } catch {
    return { totalKb: 'Unavailable', chatsKb: 'Unavailable' };
  }
}

export function SettingsDrawerContent({
  settings,
  onUpdateSettings,
  conversations,
  libraryImages,
  onClearAllConversations,
  onOpenArchived,
  onOpenProfileEditor,
  onSignOut,
  firebaseUser,
  userProfile,
}: SettingsDrawerContentProps) {
  const [selectedCategory, setSelectedCategory] = useState<SettingsCategoryId | null>(null);
  const [languagePickerOpen, setLanguagePickerOpen] = useState(false);
  const [languageSearch, setLanguageSearch] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [ttsState, setTtsState] = useState<TTSState>(() => ttsEngine.getState());
  const [serverVoices, setServerVoices] = useState<ServerVoiceInfo[]>([]);
  const [ttsProvider, setTtsProvider] = useState<'gemini' | 'elevenlabs' | 'webspeech'>('webspeech');
  const [voicesLoading, setVoicesLoading] = useState(false);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  const [bugModalOpen, setBugModalOpen] = useState(false);
  const [aboutModalOpen, setAboutModalOpen] = useState(false);
  const [bugDescription, setBugDescription] = useState('');
  const [bugCopied, setBugCopied] = useState(false);
  const [cacheNotice, setCacheNotice] = useState<string | null>(null);

  React.useEffect(() => {
    const unsub = ttsEngine.subscribe((next) => setTtsState(next));
    return unsub;
  }, []);

  React.useEffect(() => {
    if (selectedCategory !== 'voice') return;
    setVoicesLoading(true);
    ttsEngine
      .fetchConnectedVoices()
      .then((res) => {
        setServerVoices(res.voices);
        setTtsProvider(res.provider);
      })
      .finally(() => setVoicesLoading(false));
  }, [selectedCategory]);

  const activeLanguage = useMemo(
    () => getLanguageOption(settings.languagePreference),
    [settings.languagePreference]
  );

  const filteredLanguages = useMemo(() => {
    const q = languageSearch.trim().toLowerCase();
    if (!q) return LANGUAGE_CATALOG;
    return LANGUAGE_CATALOG.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.nativeName.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q) ||
        l.searchKeywords.includes(q)
    );
  }, [languageSearch]);

  const filteredCategories = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return SETTINGS_CATEGORIES;
    return SETTINGS_CATEGORIES.filter(
      (cat) =>
        cat.title.toLowerCase().includes(q) ||
        cat.subtitle.toLowerCase().includes(q) ||
        cat.keywords.some((kw) => kw.includes(q))
    );
  }, [searchQuery]);

  const totalMessagesCount = useMemo(
    () => conversations.reduce((acc, c) => acc + c.messages.length, 0),
    [conversations]
  );

  const storageMetrics = useMemo(() => computeLocalStorageBytes(), [conversations, settings]);

  const handleTestVoice = async (customVoiceId?: string, customGender?: 'male' | 'female') => {
    await ttsEngine.testVoice({
      gender: customGender || settings.voiceGender || 'female',
      languagePreference: normalizeLocaleCode(settings.languagePreference),
      voiceId: customVoiceId || settings.voiceId,
    });
  };

  const handleStopTestVoice = () => {
    ttsEngine.stop();
  };

  const handleExportJson = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      product: 'MindGPT by Ragib',
      accountEmail: firebaseUser?.email || '',
      conversationCount: conversations.length,
      conversations,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mindgpt-chats-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportMarkdown = () => {
    const lines: string[] = [
      `# MindGPT Conversation Export`,
      `Exported: ${new Date().toLocaleString()}`,
      `Conversations: ${conversations.length}`,
      '',
    ];
    for (const c of conversations) {
      lines.push(`## ${c.title}`);
      lines.push(`*Updated: ${new Date(c.updatedAt).toLocaleString()}*`);
      lines.push('');
      for (const m of c.messages) {
        const speaker = m.role === 'user' ? 'User' : 'MindGPT';
        lines.push(`### ${speaker}`);
        lines.push(m.content || '(Image / Attachment)');
        lines.push('');
      }
      lines.push('---');
      lines.push('');
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mindgpt-chats-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyBugDiagnostics = () => {
    const report = [
      `MindGPT Issue Report`,
      `Date: ${new Date().toISOString()}`,
      `Theme: ${settings.theme}`,
      `Model: ${settings.model}`,
      `UID Prefix: ${firebaseUser?.uid?.slice(0, 8) || 'none'}`,
      `Viewport: ${window.innerWidth}x${window.innerHeight}`,
      `Issue Description:\n${bugDescription.trim() || '(No description provided)'}`,
    ].join('\n');
    navigator.clipboard.writeText(report);
    setBugCopied(true);
    setTimeout(() => setBugCopied(false), 2500);
  };

  const activeCategoryMeta = SETTINGS_CATEGORIES.find((c) => c.id === selectedCategory);

  // SEARCHABLE LANGUAGE SELECTOR SCREEN (inside General -> Language)
  if (selectedCategory === 'general' && languagePickerOpen) {
    const groups: Array<{ id: 'indian' | 'english' | 'world'; title: string }> = [
      { id: 'indian', title: 'Indian Languages (21)' },
      { id: 'english', title: 'International English' },
      { id: 'world', title: 'World Languages' },
    ];

    return (
      <div className="flex-1 flex flex-col min-h-0" data-testid="settings-language-picker">
        <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#090c16] flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              setLanguagePickerOpen(false);
              setLanguageSearch('');
            }}
            data-testid="language-picker-back"
            className="min-h-[40px] px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>General</span>
          </button>
          <span className="text-slate-300 dark:text-slate-700">/</span>
          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
            Select Language
          </span>
        </div>

        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-[#07090e] shrink-0">
          <div className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={languageSearch}
              onChange={(e) => setLanguageSearch(e.target.value)}
              placeholder="Search language or code (e.g. Hindi, EN-US, தமிழ்)..."
              data-testid="language-search-input"
              className="w-full pl-9 pr-8 py-2.5 text-xs rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none text-slate-800 dark:text-slate-200"
            />
            {languageSearch && (
              <button
                type="button"
                onClick={() => setLanguageSearch('')}
                className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                aria-label="Clear language search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3.5 space-y-5 text-xs">
          {filteredLanguages.length === 0 ? (
            <div className="py-12 text-center text-slate-500 dark:text-slate-400">
              No languages matched &ldquo;{languageSearch}&rdquo;.
            </div>
          ) : (
            groups.map((grp) => {
              const items = filteredLanguages.filter((l) => l.group === grp.id);
              if (items.length === 0) return null;
              return (
                <div key={grp.id} className="space-y-1.5">
                  <h4 className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {grp.title}
                  </h4>
                  <div className="space-y-1">
                    {items.map((lang) => {
                      const isSelected = activeLanguage.code === lang.code;
                      return (
                        <button
                          key={lang.code}
                          type="button"
                          onClick={() => {
                            onUpdateSettings({
                              languagePreference: lang.code,
                              speechLanguage: lang.speechLang,
                            });
                            setLanguagePickerOpen(false);
                            setLanguageSearch('');
                          }}
                          data-testid={`language-option-${lang.code}`}
                          className={`w-full min-h-[48px] px-3 py-2.5 rounded-2xl border flex items-center justify-between gap-2 transition-colors cursor-pointer text-left ${
                            isSelected
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-slate-900 dark:text-white'
                              : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <span className="text-lg shrink-0" aria-hidden="true">
                              {lang.flag}
                            </span>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="font-semibold text-slate-900 dark:text-white truncate">
                                  {lang.name}
                                </span>
                                {lang.nativeName !== lang.name && (
                                  <span className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                                    ({lang.nativeName})
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="font-mono text-[10px] font-bold uppercase text-slate-500 dark:text-slate-400">
                                  {lang.code}
                                </span>
                                {lang.aiSupport === 'partial' && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 font-medium">
                                    AI chat supported · Dictation uses closest regional voice
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  }

  // DETAIL VIEW FOR A SELECTED CATEGORY
  if (selectedCategory && activeCategoryMeta) {
    return (
      <div className="flex-1 flex flex-col min-h-0" data-testid={`settings-detail-${selectedCategory}`}>
        {/* Back Sub-Header */}
        <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#090c16] flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              setSelectedCategory(null);
              setLanguagePickerOpen(false);
            }}
            data-testid="settings-back-button"
            className="min-h-[40px] px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Settings</span>
          </button>
          <span className="text-slate-300 dark:text-slate-700">/</span>
          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
            {activeCategoryMeta.title}
          </span>
        </div>

        {/* Category Detail Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs">
          {selectedCategory === 'account' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center gap-3">
                  {(userProfile?.photoURL || firebaseUser?.photoURL) ? (
                    <img
                      src={userProfile?.photoURL || firebaseUser?.photoURL || ''}
                      alt="Profile"
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-full object-cover border border-emerald-500/50"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-emerald-600 text-white font-bold text-lg flex items-center justify-center">
                      {(userProfile?.displayName || firebaseUser?.displayName || 'M').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-sm text-slate-900 dark:text-white truncate">
                      {userProfile?.displayName || firebaseUser?.displayName || 'MindGPT User'}
                    </div>
                    <div className="text-emerald-700 dark:text-emerald-400 font-semibold truncate">
                      @{userProfile?.username || 'mindgpt_user'}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between gap-2">
                    <span className="text-slate-500">Email</span>
                    <span className="font-medium text-slate-900 dark:text-slate-200 truncate">
                      {firebaseUser?.email || 'Not available'}
                    </span>
                  </div>
                  <div className="flex justify-between gap-2">
                    <span className="text-slate-500">Sign-In Method</span>
                    <span className="font-medium text-slate-900 dark:text-slate-200">Google Account</span>
                  </div>
                  <div className="flex justify-between gap-2">
                    <span className="text-slate-500">Firebase UID</span>
                    <span className="font-mono text-[10px] text-slate-600 dark:text-slate-400 truncate max-w-[180px]">
                      {firebaseUser?.uid || '—'}
                    </span>
                  </div>
                </div>
              </div>

              {onOpenProfileEditor && (
                <button
                  type="button"
                  onClick={onOpenProfileEditor}
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer transition-colors"
                >
                  Edit Display Name, Username & Photo
                </button>
              )}
            </div>
          )}

          {selectedCategory === 'workspace' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-3">
                <div>
                  <span className="text-slate-500 text-[11px] block">Workspace Name</span>
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    {userProfile?.displayName ? `${userProfile.displayName}'s Workspace` : 'Personal MindGPT Workspace'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Active Chats</span>
                    <span className="text-base font-bold text-slate-900 dark:text-white">
                      {conversations.filter((c) => !c.isArchived).length}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Archived Chats</span>
                    <span className="text-base font-bold text-slate-900 dark:text-white">
                      {conversations.filter((c) => c.isArchived).length}
                    </span>
                  </div>
                </div>
              </div>

              {onOpenArchived && (
                <button
                  type="button"
                  onClick={onOpenArchived}
                  className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold flex items-center justify-between cursor-pointer"
                >
                  <span>View Archived Conversations</span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              )}
            </div>
          )}

          {selectedCategory === 'upgrade' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-slate-50 dark:from-emerald-950/30 dark:to-[#080b14] border border-emerald-200 dark:border-emerald-800/40 space-y-2.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span className="font-bold text-sm text-slate-900 dark:text-white">MindGPT Standard Access</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  You currently have full access to Mind Turbo One, Mind Advanced Reasoning 4.0, natural speech playback, image generation, and your private visual library at no cost.
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Paid subscription checkout is not enabled in this release. No billing or card data is collected.
                </p>
              </div>
            </div>
          )}

          {selectedCategory === 'personalization' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Your Nickname</h3>
                <input
                  type="text"
                  value={settings.userNickname || ''}
                  onChange={(e) => onUpdateSettings({ userNickname: e.target.value })}
                  placeholder="How should MindGPT address you?"
                  className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-[#0e1220] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Custom Instructions</h3>
                <p className="text-slate-500 mb-2">Included automatically in your chat system instructions.</p>
                <textarea
                  value={settings.customInstructions || ''}
                  onChange={(e) => onUpdateSettings({ customInstructions: e.target.value })}
                  placeholder="e.g. Answer concisely and provide TypeScript examples."
                  rows={4}
                  className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-[#0e1220] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none resize-none leading-relaxed"
                />
              </div>

              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">Assistant Style</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'balanced', label: 'Balanced' },
                    { id: 'precise', label: 'Precise' },
                    { id: 'creative', label: 'Creative' },
                    { id: 'technical', label: 'Technical' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => onUpdateSettings({ persona: p.id as any })}
                      className={`min-h-[44px] px-3 py-2 rounded-xl border font-semibold text-left flex items-center justify-between cursor-pointer ${
                        settings.persona === p.id
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-emerald-950 dark:text-white'
                          : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <span>{p.label}</span>
                      {settings.persona === p.id && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">Accent Color</h3>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'green', label: 'Emerald', bg: 'bg-emerald-600' },
                    { id: 'blue', label: 'Ocean', bg: 'bg-blue-600' },
                    { id: 'purple', label: 'Violet', bg: 'bg-purple-600' },
                    { id: 'amber', label: 'Amber', bg: 'bg-amber-600' },
                  ].map((acc) => (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => onUpdateSettings({ accentColor: acc.id as any })}
                      className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 cursor-pointer ${
                        (settings.accentColor || 'green') === acc.id
                          ? 'border-emerald-500 bg-slate-100 dark:bg-[#121626]'
                          : 'border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full ${acc.bg} text-white flex items-center justify-center`}>
                        {(settings.accentColor || 'green') === acc.id && <Check className="w-3 h-3" />}
                      </div>
                      <span className="text-[10px] font-medium">{acc.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {selectedCategory === 'memory' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2.5">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">How Memory Works in MindGPT</h3>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  Within any active conversation, MindGPT remembers your full multi-turn thread so follow-up questions stay coherent.
                </p>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  Persistent cross-chat server-side memory is not enabled in this version. To set standing rules across all new chats, use{' '}
                  <button
                    type="button"
                    onClick={() => setSelectedCategory('personalization')}
                    className="font-semibold text-emerald-600 dark:text-emerald-400 underline cursor-pointer"
                  >
                    Custom Instructions
                  </button>
                  .
                </p>
              </div>
            </div>
          )}

          {selectedCategory === 'general' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">Theme</h3>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ theme: 'light' })}
                    className={`p-3.5 rounded-2xl border text-left cursor-pointer ${
                      settings.theme === 'light'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-950 ring-2 ring-emerald-500/20'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1.5 font-bold">
                        <Sun className="w-4 h-4 text-amber-500" />
                        Light
                      </span>
                      {settings.theme === 'light' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500">Bright crisp daylight UI</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ theme: 'dark' })}
                    className={`p-3.5 rounded-2xl border text-left cursor-pointer ${
                      settings.theme === 'dark'
                        ? 'bg-emerald-950/40 border-emerald-500 text-white ring-2 ring-emerald-500/20'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1.5 font-bold">
                        <Moon className="w-4 h-4 text-indigo-400" />
                        Dark
                      </span>
                      {settings.theme === 'dark' && <Check className="w-4 h-4 text-emerald-400" />}
                    </div>
                    <p className="text-[11px] text-slate-400">Deep low-glare canvas</p>
                  </button>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1.5">Language</h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2">
                  Controls AI response language, script, and voice input dictation.
                </p>
                <button
                  type="button"
                  onClick={() => setLanguagePickerOpen(true)}
                  data-testid="open-language-selector"
                  className="w-full min-h-[54px] px-3.5 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 hover:border-emerald-500 flex items-center justify-between gap-3 transition-colors cursor-pointer text-left"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white truncate">
                        <span>{activeLanguage.flag}</span>
                        <span>{activeLanguage.name}</span>
                        {activeLanguage.nativeName !== activeLanguage.name && (
                          <span className="font-normal text-slate-500 dark:text-slate-400">
                            ({activeLanguage.nativeName})
                          </span>
                        )}
                      </div>
                      <span className="font-mono text-[10px] font-bold uppercase text-emerald-700 dark:text-emerald-400">
                        {activeLanguage.code}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>
              </div>

              <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="font-semibold block text-slate-900 dark:text-white">Enter Inserts Newline</span>
                    <span className="text-[11px] text-slate-500">Use Send button or Cmd/Ctrl+Enter to submit</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={(settings.enterBehavior || 'newline') === 'newline'}
                    onChange={(e) => onUpdateSettings({ enterBehavior: e.target.checked ? 'newline' : 'send' })}
                    className="w-4 h-4 accent-emerald-600 cursor-pointer"
                  />
                </label>

                <label className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="font-semibold block text-slate-900 dark:text-white">Auto-Scroll Chat</span>
                    <span className="text-[11px] text-slate-500">Follow new response tokens automatically</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autoScroll !== false}
                    onChange={(e) => onUpdateSettings({ autoScroll: e.target.checked })}
                    className="w-4 h-4 accent-emerald-600 cursor-pointer"
                  />
                </label>
              </div>
            </div>
          )}

          {selectedCategory === 'usage' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-lg font-extrabold text-slate-900 dark:text-white block">
                    {conversations.length}
                  </span>
                  <span className="text-[10px] text-slate-500">Saved Chats</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-lg font-extrabold text-slate-900 dark:text-white block">
                    {totalMessagesCount}
                  </span>
                  <span className="text-[10px] text-slate-500">Messages</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-center">
                  <span className="text-lg font-extrabold text-slate-900 dark:text-white block">
                    {libraryImages.length}
                  </span>
                  <span className="text-[10px] text-slate-500">Library Images</span>
                </div>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 leading-relaxed">
                These figures reflect real items saved in your session and UID-isolated library. Upstream provider token quotas are managed at the API gateway and are not exposed to the browser client.
              </div>
            </div>
          )}

          {selectedCategory === 'notifications' && (
            <div className="space-y-4">
              <label className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Response Sound Cues</span>
                  <span className="text-[11px] text-slate-500">
                    Play subtle WebAudio chime when sending or receiving AI replies
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                  className="w-4 h-4 accent-emerald-600 cursor-pointer"
                />
              </label>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 leading-relaxed">
                Background browser push notifications are not active in this web client.
              </div>
            </div>
          )}

          {selectedCategory === 'voice' && (() => {
            const activeGender: 'male' | 'female' = settings.voiceGender === 'male' ? 'male' : 'female';
            const genderVoices = serverVoices.filter((v) => v.gender === activeGender);
            const isPreviewPlaying = ttsState.currentMessageId === 'test-voice-preview' && ttsState.status !== 'idle';
            const isPreviewLoading = ttsState.currentMessageId === 'test-voice-preview' && ttsState.status === 'loading';

            const handleSelectGender = (gender: 'male' | 'female') => {
              const firstMatchingVoice = serverVoices.find((v) => v.gender === gender);
              onUpdateSettings({
                voiceGender: gender,
                voiceId: firstMatchingVoice?.id || (gender === 'male' ? 'Charon' : 'Kore'),
              });
            };

            return (
              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Speech Output Voice</h3>
                  <p className="text-slate-500 dark:text-slate-400 mb-3">
                    Select Male or Female voice used when reading responses aloud in {activeLanguage.name}.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => handleSelectGender('female')}
                      data-testid="voice-gender-female"
                      className={`min-h-[52px] p-3 rounded-2xl border text-left cursor-pointer flex items-center justify-between ${
                        activeGender === 'female'
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-slate-900 dark:text-white'
                          : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <span className="font-bold">Female Voice</span>
                      {activeGender === 'female' && <Check className="w-4 h-4 text-emerald-600" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectGender('male')}
                      data-testid="voice-gender-male"
                      className={`min-h-[52px] p-3 rounded-2xl border text-left cursor-pointer flex items-center justify-between ${
                        activeGender === 'male'
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-slate-900 dark:text-white'
                          : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <span className="font-bold">Male Voice</span>
                      {activeGender === 'male' && <Check className="w-4 h-4 text-emerald-600" />}
                    </button>
                  </div>
                </div>

                {/* Connected Studio Voices List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-xs">
                      Connected {activeGender === 'male' ? 'Male' : 'Female'} Voices
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 uppercase">
                      {ttsProvider === 'gemini'
                        ? 'Gemini Neural Audio'
                        : ttsProvider === 'elevenlabs'
                          ? 'ElevenLabs'
                          : 'Browser Speech'}
                    </span>
                  </div>

                  {voicesLoading ? (
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center gap-2 text-slate-500">
                      <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                      <span>Loading connected voices...</span>
                    </div>
                  ) : genderVoices.length > 0 ? (
                    <div className="space-y-2">
                      {genderVoices.map((v, idx) => {
                        const isSelected =
                          settings.voiceId === v.id ||
                          (!genderVoices.some((gv) => gv.id === settings.voiceId) && idx === 0);
                        return (
                          <div
                            key={v.id}
                            onClick={() => onUpdateSettings({ voiceId: v.id, voiceGender: v.gender })}
                            role="button"
                            tabIndex={0}
                            data-testid={`voice-option-${v.id}`}
                            className={`p-3 rounded-2xl border flex items-center justify-between gap-2 cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600'
                                : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <Volume2
                                className={`w-4 h-4 shrink-0 ${
                                  isSelected ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                                }`}
                              />
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-slate-900 dark:text-white">{v.name}</span>
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 capitalize">
                                    {v.gender}
                                  </span>
                                </div>
                                <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                                  {v.description}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUpdateSettings({ voiceId: v.id, voiceGender: v.gender });
                                  if (isPreviewPlaying) {
                                    handleStopTestVoice();
                                  } else {
                                    void handleTestVoice(v.id, v.gender);
                                  }
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white text-[11px] font-semibold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                              >
                                {isPreviewPlaying && isSelected ? 'Stop' : 'Test'}
                              </button>
                              {isSelected && <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 text-[11px] text-amber-800 dark:text-amber-200 leading-relaxed">
                      Server neural TTS is unavailable right now. Playback will use your device browser&apos;s built-in speech voices when available.
                    </div>
                  )}
                </div>

                {/* Test Selected Voice Sample */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="font-semibold block text-slate-900 dark:text-white">Test Voice Sample</span>
                    <span className="text-slate-500 text-[11px] truncate block">
                      {isPreviewLoading
                        ? 'Preparing audio...'
                        : isPreviewPlaying
                          ? `Playing ${ttsState.voiceName || activeGender} sample...`
                          : `Plays sample in ${activeLanguage.name}`}
                    </span>
                  </div>
                  {isPreviewPlaying ? (
                    <button
                      type="button"
                      onClick={handleStopTestVoice}
                      className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-red-100 dark:bg-red-950/50 text-red-700 dark:text-red-300 font-semibold cursor-pointer flex items-center gap-1.5 shrink-0"
                    >
                      <Square className="w-3 h-3 fill-current" />
                      <span>Stop</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void handleTestVoice()}
                      data-testid="voice-test-button"
                      className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer flex items-center gap-1.5 shrink-0"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Test Voice</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })()}

          {selectedCategory === 'safety' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">Responsible AI & Verification</h3>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  MindGPT strives for high accuracy, but AI outputs can occasionally contain errors. Always double-check medical, legal, financial, or safety-critical guidance with trusted primary sources.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onUpdateSettings({ persona: settings.persona === 'precise' ? 'balanced' : 'precise' })}
                className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between text-left cursor-pointer"
              >
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Concise / Precise Focus Mode</span>
                  <span className="text-[11px] text-slate-500">Reduces long walls of text for calmer reading sessions</span>
                </div>
                <span
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                    settings.persona === 'precise'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {settings.persona === 'precise' ? 'Enabled' : 'Balanced'}
                </span>
              </button>
            </div>
          )}

          {selectedCategory === 'security' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2.5">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Google Firebase Session Verified</span>
                </div>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Account</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{firebaseUser?.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Email Verified</span>
                    <span className="font-medium text-emerald-600 dark:text-emerald-400">
                      {firebaseUser?.emailVerified ? 'Yes' : 'Managed by Google'}
                    </span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-200 dark:border-slate-800 leading-relaxed">
                  Authentication & two-step verification are managed directly by your Google Account rather than a separate MindGPT password.
                </p>
              </div>

              {onSignOut && (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out of This Device</span>
                </button>
              )}
            </div>
          )}

          {selectedCategory === 'codex' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">Default Intelligence Mode</h3>
                <div className="space-y-2">
                  {[
                    {
                      id: 'mind-turbo-one',
                      name: 'Mind Turbo One',
                      desc: 'Ultra-fast general & coding assistant',
                    },
                    {
                      id: 'mind-reasoning',
                      name: 'Mind Advanced Reasoning 4.0',
                      desc: 'Deep multi-step architectural & STEM reasoning',
                    },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => onUpdateSettings({ model: m.id })}
                      className={`w-full p-3.5 rounded-2xl border text-left cursor-pointer flex items-center justify-between ${
                        settings.model === m.id
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-slate-900 dark:text-white'
                          : 'bg-white dark:bg-[#080b14] border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div>
                        <span className="font-bold block">{m.name}</span>
                        <span className="text-[11px] text-slate-500">{m.desc}</span>
                      </div>
                      {settings.model === m.id && <Check className="w-4 h-4 text-emerald-600 shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>

              <label className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                <div>
                  <span className="font-semibold block text-slate-900 dark:text-white">Code Block Line Numbers</span>
                  <span className="text-[11px] text-slate-500">Show line indicators in formatted code snippets</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.codeLineNumbers !== false}
                  onChange={(e) => onUpdateSettings({ codeLineNumbers: e.target.checked })}
                  className="w-4 h-4 accent-emerald-600 cursor-pointer"
                />
              </label>
            </div>
          )}

          {selectedCategory === 'storage' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Browser Total Storage</span>
                  <span className="font-bold text-slate-900 dark:text-white">{storageMetrics.totalKb}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Conversation History Size</span>
                  <span className="font-bold text-slate-900 dark:text-white">{storageMetrics.chatsKb}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Private Library Visuals</span>
                  <span className="font-bold text-slate-900 dark:text-white">{libraryImages.length} saved</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  try {
                    sessionStorage.clear();
                  } catch {}
                  setCacheNotice('Temporary session cache cleared.');
                  setTimeout(() => setCacheNotice(null), 2500);
                }}
                className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-semibold cursor-pointer"
              >
                Clear Temporary Session Cache
              </button>
              {cacheNotice && (
                <p className="text-emerald-600 dark:text-emerald-400 font-semibold text-center">{cacheNotice}</p>
              )}
            </div>
          )}

          {selectedCategory === 'privacy' && (
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">Privacy-by-Design Architecture</h3>
                <ul className="space-y-1.5 text-slate-600 dark:text-slate-300 list-disc pl-4 leading-relaxed">
                  <li>Chat threads remain stored locally in your own browser storage.</li>
                  <li>Your profile settings and generated Library visuals are isolated strictly by your Firebase UID.</li>
                  <li>Zero third-party ad networks, analytics beacons, or behavioral selling.</li>
                </ul>
              </div>
            </div>
          )}

          {selectedCategory === 'history' && (
            <div className="space-y-4">
              <div className="space-y-2.5">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">Export Conversations</h3>
                <p className="text-slate-500">
                  Download all {conversations.length} conversations to keep an offline backup.
                </p>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleExportJson}
                    disabled={conversations.length === 0}
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export JSON</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleExportMarkdown}
                    disabled={conversations.length === 0}
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:opacity-90 disabled:opacity-40 text-white font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Markdown</span>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">Clear Chat History</h3>
                {confirmClearOpen ? (
                  <div className="p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/30 border border-red-300 dark:border-red-800 space-y-2.5">
                    <p className="text-red-700 dark:text-red-300 font-semibold">
                      Permanently delete all {conversations.length} conversations? This cannot be undone.
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onClearAllConversations();
                          setConfirmClearOpen(false);
                        }}
                        className="min-h-[40px] px-4 py-1.5 rounded-xl bg-red-600 text-white font-semibold cursor-pointer"
                      >
                        Yes, Delete All
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmClearOpen(false)}
                        className="min-h-[40px] px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmClearOpen(true)}
                    className="w-full min-h-[44px] flex items-center justify-center gap-2 text-red-600 dark:text-red-400 p-2.5 rounded-xl border border-red-200 dark:border-red-900/50 hover:bg-red-50 dark:hover:bg-red-950/30 font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear All Chat History</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {selectedCategory === 'ads' && (
            <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 space-y-2">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">Ad-Free Experience</h3>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                MindGPT does not display advertisements, sponsored prompts, or ad-targeting cookies. No ad controls are required because advertising is completely absent from the platform.
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // MAIN SEARCHABLE SETTINGS DIRECTORY + BOTTOM ACTIONS
  return (
    <div className="flex-1 flex flex-col min-h-0" data-testid="settings-home-view">
      {/* Live Search Bar */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800/80 bg-slate-50/50 dark:bg-[#07090e] shrink-0">
        <div className="relative flex items-center">
          <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search settings (e.g. voice, export, theme, privacy)..."
            data-testid="settings-search-input"
            className="w-full pl-9 pr-8 py-2.5 text-xs rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none text-slate-800 dark:text-slate-200"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Category Rows + Bottom Actions */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-1.5 text-xs">
        {filteredCategories.length === 0 ? (
          <div className="py-12 text-center text-slate-500 dark:text-slate-400">
            No settings matched &ldquo;{searchQuery}&rdquo;.
          </div>
        ) : (
          filteredCategories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                data-testid={`settings-cat-${cat.id}`}
                className="w-full min-h-[54px] flex items-center justify-between gap-3 px-3 py-2.5 rounded-2xl hover:bg-slate-100 dark:hover:bg-[#131929] transition-colors cursor-pointer text-left group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${cat.iconBg}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="font-semibold text-slate-900 dark:text-white block truncate text-xs">
                      {cat.title}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                      {cat.subtitle}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200 shrink-0" />
              </button>
            );
          })
        )}

        {/* Bottom Actions: Report a Bug, About MindGPT, Log Out */}
        <div className="pt-4 mt-4 border-t border-slate-200 dark:border-slate-800 space-y-1.5 pb-4">
          <button
            type="button"
            onClick={() => setBugModalOpen((v) => !v)}
            className="w-full min-h-[46px] flex items-center justify-between px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-[#131929] text-slate-700 dark:text-slate-200 font-semibold cursor-pointer"
          >
            <span className="flex items-center gap-3">
              <Bug className="w-4 h-4 text-amber-500" />
              <span>Report a Bug</span>
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {bugModalOpen && (
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#080b14] border border-slate-200 dark:border-slate-800 space-y-2.5 animate-fadeIn">
              <textarea
                value={bugDescription}
                onChange={(e) => setBugDescription(e.target.value)}
                rows={3}
                placeholder="Describe what happened so diagnostics can be copied..."
                className="w-full p-2.5 rounded-xl bg-white dark:bg-[#121626] border border-slate-200 dark:border-slate-800 text-xs focus:border-emerald-500 focus:outline-none resize-none"
              />
              <button
                type="button"
                onClick={handleCopyBugDiagnostics}
                className="w-full min-h-[40px] py-2 px-3 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                {bugCopied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{bugCopied ? 'Diagnostics Copied to Clipboard!' : 'Copy Diagnostic Report'}</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => setAboutModalOpen((v) => !v)}
            className="w-full min-h-[46px] flex items-center justify-between px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-[#131929] text-slate-700 dark:text-slate-200 font-semibold cursor-pointer"
          >
            <span className="flex items-center gap-3">
              <Info className="w-4 h-4 text-blue-500" />
              <span>About MindGPT</span>
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {aboutModalOpen && (
            <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 space-y-2 animate-fadeIn">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg overflow-hidden bg-black border border-purple-500/40 shrink-0">
                  <img src="/mindgpt-badge.png" alt="MindGPT" className="w-full h-full object-contain" />
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">MindGPT</span>
                  <span className="text-[11px] text-slate-500">Created & Developed by Ragib</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
                &ldquo;I was created by Ragib, the developer and creator of MindGPT. My vision is to make AI useful, accessible, and intelligent for everyone.&rdquo;
              </p>
            </div>
          )}

          {onSignOut && firebaseUser && (
            <button
              type="button"
              onClick={onSignOut}
              data-testid="settings-logout-button"
              className="w-full min-h-[46px] flex items-center justify-center gap-2 px-3 py-2.5 mt-2 rounded-2xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 font-semibold hover:bg-red-100 dark:hover:bg-red-950/50 cursor-pointer transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

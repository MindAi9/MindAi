import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowUp,
  Plus,
  Mic,
  MicOff,
  Square,
  X,
  FileText,
  Image as ImageIcon,
  Camera,
  ChevronDown,
  Sparkles,
  Loader2,
  RotateCcw,
  AlertCircle,
} from 'lucide-react';
import { Attachment } from '../types';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { getLanguageOption } from '../data/languages';

export interface ModelOption {
  id: string;
  name: string;
  speed: string;
  tagline: string;
}

export const AVAILABLE_MODELS: ModelOption[] = [
  {
    id: 'mind-turbo-one',
    name: 'Mind Turbo One',
    speed: 'Ultra Fast',
    tagline: 'High speed, balanced intelligence for coding, creative writing, and everyday analysis',
  },
  {
    id: 'mind-reasoning',
    name: 'Mind Advanced Reasoning 4.0',
    speed: 'Deep Logic',
    tagline: 'Deep step-by-step thinking for complex STEM, logic, and systems architecture',
  },
];

interface ChatInputProps {
  onSendMessage: (content: string, attachments?: Attachment[]) => void;
  isLoading: boolean;
  sendingStatus?: 'idle' | 'sending' | 'streaming' | 'error';
  sendingError?: string | null;
  onRetryLastSend?: () => void;
  onStopGeneration?: () => void;
  disabled?: boolean;
  selectedModel: string;
  onSelectModel: (modelId: string) => void;
  languagePreference?: string;
  enterBehavior?: 'newline' | 'send';
  draftPrompt?: { text: string; nonce: number } | null;
}

export function ChatInput({
  onSendMessage,
  isLoading,
  sendingStatus = 'idle',
  sendingError,
  onRetryLastSend,
  onStopGeneration,
  disabled,
  selectedModel,
  onSelectModel,
  languagePreference = 'en-US',
  enterBehavior = 'newline',
  draftPrompt,
}: ChatInputProps) {
  const [content, setContent] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [plusMenuOpen, setPlusMenuOpen] = useState(false);
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const initialContentRef = useRef('');
  const submitLockRef = useRef(false);

  const activeLanguageObj = getLanguageOption(languagePreference);

  // Hook for Web Speech API Voice Dictation automatically synced to Settings -> Language
  const {
    isListening,
    toggleListening: baseToggleListening,
    stopListening: baseStopListening,
    error: speechError,
    clearError: clearSpeechError,
  } = useSpeechRecognition({
    onTranscriptChange: (text) => {
      const base = initialContentRef.current;
      setContent(base ? `${base} ${text}` : text);
    },
    preferredLanguage: languagePreference,
  });

  const toggleListening = () => {
    if (!isListening) {
      initialContentRef.current = content;
    }
    baseToggleListening();
  };

  const stopListening = () => {
    baseStopListening();
    clearSpeechError();
    initialContentRef.current = '';
  };

  // Populate prompt draft from Gallery / Library without auto-sending
  useEffect(() => {
    if (!draftPrompt || !draftPrompt.text) return;
    setContent(draftPrompt.text);
    requestAnimationFrame(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const len = draftPrompt.text.length;
        textareaRef.current.setSelectionRange(len, len);
      }
    });
  }, [draftPrompt]);

  // Release submit lock whenever loading finishes
  useEffect(() => {
    if (!isLoading) {
      submitLockRef.current = false;
    }
  }, [isLoading]);

  // Auto-resize textarea naturally
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(scrollHeight, 220)}px`;
    }
  }, [content]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (enterBehavior === 'send') {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    } else {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        handleSubmit();
      }
    }
  };

  const handleSubmit = () => {
    if ((!content.trim() && attachments.length === 0) || isLoading || submitLockRef.current) return;
    submitLockRef.current = true;
    if (isListening) stopListening();

    onSendMessage(content.trim(), attachments);
    setContent('');
    setAttachments([]);
    initialContentRef.current = '';

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      const isImage = file.type.startsWith('image/');

      if (isImage || file.type.includes('pdf')) {
        reader.onload = () => {
          setAttachments((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              name: file.name,
              size: file.size,
              type: file.type || 'application/octet-stream',
              data: reader.result as string,
              isBase64: true,
            },
          ]);
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = () => {
          setAttachments((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              name: file.name,
              size: file.size,
              type: file.type || 'text/plain',
              data: reader.result as string,
              isBase64: false,
            },
          ]);
        };
        reader.readAsText(file);
      }
    });

    e.target.value = '';
    setPlusMenuOpen(false);
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const activeModelObj =
    AVAILABLE_MODELS.find((m) => m.id === selectedModel) || AVAILABLE_MODELS[0];

  return (
    <div className="w-full max-w-3xl mx-auto px-3 sm:px-4 pb-3">
      {/* Hidden File Inputs */}
      <input
        ref={photoInputRef}
        type="file"
        multiple
        accept="image/jpeg,image/png,image/webp,image/gif"
        onChange={handleFileUpload}
        className="hidden"
      />
      <input
        ref={docInputRef}
        type="file"
        multiple
        accept=".pdf,.docx,.txt,.csv,.xlsx,.json,.md,.js,.ts,.py"
        onChange={handleFileUpload}
        className="hidden"
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Sending Status Feedback Pill */}
      {sendingStatus === 'sending' && (
        <div
          data-testid="sending-status-pill"
          className="mb-2 px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-700/50 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2 w-fit animate-fadeIn shadow-xs"
        >
          <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600 dark:text-emerald-400" />
          <span className="font-medium">Sending message...</span>
        </div>
      )}

      {sendingStatus === 'error' && sendingError && (
        <div
          data-testid="sending-error-pill"
          className="mb-2 px-3.5 py-1.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/50 text-xs text-red-700 dark:text-red-300 flex items-center justify-between gap-3 animate-fadeIn"
        >
          <span className="flex items-center gap-1.5 truncate">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{sendingError}</span>
          </span>
          {onRetryLastSend && (
            <button
              type="button"
              onClick={onRetryLastSend}
              className="shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-100 dark:bg-red-900/50 hover:bg-red-200 text-red-800 dark:text-red-100 font-semibold cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          )}
        </div>
      )}

      {/* Voice Dictation Active State */}
      {isListening && (
        <div className="mb-2 px-3.5 py-2 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-600/40 flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-200 shadow-xs">
          <div className="flex items-center gap-2 min-w-0">
            <div className="flex items-center gap-1 shrink-0">
              <span className="w-1.5 h-3 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1.5 h-4 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <span className="font-semibold truncate">
              Listening ({activeLanguageObj.name})... speak naturally
            </span>
          </div>
          <button
            type="button"
            onClick={stopListening}
            className="text-xs px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-colors cursor-pointer shrink-0"
          >
            Done
          </button>
        </div>
      )}

      {speechError && (
        <div className="mb-2 px-3.5 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/50 text-[11px] text-amber-800 dark:text-amber-200 flex items-center justify-between gap-2">
          <span>{speechError}</span>
          <button
            type="button"
            onClick={stopListening}
            className="text-amber-600 hover:text-amber-900 dark:text-amber-300 dark:hover:text-white cursor-pointer shrink-0"
            aria-label="Dismiss voice notice"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Unified Chat Composer Box */}
      <div className="relative rounded-3xl bg-white dark:bg-[#0c101d] border border-slate-300 dark:border-slate-800 focus-within:border-emerald-500 dark:focus-within:border-emerald-500/70 transition-all shadow-sm">
        {/* Attachment chips */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 p-3 pb-0">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-[#141a2e] border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
              >
                {att.isBase64 && att.type.startsWith('image/') ? (
                  <img src={att.data} alt={att.name} className="w-6 h-6 rounded object-cover" />
                ) : (
                  <FileText className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                )}
                <span className="truncate max-w-[130px] font-medium">{att.name}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(att.id)}
                  className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask MindGPT"
          rows={1}
          disabled={disabled || isLoading}
          className="w-full bg-transparent px-4 pt-3.5 pb-2 text-[14px] text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none resize-none min-h-[44px] max-h-[220px] leading-relaxed disabled:opacity-60"
        />

        {/* Controls Bar: Plus (+) Menu | Microphone | Send Button (No EN/HI toggle) */}
        <div className="flex items-center justify-between px-3 pb-2.5 pt-1">
          <div className="flex items-center gap-1.5 relative">
            {/* Functional Plus (+) Button */}
            <button
              type="button"
              onClick={() => setPlusMenuOpen(!plusMenuOpen)}
              className="flex items-center justify-center w-10 h-10 sm:w-9 sm:h-9 rounded-full bg-slate-100 dark:bg-[#141a2c] hover:bg-slate-200 dark:hover:bg-[#1a233b] text-slate-700 dark:text-slate-300 transition-colors cursor-pointer shadow-xs"
              title="Add photos, documents, or camera"
              aria-label="Add photos, documents, or camera"
            >
              <Plus className={`w-4 h-4 transition-transform ${plusMenuOpen ? 'rotate-45' : ''}`} />
            </button>

            {/* Plus (+) Menu Dropdown */}
            {plusMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setPlusMenuOpen(false)}
                />
                <div className="absolute left-0 bottom-full mb-2 w-56 z-50 bg-white dark:bg-[#0f1424] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-1.5 text-xs animate-fadeIn space-y-0.5">
                  <button
                    type="button"
                    onClick={() => {
                      photoInputRef.current?.click();
                      setPlusMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#182138] transition-colors cursor-pointer text-left"
                  >
                    <ImageIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Upload Image</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      docInputRef.current?.click();
                      setPlusMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#182138] transition-colors cursor-pointer text-left"
                  >
                    <FileText className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span>Upload Document (PDF, TXT)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      cameraInputRef.current?.click();
                      setPlusMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#182138] transition-colors cursor-pointer text-left"
                  >
                    <Camera className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span>Camera</span>
                  </button>

                  <div className="border-t border-slate-100 dark:border-slate-800 my-1" />

                  <button
                    type="button"
                    onClick={() => {
                      setContent('Create a cinematic image of ');
                      setPlusMenuOpen(false);
                      textareaRef.current?.focus();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#182138] transition-colors cursor-pointer text-left"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Create Image Prompt</span>
                  </button>
                </div>
              </>
            )}

            {/* Voice Input (Microphone) Button — Language controlled strictly by Settings -> General -> Language */}
            <button
              type="button"
              onClick={toggleListening}
              data-testid="composer-mic-button"
              className={`flex items-center justify-center w-10 h-10 sm:w-9 sm:h-9 rounded-full transition-all cursor-pointer ${
                isListening
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40 animate-pulse'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
              }`}
              title={isListening ? 'Stop voice recording' : `Dictate (${activeLanguageObj.name})`}
              aria-label="Voice input"
              disabled={disabled || isLoading}
            >
              {isListening ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Send or Stop Button */}
            {isLoading ? (
              <button
                type="button"
                onClick={onStopGeneration}
                className="flex items-center justify-center w-10 h-10 sm:w-9 sm:h-9 rounded-full bg-slate-900 dark:bg-white text-white dark:text-black hover:opacity-90 transition-all cursor-pointer shadow-sm"
                title="Stop generation"
                aria-label="Stop generation"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                data-testid="composer-send-button"
                disabled={(!content.trim() && attachments.length === 0) || disabled}
                className={`flex items-center justify-center w-10 h-10 sm:w-9 sm:h-9 rounded-full transition-all cursor-pointer ${
                  content.trim() || attachments.length > 0
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                }`}
                title="Send message"
                aria-label="Send message"
              >
                <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Model Selector Bar */}
      <div className="flex items-center justify-between mt-2 px-1 relative">
        <div className="relative">
          <button
            type="button"
            onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
            className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-[#0c101c] hover:bg-slate-200 dark:hover:bg-[#131929] border border-slate-200 dark:border-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-slate-900 dark:text-white">{activeModelObj.name}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {modelDropdownOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setModelDropdownOpen(false)} />
              <div className="absolute left-0 bottom-full mb-2 w-72 z-50 bg-white dark:bg-[#0d121f] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-1.5 text-xs animate-fadeIn">
                <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Active Intelligence Mode
                </div>
                <div className="space-y-1">
                  {AVAILABLE_MODELS.map((m) => {
                    const isSelected = m.id === selectedModel;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          onSelectModel(m.id);
                          setModelDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-xl transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-600/40 text-emerald-900 dark:text-emerald-200'
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 border border-transparent'
                        }`}
                      >
                        <div className="font-bold text-slate-900 dark:text-white text-xs mb-0.5">
                          {m.name}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                          {m.tagline}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        <div className="text-[11px] text-slate-400 dark:text-slate-500">
          {enterBehavior === 'newline' ? 'Enter for newline · Click send' : 'Enter to send'}
        </div>
      </div>

      {/* Subtle AI Disclaimer */}
      <p className="text-center text-[11px] text-slate-400 dark:text-slate-500 mt-2 px-4 leading-normal">
        MindGPT is an AI cognitive partner. It may sometimes produce inaccurate information. Please verify important information before relying on it.
      </p>
    </div>
  );
}

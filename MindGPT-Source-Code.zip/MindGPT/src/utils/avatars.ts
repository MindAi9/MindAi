export type AvatarCategory = 'google' | 'male' | 'female' | 'ai' | 'color';

export interface AvatarBgColor {
  id: string;
  label: string;
  hex: string;
}

export interface PresetAvatarItem {
  id: string;
  label: string;
  category: 'male' | 'female' | 'ai' | 'color';
}

export const AVATAR_BG_COLORS: AvatarBgColor[] = [
  { id: 'emerald', label: 'Emerald', hex: '#10b981' },
  { id: 'blue', label: 'Ocean Blue', hex: '#2563eb' },
  { id: 'violet', label: 'Violet', hex: '#7c3aed' },
  { id: 'indigo', label: 'Indigo', hex: '#4f46e5' },
  { id: 'rose', label: 'Rose', hex: '#e11d48' },
  { id: 'amber', label: 'Amber', hex: '#d97706' },
  { id: 'cyan', label: 'Cyan', hex: '#0891b2' },
  { id: 'slate', label: 'Slate', hex: '#334155' },
];

export const PRESET_AVATARS: PresetAvatarItem[] = [
  // Male AI-style avatars
  { id: 'male-1', label: 'Tech Founder', category: 'male' },
  { id: 'male-2', label: 'Architect', category: 'male' },
  { id: 'male-3', label: 'Scholar', category: 'male' },
  { id: 'male-4', label: 'Creator', category: 'male' },
  { id: 'male-5', label: 'Engineer', category: 'male' },
  { id: 'male-6', label: 'Strategist', category: 'male' },
  // Female AI-style avatars
  { id: 'female-1', label: 'Product Lead', category: 'female' },
  { id: 'female-2', label: 'Researcher', category: 'female' },
  { id: 'female-3', label: 'Designer', category: 'female' },
  { id: 'female-4', label: 'Developer', category: 'female' },
  { id: 'female-5', label: 'Visionary', category: 'female' },
  { id: 'female-6', label: 'Analyst', category: 'female' },
  // AI / Futuristic avatars
  { id: 'ai-1', label: 'Neural Core', category: 'ai' },
  { id: 'ai-2', label: 'Cyber Visor', category: 'ai' },
  { id: 'ai-3', label: 'Holo Bot', category: 'ai' },
  { id: 'ai-4', label: 'Quantum Pulse', category: 'ai' },
  { id: 'ai-5', label: 'Mind Orb', category: 'ai' },
  { id: 'ai-6', label: 'Prism Node', category: 'ai' },
  // Color-based profile icons
  { id: 'color-1', label: 'Initial Badge', category: 'color' },
  { id: 'color-2', label: 'Spark Crest', category: 'color' },
  { id: 'color-3', label: 'Bolt Icon', category: 'color' },
  { id: 'color-4', label: 'Compass', category: 'color' },
  { id: 'color-5', label: 'Crown', category: 'color' },
  { id: 'color-6', label: 'Hex Emblem', category: 'color' },
];

export function buildPresetAvatarUrl(avatarId: string, bgHex: string, initial = 'M'): string {
  const cleanBg = bgHex.replace('#', '');
  const cleanInit = (initial || 'M').trim().charAt(0).toUpperCase() || 'M';
  return `/api/avatars/preset/${encodeURIComponent(avatarId)}.svg?bg=${encodeURIComponent(cleanBg)}&init=${encodeURIComponent(cleanInit)}`;
}

export function validateAvatarFile(file: File): string | null {
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowed.includes(file.type)) {
    return 'Unsupported image format. Please choose a JPG, PNG, or WebP image.';
  }
  const maxBytes = 2 * 1024 * 1024; // 2 MB
  if (file.size > maxBytes) {
    return 'Image file is too large. Maximum allowed size is 2 MB.';
  }
  return null;
}

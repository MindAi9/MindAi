import React, { useState } from 'react';
import { Check, Copy, Code2 } from 'lucide-react';

interface CodeBlockProps {
  language: string;
  code: string;
}

function CodeBlock({ language, code }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const cleanLang = language.trim().toLowerCase() || 'code';

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-[#0d111a] shadow-sm">
      <div className="flex items-center justify-between px-4 py-2 bg-[#141926] border-b border-slate-800/80 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Code2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-mono uppercase tracking-wider text-[11px] font-semibold text-slate-200">
            {cleanLang}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-slate-200 hover:text-white bg-slate-800/70 hover:bg-slate-700/80 transition-colors cursor-pointer"
          title="Copy code to clipboard"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <div className="p-3.5 overflow-x-auto text-[12.5px] leading-relaxed font-mono text-slate-100">
        <pre className="m-0 font-mono">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
}

// Inline formatting helper
function formatInlineText(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let keyIndex = 0;

  while (remaining.length > 0) {
    const codeMatch = remaining.match(/^(.*?)`([^`]+)`(.*)$/s);
    const boldMatch = remaining.match(/^(.*?)\*\*([^*]+)\*\*(.*)$/s);
    const italicMatch = remaining.match(/^(.*?)\*([^*]+)\*(.*)$/s);
    const linkMatch = remaining.match(/^(.*?)\[([^\]]+)\]\(([^)]+)\)(.*)$/s);

    const matches = [
      codeMatch ? { type: 'code', index: codeMatch[1].length, match: codeMatch } : null,
      boldMatch ? { type: 'bold', index: boldMatch[1].length, match: boldMatch } : null,
      italicMatch ? { type: 'italic', index: italicMatch[1].length, match: italicMatch } : null,
      linkMatch ? { type: 'link', index: linkMatch[1].length, match: linkMatch } : null,
    ].filter(Boolean) as Array<{ type: string; index: number; match: RegExpMatchArray }>;

    if (matches.length === 0) {
      parts.push(<span key={keyIndex++}>{remaining}</span>);
      break;
    }

    matches.sort((a, b) => a.index - b.index);
    const earliest = matches[0];

    const prefix = earliest.match[1];
    if (prefix) {
      parts.push(<span key={keyIndex++}>{prefix}</span>);
    }

    if (earliest.type === 'code') {
      parts.push(
        <code
          key={keyIndex++}
          className="px-1.5 py-0.5 mx-0.5 rounded-md bg-slate-100 dark:bg-slate-800/80 text-emerald-700 dark:text-emerald-300 border border-slate-200 dark:border-slate-700 font-mono text-[12.5px]"
        >
          {earliest.match[2]}
        </code>
      );
      remaining = earliest.match[3];
    } else if (earliest.type === 'bold') {
      parts.push(
        <strong key={keyIndex++} className="font-semibold text-slate-900 dark:text-white">
          {earliest.match[2]}
        </strong>
      );
      remaining = earliest.match[3];
    } else if (earliest.type === 'italic') {
      parts.push(
        <em key={keyIndex++} className="italic text-slate-700 dark:text-slate-200">
          {earliest.match[2]}
        </em>
      );
      remaining = earliest.match[3];
    } else if (earliest.type === 'link') {
      parts.push(
        <a
          key={keyIndex++}
          href={earliest.match[3]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 underline underline-offset-2 transition-colors"
        >
          {earliest.match[2]}
        </a>
      );
      remaining = earliest.match[4];
    }
  }

  return parts;
}

export function RenderMarkdown({ content }: { content: string }) {
  if (!content) return null;

  const sections: React.ReactNode[] = [];
  const codeBlockRegex = /```([a-zA-Z0-9_\-+]*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = codeBlockRegex.exec(content)) !== null) {
    const textBefore = content.substring(lastIndex, match.index);
    if (textBefore.trim()) {
      sections.push(
        <div key={`text-${lastIndex}`} className="space-y-3">
          {renderTextBlocks(textBefore)}
        </div>
      );
    }

    const lang = match[1] || 'code';
    const code = match[2];
    sections.push(<CodeBlock key={`code-${match.index}`} language={lang} code={code} />);

    lastIndex = match.index + match[0].length;
  }

  const trailingText = content.substring(lastIndex);
  if (trailingText.trim()) {
    sections.push(
      <div key={`text-${lastIndex}`} className="space-y-3">
        {renderTextBlocks(trailingText)}
      </div>
    );
  }

  return (
    <div className="markdown-body space-y-2.5 text-[13.5px] sm:text-[14px] leading-[1.6] text-slate-800 dark:text-slate-200">
      {sections}
    </div>
  );
}

function renderTextBlocks(text: string): React.ReactNode[] {
  const lines = text.split('\n');
  const nodes: React.ReactNode[] = [];
  let currentList: { type: 'ul' | 'ol'; items: string[] } | null = null;
  let blockquoteLines: string[] = [];

  const flushList = (key: string) => {
    if (currentList) {
      if (currentList.type === 'ul') {
        nodes.push(
          <ul key={key} className="space-y-1.5 my-2 pl-5 list-disc marker:text-emerald-600 dark:marker:text-emerald-400">
            {currentList.items.map((it, idx) => (
              <li key={idx} className="leading-relaxed">
                {formatInlineText(it)}
              </li>
            ))}
          </ul>
        );
      } else {
        nodes.push(
          <ol key={key} className="space-y-1.5 my-2 pl-5 list-decimal marker:text-emerald-600 dark:marker:text-emerald-400">
            {currentList.items.map((it, idx) => (
              <li key={idx} className="leading-relaxed">
                {formatInlineText(it)}
              </li>
            ))}
          </ol>
        );
      }
      currentList = null;
    }
  };

  const flushBlockquote = (key: string) => {
    if (blockquoteLines.length > 0) {
      nodes.push(
        <blockquote
          key={key}
          className="my-3 pl-4 border-l-2 border-emerald-500/70 text-slate-700 dark:text-slate-300 italic bg-slate-50 dark:bg-slate-900/40 py-2 pr-3 rounded-r-lg"
        >
          {blockquoteLines.map((line, idx) => (
            <p key={idx} className="m-0 leading-relaxed">
              {formatInlineText(line)}
            </p>
          ))}
        </blockquote>
      );
      blockquoteLines = [];
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    if (line.startsWith('>')) {
      flushList(`list-before-quote-${i}`);
      blockquoteLines.push(line.replace(/^>\s?/, ''));
      continue;
    } else {
      flushBlockquote(`quote-before-line-${i}`);
    }

    const ulMatch = line.match(/^[-*]\s+(.*)$/);
    if (ulMatch) {
      if (!currentList || currentList.type !== 'ul') {
        flushList(`prev-list-${i}`);
        currentList = { type: 'ul', items: [] };
      }
      currentList.items.push(ulMatch[1]);
      continue;
    }

    const olMatch = line.match(/^(\d+)\.\s+(.*)$/);
    if (olMatch) {
      if (!currentList || currentList.type !== 'ol') {
        flushList(`prev-list-${i}`);
        currentList = { type: 'ol', items: [] };
      }
      currentList.items.push(olMatch[2]);
      continue;
    }

    flushList(`flush-${i}`);

    if (!line) {
      continue;
    }

    if (line.startsWith('### ')) {
      nodes.push(
        <h4 key={`h3-${i}`} className="text-[14px] font-semibold text-slate-900 dark:text-slate-100 pt-1.5 pb-0.5">
          {formatInlineText(line.replace(/^###\s+/, ''))}
        </h4>
      );
    } else if (line.startsWith('## ')) {
      nodes.push(
        <h3 key={`h2-${i}`} className="text-[15px] font-bold text-slate-900 dark:text-white pt-2 pb-0.5 border-b border-slate-200/80 dark:border-slate-800">
          {formatInlineText(line.replace(/^##\s+/, ''))}
        </h3>
      );
    } else if (line.startsWith('# ')) {
      nodes.push(
        <h2 key={`h1-${i}`} className="text-[16px] sm:text-[17px] font-bold text-slate-900 dark:text-white pt-2.5 pb-0.5">
          {formatInlineText(line.replace(/^#\s+/, ''))}
        </h2>
      );
    } else if (line === '---' || line === '***') {
      nodes.push(<hr key={`hr-${i}`} className="my-3 border-slate-200 dark:border-slate-800" />);
    } else {
      nodes.push(
        <p key={`p-${i}`} className="m-0 leading-[1.6]">
          {formatInlineText(line)}
        </p>
      );
    }
  }

  flushList('final-list');
  flushBlockquote('final-quote');

  return nodes;
}

import { getSpeechLangForLocale, normalizeLocaleCode } from '../data/languages';

export interface ServerVoiceInfo {
  id: string;
  name: string;
  gender: 'male' | 'female';
  provider: 'gemini' | 'elevenlabs' | 'webspeech';
  description: string;
}

export interface TTSState {
  currentMessageId: string | null;
  status: 'idle' | 'loading' | 'playing' | 'paused';
  provider: 'gemini' | 'elevenlabs' | 'webspeech' | null;
  voiceName: string | null;
  notice: string | null;
  chunkIndex: number;
  totalChunks: number;
}

type StateListener = (state: TTSState) => void;

const FEMALE_VOICE_KEYWORDS = [
  'female', 'woman', 'girl', 'zira', 'samantha', 'karen', 'victoria', 'moira', 'fiona',
  'veena', 'leena', 'lekha', 'kalpana', 'ananya', 'priya', 'swara', 'aditi', 'tessa',
  'amelie', 'anna', 'sara', 'joana', 'helena', 'zuzana', 'heera', 'kavya', 'neerja',
  'google हिन्दी', 'google us english female', 'siri female',
];

const MALE_VOICE_KEYWORDS = [
  'male', 'man', 'boy', 'david', 'george', 'mark', 'alex', 'daniel', 'fred', 'oliver',
  'rishi', 'madhav', 'madhur', 'hemant', 'tarun', 'neel', 'ravi', 'guy', 'pradeep',
  'google uk english male', 'google us english male', 'siri male',
];

export function cleanTextForSpeech(markdown: string): string {
  if (!markdown) return '';
  let text = markdown;

  text = text.replace(/```[\s\S]*?```/g, ' [Code snippet omitted] ');
  text = text.replace(/`([^`]+)`/g, '$1');
  text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  text = text.replace(/https?:\/\/\S+/g, '');
  text = text.replace(/#{1,6}\s+/g, '');
  text = text.replace(/(\*\*|__)(.*?)\1/g, '$2');
  text = text.replace(/(\*|_)(.*?)\1/g, '$2');
  text = text.replace(/~~(.*?)~~/g, '$1');
  text = text.replace(/^>\s+/gm, '');
  text = text.replace(/^\s*[-*+]\s+/gm, '');
  text = text.replace(/^\s*\d+\.\s+/gm, '');
  text = text.replace(/^[-*_]{3,}\s*$/gm, '');
  text = text.replace(/\|/g, ' ');
  text = text.replace(/\s+/g, ' ').trim();

  return text;
}

export function chunkTextIntoSentences(text: string, maxLen = 300): string[] {
  if (!text) return [];
  const rawSentences = text.match(/[^.!?।\n]+[.!?।\n]+|[^.!?।\n]+$/g) || [text];
  const chunks: string[] = [];

  for (const sentence of rawSentences) {
    const trimmed = sentence.trim();
    if (!trimmed) continue;

    if (trimmed.length <= maxLen) {
      chunks.push(trimmed);
    } else {
      const parts = trimmed.split(/([,;:]\s+)/);
      let currentChunk = '';

      for (const part of parts) {
        if ((currentChunk + part).length <= maxLen) {
          currentChunk += part;
        } else {
          if (currentChunk.trim()) chunks.push(currentChunk.trim());
          currentChunk = part;
        }
      }
      if (currentChunk.trim()) chunks.push(currentChunk.trim());
    }
  }

  return chunks.length > 0 ? chunks : [text];
}

class TTSManager {
  private state: TTSState = {
    currentMessageId: null,
    status: 'idle',
    provider: null,
    voiceName: null,
    notice: null,
    chunkIndex: 0,
    totalChunks: 0,
  };

  private listeners: Set<StateListener> = new Set();
  private serverVoicesLoaded = false;
  private serverConfigured = false;
  private serverProvider: 'gemini' | 'elevenlabs' | 'webspeech' = 'webspeech';
  private serverVoices: ServerVoiceInfo[] = [];
  private browserVoices: SpeechSynthesisVoice[] = [];

  // Active playback tracking
  private sessionId = 0;
  private abortController: AbortController | null = null;
  private activeAudio: HTMLAudioElement | null = null;
  private activeAudioUrl: string | null = null;
  private prefetchedChunkPromises: Map<number, Promise<{ blobUrl: string; provider: 'gemini' | 'elevenlabs'; voiceName: string }>> = new Map();
  private chunks: string[] = [];
  private chunkIdx = 0;
  private activeLangCode = 'en-US';
  private activeGender: 'male' | 'female' = 'female';
  private activeVoiceId?: string;
  private activeWebVoice: SpeechSynthesisVoice | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.loadBrowserVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.loadBrowserVoices();
      };
    }
  }

  private loadBrowserVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      this.browserVoices = window.speechSynthesis.getVoices();
    } catch {}
  }

  public isWebSpeechSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && (typeof Audio !== 'undefined' || this.isWebSpeechSupported());
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getState(): TTSState {
    return { ...this.state };
  }

  private setState(partial: Partial<TTSState>) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((l) => l(this.state));
  }

  public async fetchConnectedVoices(forceRefresh = false): Promise<{
    configured: boolean;
    provider: 'gemini' | 'elevenlabs' | 'webspeech';
    voices: ServerVoiceInfo[];
  }> {
    if (this.serverVoicesLoaded && !forceRefresh) {
      return {
        configured: this.serverConfigured,
        provider: this.serverProvider,
        voices: this.serverVoices,
      };
    }

    try {
      const resp = await fetch('/api/tts/voices');
      if (resp.ok) {
        const data = await resp.json();
        this.serverConfigured = Boolean(data.configured);
        this.serverProvider = data.provider || 'webspeech';
        this.serverVoices = Array.isArray(data.voices) ? data.voices : [];
        this.serverVoicesLoaded = true;
        return {
          configured: this.serverConfigured,
          provider: this.serverProvider,
          voices: this.serverVoices,
        };
      }
    } catch (err) {
      console.warn('Could not load connected TTS voices:', err);
    }

    return {
      configured: false,
      provider: 'webspeech',
      voices: [],
    };
  }

  public getBrowserVoiceGender(voice: SpeechSynthesisVoice): 'male' | 'female' | 'unknown' {
    const name = voice.name.toLowerCase();
    for (const kw of FEMALE_VOICE_KEYWORDS) {
      if (name.includes(kw)) return 'female';
    }
    for (const kw of MALE_VOICE_KEYWORDS) {
      if (name.includes(kw)) return 'male';
    }
    return 'unknown';
  }

  public resolveBrowserVoice(
    languagePreference: string,
    gender: 'male' | 'female',
    sampleText?: string
  ): { voice: SpeechSynthesisVoice | null; langCode: string; exactGenderMatch: boolean } {
    this.loadBrowserVoices();
    const hasDevanagari = sampleText ? /[\u0900-\u097F]/.test(sampleText) : false;
    const targetLangCode = hasDevanagari ? 'hi-IN' : getSpeechLangForLocale(languagePreference);
    const langPrefix = targetLangCode.split('-')[0].toLowerCase();

    let langVoices = this.browserVoices.filter((v) => v.lang.toLowerCase().startsWith(langPrefix));
    if (langVoices.length === 0) {
      langVoices = this.browserVoices;
    }

    if (langVoices.length === 0) {
      return { voice: null, langCode: targetLangCode, exactGenderMatch: false };
    }

    const genderMatches = langVoices.filter((v) => this.getBrowserVoiceGender(v) === gender);
    if (genderMatches.length > 0) {
      return { voice: genderMatches[0], langCode: targetLangCode, exactGenderMatch: true };
    }

    return { voice: langVoices[0], langCode: targetLangCode, exactGenderMatch: false };
  }

  private resolveServerVoice(gender: 'male' | 'female', voiceId?: string): ServerVoiceInfo | null {
    if (this.serverVoices.length === 0) return null;
    if (voiceId) {
      const exact = this.serverVoices.find((v) => v.id === voiceId && v.gender === gender);
      if (exact) return exact;
    }
    return this.serverVoices.find((v) => v.gender === gender) || this.serverVoices[0];
  }

  private async fetchServerChunkAudio(
    chunkText: string,
    voiceId: string | undefined,
    gender: 'male' | 'female',
    langCode: string,
    signal: AbortSignal
  ): Promise<{ blobUrl: string; provider: 'gemini' | 'elevenlabs'; voiceName: string }> {
    const resp = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: chunkText,
        voiceId,
        gender,
        languagePreference: langCode,
      }),
      signal,
    });

    const contentType = resp.headers.get('content-type') || '';
    if (!resp.ok || !contentType.includes('audio')) {
      const errData = await resp.json().catch(() => ({}));
      throw new Error(errData.error || errData.message || 'Server TTS unavailable');
    }

    const blob = await resp.blob();
    const blobUrl = URL.createObjectURL(blob);
    const provider = (resp.headers.get('X-TTS-Provider') as 'gemini' | 'elevenlabs') || 'gemini';
    const voiceName = resp.headers.get('X-TTS-Voice') || voiceId || (gender === 'male' ? 'Charon' : 'Kore');
    return { blobUrl, provider, voiceName };
  }

  private prefetchChunk(index: number, currentSession: number) {
    if (index >= this.chunks.length || this.prefetchedChunkPromises.has(index) || !this.abortController) {
      return;
    }
    const signal = this.abortController.signal;
    const promise = this.fetchServerChunkAudio(
      this.chunks[index],
      this.activeVoiceId,
      this.activeGender,
      this.activeLangCode,
      signal
    ).catch((err) => {
      // Remove failed prefetch so caller can handle cleanly if session is still active
      if (this.sessionId === currentSession) {
        this.prefetchedChunkPromises.delete(index);
      }
      throw err;
    });
    this.prefetchedChunkPromises.set(index, promise);
  }

  public async play(
    messageId: string,
    rawText: string,
    options: {
      languagePreference: string;
      gender: 'male' | 'female';
      voiceId?: string;
    }
  ): Promise<void> {
    this.stop();

    const cleaned = cleanTextForSpeech(rawText);
    if (!cleaned) return;

    const mySession = ++this.sessionId;
    const controller = new AbortController();
    this.abortController = controller;

    const locale = normalizeLocaleCode(options.languagePreference);
    const hasDevanagari = /[\u0900-\u097F]/.test(cleaned);
    this.activeLangCode = hasDevanagari ? 'hi-IN' : getSpeechLangForLocale(locale);
    this.activeGender = options.gender === 'male' ? 'male' : 'female';

    this.chunks = chunkTextIntoSentences(cleaned, 300);
    this.chunkIdx = 0;

    this.setState({
      currentMessageId: messageId,
      status: 'loading',
      provider: null,
      voiceName: null,
      notice: null,
      chunkIndex: 0,
      totalChunks: this.chunks.length,
    });

    const voiceCatalog = await this.fetchConnectedVoices();
    if (this.sessionId !== mySession) return;

    if (voiceCatalog.configured && voiceCatalog.voices.length > 0) {
      const chosen = this.resolveServerVoice(this.activeGender, options.voiceId);
      this.activeVoiceId = chosen?.id;
      await this.playServerChunkAt(0, mySession, messageId, cleaned, options.languagePreference);
      return;
    }

    // Fallback to device Web Speech API when server TTS is not configured
    this.startWebSpeechPlayback(messageId, cleaned, options.languagePreference, this.activeGender, mySession);
  }

  private async playServerChunkAt(
    index: number,
    mySession: number,
    messageId: string,
    fullCleanedText: string,
    languagePreference: string
  ) {
    if (this.sessionId !== mySession) return;

    if (index >= this.chunks.length) {
      this.stop();
      return;
    }

    this.chunkIdx = index;

    try {
      let chunkPromise = this.prefetchedChunkPromises.get(index);
      if (!chunkPromise) {
        if (!this.abortController) return;
        chunkPromise = this.fetchServerChunkAudio(
          this.chunks[index],
          this.activeVoiceId,
          this.activeGender,
          this.activeLangCode,
          this.abortController.signal
        );
      }

      const { blobUrl, provider, voiceName } = await chunkPromise;
      this.prefetchedChunkPromises.delete(index);

      if (this.sessionId !== mySession) {
        URL.revokeObjectURL(blobUrl);
        return;
      }

      // Clean up any previous audio URL
      if (this.activeAudio) {
        this.activeAudio.onended = null;
        this.activeAudio.onerror = null;
        this.activeAudio.pause();
      }
      if (this.activeAudioUrl) {
        URL.revokeObjectURL(this.activeAudioUrl);
      }

      const audio = new Audio(blobUrl);
      this.activeAudio = audio;
      this.activeAudioUrl = blobUrl;

      audio.onended = () => {
        if (this.sessionId !== mySession) return;
        if (this.state.status === 'paused' || this.state.status === 'idle') return;
        const nextIndex = index + 1;
        if (nextIndex < this.chunks.length) {
          void this.playServerChunkAt(nextIndex, mySession, messageId, fullCleanedText, languagePreference);
        } else {
          this.stop();
        }
      };

      audio.onerror = () => {
        if (this.sessionId !== mySession) return;
        console.warn('Cloud audio playback failed on chunk', index);
        this.startWebSpeechPlayback(
          messageId,
          this.chunks.slice(index).join(' '),
          languagePreference,
          this.activeGender,
          mySession
        );
      };

      // Prefetch next chunk immediately before/as current plays
      this.prefetchChunk(index + 1, mySession);

      await audio.play();
      if (this.sessionId !== mySession) return;

      this.setState({
        currentMessageId: messageId,
        status: 'playing',
        provider,
        voiceName,
        notice: null,
        chunkIndex: index + 1,
        totalChunks: this.chunks.length,
      });
    } catch (err: any) {
      if (this.sessionId !== mySession || err?.name === 'AbortError') return;
      console.warn('Cloud TTS chunk error, switching to browser speech synthesis:', err?.message);
      this.startWebSpeechPlayback(
        messageId,
        this.chunks.slice(index).join(' '),
        languagePreference,
        this.activeGender,
        mySession
      );
    }
  }

  private startWebSpeechPlayback(
    messageId: string,
    text: string,
    languagePreference: string,
    gender: 'male' | 'female',
    mySession: number
  ) {
    if (!this.isWebSpeechSupported() || this.sessionId !== mySession) {
      this.stop();
      return;
    }

    try {
      window.speechSynthesis.cancel();
    } catch {}

    this.chunks = chunkTextIntoSentences(text, 160);
    this.chunkIdx = 0;

    const resolved = this.resolveBrowserVoice(languagePreference, gender, text);
    this.activeWebVoice = resolved.voice;
    this.activeLangCode = resolved.langCode;

    const genderNotice =
      !resolved.exactGenderMatch && resolved.voice
        ? `Browser lacks a ${gender} voice for ${resolved.langCode}; using device default (${resolved.voice.name}).`
        : null;

    this.setState({
      currentMessageId: messageId,
      status: 'playing',
      provider: 'webspeech',
      voiceName: resolved.voice?.name || 'Device Voice',
      notice: genderNotice,
      chunkIndex: 1,
      totalChunks: this.chunks.length,
    });

    this.speakWebChunk(mySession);
  }

  private speakWebChunk(mySession: number) {
    if (this.sessionId !== mySession || !this.isWebSpeechSupported()) return;
    if (this.chunkIdx >= this.chunks.length) {
      this.stop();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(this.chunks[this.chunkIdx]);
    if (this.activeWebVoice) {
      utterance.voice = this.activeWebVoice;
    }
    utterance.lang = this.activeLangCode;
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      if (this.sessionId !== mySession) return;
      if (this.state.status === 'paused' || this.state.status === 'idle') return;
      this.chunkIdx++;
      if (this.chunkIdx < this.chunks.length) {
        this.setState({ chunkIndex: this.chunkIdx + 1 });
        this.speakWebChunk(mySession);
      } else {
        this.stop();
      }
    };

    utterance.onerror = (ev) => {
      if (this.sessionId !== mySession) return;
      if (ev.error === 'canceled' || ev.error === 'interrupted') return;
      console.warn('Web Speech chunk error:', ev.error);
      this.stop();
    };

    try {
      window.speechSynthesis.speak(utterance);
    } catch {
      this.stop();
    }
  }

  public pause() {
    if (this.activeAudio && !this.activeAudio.paused) {
      this.activeAudio.pause();
      this.setState({ status: 'paused' });
      return;
    }
    if (this.isWebSpeechSupported() && window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      try {
        window.speechSynthesis.pause();
        this.setState({ status: 'paused' });
      } catch {}
    }
  }

  public resume() {
    if (this.activeAudio && this.activeAudio.paused && this.state.status === 'paused') {
      void this.activeAudio.play();
      this.setState({ status: 'playing' });
      return;
    }
    if (this.isWebSpeechSupported() && this.state.status === 'paused') {
      try {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
          this.setState({ status: 'playing' });
        } else {
          this.setState({ status: 'playing' });
          this.speakWebChunk(this.sessionId);
        }
      } catch {}
    }
  }

  public stop() {
    this.sessionId++;
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    // Revoke any prefetched chunk URLs
    this.prefetchedChunkPromises.forEach((p) => {
      p.then((res) => {
        try {
          URL.revokeObjectURL(res.blobUrl);
        } catch {}
      }).catch(() => {});
    });
    this.prefetchedChunkPromises.clear();

    if (this.activeAudio) {
      this.activeAudio.onended = null;
      this.activeAudio.onerror = null;
      this.activeAudio.pause();
      this.activeAudio = null;
    }
    if (this.activeAudioUrl) {
      try {
        URL.revokeObjectURL(this.activeAudioUrl);
      } catch {}
      this.activeAudioUrl = null;
    }

    if (this.isWebSpeechSupported()) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    this.chunks = [];
    this.chunkIdx = 0;
    this.activeWebVoice = null;

    this.setState({
      currentMessageId: null,
      status: 'idle',
      provider: null,
      voiceName: null,
      notice: null,
      chunkIndex: 0,
      totalChunks: 0,
    });
  }

  public async testVoice(options: {
    gender: 'male' | 'female';
    languagePreference: string;
    voiceId?: string;
  }): Promise<void> {
    const locale = normalizeLocaleCode(options.languagePreference);
    const sampleByPrefix: Record<string, string> = {
      hi: 'नमस्ते! यह MindGPT की प्राकृतिक आवाज़ का परीक्षण है।',
      bn: 'নমস্কার! এটি MindGPT-এর স্বাভাবিক কণ্ঠস্বর পরীক্ষা।',
      mr: 'नमस्कार! ही MindGPT च्या नैसर्गिक आवाजाची चाचणी आहे.',
      ta: 'வணக்கம்! இது MindGPT குரல் சோதனை.',
      te: 'నమస్కారం! ఇది MindGPT సహజ వాయిస్ పరీక్ష.',
      gu: 'નમસ્તે! આ MindGPT નો અવાજ પરીક્ષણ છે.',
      pa: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਇਹ MindGPT ਦੀ ਆਵਾਜ਼ ਦੀ ਜਾਂਚ ਹੈ।',
      ur: 'السلام علیکم! یہ MindGPT کی قدرتی آواز کا ٹیسٹ ہے۔',
      es: '¡Hola! Esta es una prueba de voz de MindGPT.',
      fr: 'Bonjour ! Ceci est un test vocal de MindGPT.',
      de: 'Hallo! Dies ist ein Sprachtest von MindGPT.',
      ja: 'こんにちは！これはMindGPTの音声テストです。',
      ko: '안녕하세요! MindGPT 음성 테스트입니다.',
      zh: '你好！这是 MindGPT 的语音测试。',
      ar: 'مرحباً! هذا اختبار صوتي من MindGPT.',
      pt: 'Olá! Este é um teste de voz do MindGPT.',
      ru: 'Привет! Это тест голоса MindGPT.',
    };
    const prefix = locale.split('-')[0].toLowerCase();
    const sample =
      sampleByPrefix[prefix] ||
      'Hello! This is MindGPT testing your selected voice for natural assistant responses.';

    await this.play('test-voice-preview', sample, options);
  }
}

export const ttsEngine = new TTSManager();
